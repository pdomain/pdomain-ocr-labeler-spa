// Hi-fi · multiple views with a top picker.
// Views: Studio (full N1), Word Detail (focused right-panel), Line Words,
// Block Items Words, Block Layout.

const H = {
  bgPage:'#0c0c10', bgSurface:'#15151b', bgRaised:'#1d1d24', bgSunk:'#08080c',
  border1:'#222229', border2:'#2f2f38', border3:'#3f3f49',
  ink1:'#f0f0f2', ink2:'#b0b0b8', ink3:'#7a7a85', ink4:'#4e4e58',
  accent:'#d6925a',
  exact:'#5fbf6a', fuzzy:'#e8a83a', mismatch:'#dc6555',
  ocr:'#5d9fdf', gt:'#a888d4',
  block:'#a89074', para:'#7fb56a', line:'#d088a8', word:'#6e9cdf',
  ui:'"Inter", system-ui, sans-serif',
  mono:'"JetBrains Mono", ui-monospace, monospace',
};

if (typeof document !== 'undefined' && !document.getElementById('hifi-styles')) {
  const s = document.createElement('style');
  s.id = 'hifi-styles';
  s.textContent = `
    .hf { background:${H.bgPage}; color:${H.ink1}; font-family:${H.ui};
      width:100%; height:100%; box-sizing:border-box; position:relative; overflow:hidden; }
    .hf * { box-sizing:border-box; }
    .hf-btn { display:inline-flex; align-items:center; justify-content:center; gap:6px;
      height:30px; padding:0 12px; border-radius:6px; background:${H.bgRaised};
      border:1px solid ${H.border2}; color:${H.ink1}; font-size:12px; font-weight:500;
      cursor:default; user-select:none; white-space:nowrap; }
    .hf-btn.sm { height:24px; padding:0 9px; font-size:11px; border-radius:5px; }
    .hf-btn.lg { height:34px; padding:0 14px; font-size:13px; }
    .hf-btn.primary { background:${H.accent}; border-color:${H.accent}; color:#1a0f08; }
    .hf-btn.ghost { background:transparent; border-color:transparent; color:${H.ink2}; }
    .hf-btn.danger { color:${H.mismatch}; border-color:${H.mismatch}44; background:${H.mismatch}11; }
    .hf-btn.icon { width:30px; padding:0; }
    .hf-btn.icon.sm { width:24px; }
    .hf-chip { display:inline-flex; align-items:center; gap:5px; height:20px; padding:0 8px;
      border-radius:10px; background:${H.bgRaised}; border:1px solid ${H.border2};
      font-size:10.5px; font-weight:500; color:${H.ink2}; }
    .hf-chip .dot { width:6px; height:6px; border-radius:50%; }
    .hf-pip { display:inline-flex; align-items:center; gap:4px; height:18px; padding:0 7px;
      border-radius:9px; font-size:10px; font-weight:600; letter-spacing:0.02em; }
    .hf-pip .dot { width:5px; height:5px; border-radius:50%; }
    .hf-input { height:28px; padding:0 10px; background:${H.bgSunk}; border:1px solid ${H.border2};
      border-radius:5px; font-family:${H.mono}; font-size:12px; color:${H.ink1}; outline:none; }
    .hf-input.lg { height:32px; font-size:13px; }
    .hf-key { display:inline-flex; align-items:center; justify-content:center;
      min-width:18px; height:18px; padding:0 5px; background:${H.bgSunk};
      border:1px solid ${H.border3}; border-bottom-width:2px; border-radius:3px;
      font-family:${H.mono}; font-size:9.5px; font-weight:500; color:${H.ink2}; }
    .hf-label { font-family:${H.ui}; font-size:9.5px; font-weight:700;
      letter-spacing:0.1em; text-transform:uppercase; color:${H.ink3}; }
    .hf-tabs { display:flex; gap:0; border-bottom:1px solid ${H.border1}; }
    .hf-tab { padding:10px 14px; font-size:12.5px; font-weight:500; color:${H.ink3};
      border-bottom:2px solid transparent; margin-bottom:-1px; display:inline-flex;
      align-items:center; gap:6px; cursor:default; }
    .hf-tab.active { color:${H.ink1}; border-bottom-color:${H.accent}; }
    .hf-tab .count { font-family:${H.mono}; font-size:10px; color:${H.ink3}; padding:1px 5px;
      background:${H.bgRaised}; border-radius:8px; }
    .hf-tab.active .count { color:${H.ink1}; background:${H.accent}33; }
    .hf-mono { font-family:${H.mono}; }
    .hf ::-webkit-scrollbar { width:8px; height:8px; }
    .hf ::-webkit-scrollbar-track { background:transparent; }
    .hf ::-webkit-scrollbar-thumb { background:${H.border2}; border-radius:4px; }
    .hf-section { background:${H.bgSunk}; border:1px solid ${H.border1}; border-radius:6px;
      padding:12px; display:flex; flex-direction:column; gap:10px; }
    .hf-section-h { display:flex; align-items:baseline; gap:8px; }
    .hf-section-h .l { font-size:10.5px; font-weight:700; letter-spacing:0.05em; color:${H.ink1}; }
    .hf-section-h .sub { font-size:10px; color:${H.ink3}; }
  `;
  document.head.appendChild(s);
}

// ============= shared =============
function Metric({ value, label, color }) {
  return (
    <span style={{display:'inline-flex', alignItems:'baseline', gap: 4}}>
      {color && <span style={{width:6, height:6, borderRadius:3, background: color, alignSelf:'center'}}></span>}
      <span style={{fontWeight: 700, fontSize: 13, color: H.ink1, fontFamily: H.mono}}>{value}</span>
      <span style={{color: H.ink3, fontSize: 11}}>{label}</span>
    </span>
  );
}

function ChipState({ label, hot, state, kind='style' }) {
  const base = kind === 'style' ? H.ocr : H.gt;
  const map = {
    none:{bg:H.bgRaised, fg:H.ink2, bd:H.border2},
    some:{bg:H.bgRaised, fg:base, bd:base},
    all:{bg:base+'1a', fg:base, bd:base},
  };
  const c = map[state];
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap: 5,
      height: 24, padding:'0 8px 0 6px',
      background: c.bg, border:`1.5px solid ${c.bd}`, borderRadius: 12,
      fontSize: 11, fontWeight: 600, color: c.fg,
    }}>
      <span style={{
        width: 12, height: 12, borderRadius: 6,
        background: state==='all' ? base : 'transparent',
        border:`1.5px solid ${state==='none' ? H.border3 : base}`,
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontSize: 7, color: '#1a0f08', fontWeight: 700,
      }}>{state==='all'?'✓':''}</span>
      <span style={{
        fontStyle: label==='italic'?'italic':'normal',
        fontVariant: label==='small caps'?'small-caps':'normal',
      }}>{label}</span>
      {hot && <span className="hf-key" style={{height: 14, fontSize: 9, marginLeft: 2}}>{hot}</span>}
    </span>
  );
}

function Breadcrumb({ active='word' }) {
  const path = [
    { label:'Matches', kind:'none' },
    { label:'Body', kind:'block' },
    { label:'Column', sub:'2/2', kind:'block' },
    { label:'¶', sub:'#1 · body', kind:'paragraph' },
    { label:'Line', sub:'7', kind:'line' },
    { label:'Word', sub:'1 "The"', kind:'word' },
  ];
  const colMap = { block:H.block, paragraph:H.para, line:H.line, word:H.word, none:H.ink3 };
  const activeIdx = {block:2, paragraph:3, line:4, word:5}[active] ?? 5;
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 4,
      padding:'10px 14px', borderBottom:`1px solid ${H.border1}`,
      background: H.bgPage,
    }}>
      {path.slice(0, activeIdx+1).map((p, i) => {
        const c = colMap[p.kind];
        const isLast = i === activeIdx;
        return (
          <React.Fragment key={i}>
            <span style={{
              display:'inline-flex', alignItems:'center', gap: 4,
              padding:'3px 8px', borderRadius: 4,
              background: isLast ? c+'1a' : 'transparent',
              border: isLast ? `1px solid ${c}55` : '1px solid transparent',
              fontSize: 11, fontWeight: 600, color: isLast ? c : H.ink2,
            }}>
              {p.kind !== 'none' && <span style={{width: 5, height: 5, borderRadius: 1, background: c}}></span>}
              {p.label}
              {p.sub && <span style={{fontSize: 9.5, fontFamily: H.mono, color: H.ink3}}>{p.sub}</span>}
            </span>
            {!isLast && <span style={{color: H.ink4, fontSize: 11}}>›</span>}
          </React.Fragment>
        );
      })}
      <div style={{flex:1}}></div>
      <span style={{fontSize: 10, color: H.ink3}}>
        <span className="hf-key">⌥↑</span> parent
      </span>
    </div>
  );
}

// ============= Studio (Header+Rail+Drawer+Canvas+Right) =============
function StudioHeader() {
  return (
    <div style={{
      height: 56, flex:'0 0 56px',
      borderBottom: `1px solid ${H.border1}`, background: H.bgPage,
      display:'flex', alignItems:'center', gap: 20, padding: '0 20px',
    }}>
      <div style={{display:'flex', alignItems:'center', gap: 10}}>
        <span style={{width: 28, height: 28, borderRadius: 6, background: H.accent, color:'#1a0f08',
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 14, fontWeight: 700, fontFamily: H.mono}}>O</span>
        <span style={{fontSize: 14, fontWeight: 600}}>ocr-labeler</span>
      </div>
      <div style={{display:'flex', alignItems:'center', gap: 6, fontSize: 13, color: H.ink2}}>
        <span style={{color: H.ink3}}>Projects</span><span style={{color: H.ink4}}>/</span>
        <span style={{color: H.ink1, fontWeight: 600, padding:'4px 10px', background: H.bgRaised,
          borderRadius: 5, border:`1px solid ${H.border2}`}}>willa-cather-letters</span>
      </div>
      <div style={{display:'flex', alignItems:'center', gap: 6, marginLeft: 8}}>
        <span className="hf-btn sm icon">◀</span>
        <span className="hf-btn sm icon">▶</span>
        <input className="hf-input" defaultValue="47" style={{width: 52, height:24, fontSize: 11, textAlign:'center'}}/>
        <span style={{fontSize: 11, color: H.ink3}}>/ 392</span>
      </div>
      <div style={{flex:1}}></div>
      <div style={{display:'flex', alignItems:'center', gap: 16}}>
        <Metric value="22" label="words"/>
        <Metric value="15" label="exact" color={H.exact}/>
        <Metric value="7" label="fuzzy" color={H.fuzzy}/>
        <Metric value="0" label="✗" color={H.mismatch}/>
        <Metric value="15/22" label="validated"/>
      </div>
      <div style={{display:'inline-flex', alignItems:'center', gap: 8, height: 30, padding:'0 12px',
        background: H.bgSurface, border:`1px solid ${H.border1}`, borderRadius: 6,
        color: H.ink3, fontSize: 12, minWidth: 220}}>
        <span>⌕</span><span style={{flex:1}}>Search…</span>
        <span className="hf-key">⌘</span><span className="hf-key">K</span>
      </div>
      <div style={{display:'flex', gap: 6}}>
        <span className="hf-btn">Reload OCR</span>
        <span className="hf-btn">Rematch</span>
        <span className="hf-btn primary">✓ Save page</span>
        <span className="hf-btn">Export ▾</span>
      </div>
      <div style={{width: 28, height: 28, borderRadius: 14, background: H.bgRaised,
        border:`1px solid ${H.border2}`, display:'inline-flex', alignItems:'center',
        justifyContent:'center', fontSize: 11, fontWeight: 600}}>M</div>
    </div>
  );
}

function Rail({ activeTarget='Word' }) {
  return (
    <div style={{
      width: 64, flex:'0 0 64px', background: H.bgPage,
      borderRight:`1px solid ${H.border1}`,
      display:'flex', flexDirection:'column', alignItems:'center',
      padding: '14px 0', gap: 6,
    }}>
      <span className="hf-label" style={{fontSize: 8}}>MODE</span>
      {[
        {k:'Select', icon:'⬚', active:true},
        {k:'Rebox',  icon:'⤡'},
        {k:'Add',    icon:'＋'},
        {k:'Erase',  icon:'⌫'},
      ].map(m => (
        <div key={m.k} style={{
          width: 48, padding:'6px 0',
          background: m.active ? H.bgRaised : 'transparent',
          border: m.active ? `1px solid ${H.border3}` : '1px solid transparent',
          borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap: 2,
        }}>
          <span style={{fontSize: 15, color: m.active ? H.ink1 : H.ink3}}>{m.icon}</span>
          <span style={{fontSize: 9.5, fontWeight: 600, color: m.active ? H.ink1 : H.ink3}}>{m.k}</span>
        </div>
      ))}
      <span className="hf-label" style={{fontSize: 8, marginTop: 8}}>TARGET</span>
      <div style={{
        display:'flex', flexDirection:'column', gap: 2, padding: 2,
        background: H.bgSunk, border:`1px solid ${H.border1}`, borderRadius: 5,
      }}>
        {[['B', H.block, 'Block'],['L', H.line, 'Line'],['W', H.word, 'Word']].map(([k, c, full]) => {
          const a = full === activeTarget;
          return (
            <div key={k} style={{
              width: 28, height: 24, borderRadius: 3,
              background: a ? H.bgRaised : 'transparent',
              border: a ? `1px solid ${c}` : '1px solid transparent',
              color: a ? c : H.ink3,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize: 11, fontWeight: 700, fontFamily: H.mono,
            }}>{k}</div>
          );
        })}
      </div>
      <div style={{width:'70%', height:1, background: H.border1, margin:'10px 0 4px'}}></div>
      <span className="hf-label" style={{fontSize: 8}}>LAYERS</span>
      {[['Block', H.block],['¶ Para', H.para],['Line', H.line],['Word', H.word]].map(([l, c]) => (
        <div key={l} style={{width: 48, padding:'4px 0',
          display:'flex', flexDirection:'column', alignItems:'center', gap: 2}}>
          <span style={{width: 18, height: 18, borderRadius: 4, background: c+'33', border:`1.5px solid ${c}`}}></span>
          <span style={{fontSize: 9, color: H.ink2}}>{l}</span>
        </div>
      ))}
      <div style={{flex:1}}></div>
      {[{k:'Bulk',i:'⌗'},{k:'Hotkeys',i:'⌘'}].map(t => (
        <div key={t.k} style={{width: 48, padding:'4px 0',
          display:'flex', flexDirection:'column', alignItems:'center', gap: 2, color: H.ink3}}>
          <span style={{fontSize: 13}}>{t.i}</span>
          <span style={{fontSize: 9}}>{t.k}</span>
        </div>
      ))}
    </div>
  );
}

function Drawer({ view='worklist' }) {
  return (
    <div style={{
      flex:'0 0 320px', width: 320, borderRight:`1px solid ${H.border1}`,
      background: H.bgSurface, display:'flex', flexDirection:'column',
    }}>
      <div style={{display:'flex', alignItems:'center', padding:'0 10px',
        borderBottom:`1px solid ${H.border1}`}}>
        <span className={`hf-tab ${view==='worklist' ? 'active' : ''}`}>☰ Worklist <span className="count">7</span></span>
        <span className={`hf-tab ${view==='hierarchy' ? 'active' : ''}`}>⌐ Hierarchy</span>
        <div style={{flex:1}}></div>
        <span className="hf-btn ghost sm icon">‹</span>
      </div>
      {view === 'worklist' ? <WorklistBody/> : <HierarchyBody/>}
    </div>
  );
}

function WorklistBody() {
  const q = [
    {l:7,w:1,ocr:'tbe',gt:'The',s:'mismatch',c:42,focused:true},
    {l:7,w:2,ocr:'Jounding',gt:'Founding',s:'mismatch',c:38},
    {l:7,w:4,ocr:'tbe',gt:'the',s:'mismatch',c:44},
    {l:7,w:5,ocr:'Gopernment',gt:'Government',s:'mismatch',c:29},
    {l:4,w:3,ocr:'PH.D.,',gt:'Ph.D.,',s:'fuzzy',c:83},
    {l:4,w:4,ocr:'LITT.D.,',gt:'Litt.D.,',s:'fuzzy',c:62},
    {l:6,w:1,ocr:'VOL.',gt:'Vol.',s:'fuzzy',c:75},
  ];
  return (
    <>
      <div style={{padding:'10px 14px', borderBottom:`1px solid ${H.border1}`,
        display:'flex', flexDirection:'column', gap: 8}}>
        <div style={{display:'flex', gap: 4, flexWrap:'wrap'}}>
          <span className="hf-chip" style={{background:H.mismatch+'1a', color:H.mismatch, borderColor:H.mismatch+'55'}}>
            <span className="dot" style={{background:H.mismatch}}></span>mismatch 4
          </span>
          <span className="hf-chip" style={{background:H.fuzzy+'1a', color:H.fuzzy, borderColor:H.fuzzy+'55'}}>
            <span className="dot" style={{background:H.fuzzy}}></span>fuzzy 3
          </span>
        </div>
        <div style={{display:'flex', alignItems:'center', gap: 6}}>
          <span className="hf-label">Sort</span>
          <span className="hf-chip">confidence ↑</span>
          <div style={{flex:1}}></div>
          <span style={{fontSize: 10, color: H.ink3, display:'flex', gap: 3}}>
            <span className="hf-key">J</span><span className="hf-key">K</span>
          </span>
        </div>
      </div>
      <div style={{flex: 1, overflow:'auto', padding: 6}}>
        {q.map((x, i) => {
          const c = x.s === 'mismatch' ? H.mismatch : H.fuzzy;
          return (
            <div key={i} style={{
              padding: 10, marginBottom: 3, borderRadius: 6,
              background: x.focused ? H.bgRaised : 'transparent',
              border: x.focused ? `1px solid ${H.accent}66` : '1px solid transparent',
              display:'flex', gap: 10, alignItems:'center',
            }}>
              <span style={{width: 4, height: 36, borderRadius: 2, background: c}}></span>
              <div style={{flex:1, minWidth:0}}>
                <div style={{display:'flex', alignItems:'center', gap: 6, marginBottom: 4}}>
                  <span style={{fontSize: 10, color: H.ink3, fontFamily: H.mono, fontWeight: 600}}>L{x.l}·W{x.w}</span>
                  <span className="hf-pip" style={{background: c+'1a', color: c, border:`1px solid ${c}55`}}>
                    <span className="dot" style={{background: c}}></span>
                    {x.s === 'mismatch' ? '✗' : '~'}
                  </span>
                  <span style={{fontSize: 10, color: H.ink3, marginLeft:'auto', fontFamily: H.mono}}>{x.c}%</span>
                </div>
                <div style={{fontFamily: H.mono, fontSize: 11, whiteSpace:'nowrap'}}>
                  <span style={{color: H.ink3}}>{x.ocr}</span>
                  <span style={{margin:'0 6px', color: H.ink4}}>→</span>
                  <span style={{color: H.ink1}}>{x.gt}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

function HierarchyBody() {
  const rows = [
    ['B1', 0, 'structural', 'Header band', false],
    ['B1.1', 1, 'paragraph', '¶ running head', true],
    ['B2', 0, 'structural', 'Body', false],
    ['B2.1', 1, 'structural', 'Column 1', false],
    ['B2.1.1', 2, 'paragraph', '¶ chapter heading', true],
    ['B2.1.2', 2, 'paragraph', '¶ byline', true],
    ['B2.2', 1, 'structural', 'Column 2', false],
    ['B2.2.1', 2, 'paragraph', '¶ body text', true],
    ['B2.2.2', 2, 'structural', 'Block quote', false, true],
    ['B2.2.2.1', 3, 'paragraph', '¶ quote pt1', true],
    ['B2.2.2.2', 3, 'paragraph', '¶ quote pt2', true],
    ['B2.2.3', 2, 'paragraph', '¶ body text', true],
    ['B3', 0, 'structural', 'Footnote band', false],
    ['B4', 0, 'structural', 'Footer band', false],
  ];
  return (
    <>
      <div style={{padding:'10px 14px', borderBottom:`1px solid ${H.border1}`,
        display:'flex', alignItems:'center', gap: 6}}>
        <span className="hf-label">Filter</span>
        <span className="hf-chip">All</span>
        <span className="hf-chip">Blocks</span>
        <span className="hf-chip">¶ only</span>
        <div style={{flex:1}}></div>
        <span style={{fontSize: 10, color: H.ink3}}>22 nodes</span>
      </div>
      <div style={{flex: 1, overflow:'auto', padding: 6}}>
        {rows.map(([id, depth, kind, label, leaf, selected]) => {
          const c = kind === 'structural' ? H.block : H.para;
          return (
            <div key={id} style={{
              display:'flex', alignItems:'center', gap: 6,
              padding: '5px 6px', borderRadius: 4,
              paddingLeft: 6 + depth * 14,
              background: selected ? H.bgRaised : 'transparent',
              border: selected ? `1px solid ${H.accent}66` : '1px solid transparent',
              marginBottom: 1,
            }}>
              {!leaf && <span style={{width: 10, color: H.ink3, fontSize: 8, transform:'rotate(90deg)'}}>▶</span>}
              {leaf && <span style={{width: 10}}></span>}
              <span style={{
                fontSize: 9.5, color: c, fontWeight: 600,
                padding:'1px 6px', background: c+'1a', border:`1px solid ${c}44`, borderRadius: 8,
              }}>{kind === 'structural' ? 'block' : '¶'}</span>
              <span style={{fontSize: 11.5, color: H.ink1, flex:1, minWidth:0,
                whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{label}</span>
              <span style={{fontFamily: H.mono, fontSize: 9, color: H.ink4}}>{id}</span>
            </div>
          );
        })}
      </div>
    </>
  );
}

function CanvasArea({ highlight='Line' }) {
  return (
    <div style={{
      flex: 1, borderRight:`1px solid ${H.border1}`,
      padding: 14, background: H.bgPage,
      display:'flex', flexDirection:'column', gap: 10, minWidth: 0,
    }}>
      <div style={{
        background: H.bgSurface, border:`1px solid ${H.border1}`, borderRadius: 6,
        padding:'8px 12px', display:'flex', alignItems:'center', gap: 10,
      }}>
        <span style={{width: 14, color: H.ink2, fontSize: 11}}>▶</span>
        <span style={{fontSize: 12, fontWeight: 600}}>Bulk actions</span>
        <span style={{fontSize: 10, color: H.ink3}}>scope × action</span>
        <div style={{flex:1}}></div>
        <span style={{fontSize: 10, color: H.ink3, display:'flex', alignItems:'center', gap: 6}}>
          recent:
          <span className="hf-btn sm">Refine</span>
          <span className="hf-btn sm">OCR → GT</span>
          <span className="hf-btn sm">Validate</span>
        </span>
        <span className="hf-key">G</span>
      </div>
      <div style={{
        background: H.bgSurface, border:`1px solid ${H.border1}`, borderRadius: 6,
        padding:'8px 12px', display:'flex', alignItems:'center', gap: 10,
      }}>
        <span style={{display:'inline-flex', alignItems:'center', gap: 6, fontSize:11, fontWeight: 600,
          padding: '4px 10px', borderRadius: 4,
          background: H.accent+'1a', color: H.accent, border:`1px solid ${H.accent}55`}}>
          <span style={{width: 6, height: 6, borderRadius: 3, background: H.accent}}></span>
          SELECT · target {highlight}
        </span>
        <div style={{flex:1}}></div>
        <span className="hf-btn sm">Fit</span>
        <span className="hf-btn sm">100%</span>
      </div>
      <div style={{
        flex: 1, background:'#1a1a20', border:`1px solid ${H.border1}`, borderRadius: 6,
        overflow:'hidden', position:'relative',
      }}>
        <PageScan/>
      </div>
    </div>
  );
}

function PageScan() {
  return (
    <div style={{width:'100%', height:'100%', background:'#f5efdf',
      backgroundImage: `linear-gradient(rgba(60,40,20,0.08) 1px, transparent 1px)`,
      backgroundSize: `100% 24px`, position:'relative', overflow:'hidden'}}>
      <div style={{position:'absolute', left:'10%', right:'10%', top:'8%', bottom:'8%',
        display:'flex', flexDirection:'column', gap: 20}}>
        <PageL words={['A','HISTORY','OF']} size={1.5}/>
        <PageL words={['THE','AMERICAN','PEOPLE']} size={1.5}/>
        <div style={{height: 10}}></div>
        <PageL words={['BY']}/>
        <PageL words={['WOODROW','WILSON,','Ph.D.,','Litt.D.,','LL.D.']}/>
        <div style={{height: 10}}></div>
        <PageL words={['IN','FIVE','VOLUMES']}/>
        <PageL words={['VOL.','III.']}/>
        <div style={{height: 14}}></div>
        <PageL highlight words={['The','Founding','of','the','Government']} size={1.2}/>
      </div>
    </div>
  );
}

function PageL({ words, size=1, highlight }) {
  return (
    <div style={{
      display:'flex', justifyContent:'center', gap: 8, padding:'4px 8px',
      outline: highlight ? `2px solid ${H.accent}` : `1px solid ${H.line}66`,
      background: H.line+'12', borderRadius: 2,
    }}>
      {words.map((w, i) => (
        <span key={i} style={{
          fontFamily:'"Times New Roman", serif', fontSize: 20 * size, fontWeight: 500,
          color: '#2a221a', padding:'0 4px',
          outline:`1px solid ${H.word}88`, background: H.word+'15', borderRadius: 1,
        }}>{w}</span>
      ))}
    </div>
  );
}

// ============= 1 · Studio view =============
function StudioView() {
  return (
    <div className="hf" style={{display:'flex', flexDirection:'column'}}>
      <StudioHeader/>
      <div style={{flex:1, display:'flex', minHeight: 0}}>
        <Rail/>
        <Drawer view="worklist"/>
        <CanvasArea highlight="Word"/>
        <RightPanelWord/>
      </div>
    </div>
  );
}

// ============= 2 · Word detail (right-panel, in-context studio) =============
function RightPanelWord() {
  return (
    <div style={{flex:'0 0 520px', width: 520, background: H.bgSurface,
      display:'flex', flexDirection:'column', minWidth: 0}}>
      <Breadcrumb active="word"/>
      <div style={{flex: 1, overflow:'auto', padding: 16,
        display:'flex', flexDirection:'column', gap: 14}}>
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Line 7 · Word 1</span>
          <span className="hf-pip" style={{background: H.mismatch+'1a', color: H.mismatch, border:`1px solid ${H.mismatch}55`}}>
            <span className="dot" style={{background: H.mismatch}}></span>mismatch · 42%
          </span>
          <div style={{flex:1}}></div>
          <span style={{fontSize:10, color: H.ink3}}>1 of 7</span>
          <span className="hf-btn sm">◀</span>
          <span className="hf-btn sm">▶</span>
        </div>
        <div style={{background:'#f5efdf', borderRadius: 6, border:`1.5px solid ${H.accent}`,
          padding:'20px 24px', position:'relative',
          display:'flex', alignItems:'center', justifyContent:'center'}}>
          <span style={{fontFamily:'serif', fontSize: 76, color:'#1a140a'}}>The</span>
          <div style={{position:'absolute', left: 14, right: 14, bottom: 4,
            display:'flex', flexDirection:'column', gap: 2}}>
            <div style={{height: 4}}><div style={{width:'33%', height: 4, background: H.ocr, borderRadius: 2}}></div></div>
            <div style={{height: 4}}><div style={{width:'33%', height: 4, background: H.gt, opacity:0.7, borderRadius: 2}}></div></div>
          </div>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'62px 1fr auto', rowGap: 8, columnGap: 10, alignItems:'center'}}>
          <span className="hf-label">OCR</span>
          <div className="hf-mono" style={{padding:'8px 10px', background: H.bgSunk, border:`1px solid ${H.border1}`, borderRadius: 5, fontSize: 13, color: H.ink2}}>tbe</div>
          <span className="hf-btn sm">OCR → GT</span>
          <span className="hf-label">GT</span>
          <input className="hf-input lg" defaultValue="The" style={{width:'100%', fontSize:14}}/>
          <span className="hf-btn sm" style={{background: H.ocr+'1a', borderColor: H.ocr+'66', color: H.ocr}}>Ω chars ▾</span>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12,
          padding: 12, background: H.bgSunk, borderRadius: 6, border:`1px solid ${H.border1}`}}>
          <div>
            <div style={{display:'flex', alignItems:'baseline', gap: 6, marginBottom: 8}}>
              <span style={{fontSize: 10.5, fontWeight: 700, color: H.ocr, letterSpacing:'0.05em'}}>STYLE</span>
              <span style={{fontSize: 10, color: H.ink3}}>whole word</span>
            </div>
            <div style={{display:'flex', flexWrap:'wrap', gap: 4}}>
              <ChipState label="small caps" hot="S" state="none" kind="style"/>
              <ChipState label="italic" hot="I" state="none" kind="style"/>
              <ChipState label="ALL CAPS" hot="C" state="none" kind="style"/>
              <ChipState label="blackletter" hot="B" state="none" kind="style"/>
              <span className="hf-chip" style={{borderStyle:'dashed', color: H.ink3}}>more ▾</span>
            </div>
          </div>
          <div>
            <div style={{display:'flex', alignItems:'baseline', gap: 6, marginBottom: 8}}>
              <span style={{fontSize: 10.5, fontWeight: 700, color: H.gt, letterSpacing:'0.05em'}}>COMPONENT</span>
              <span style={{fontSize: 10, color: H.ink3}}>additive</span>
            </div>
            <div style={{display:'flex', flexWrap:'wrap', gap: 4}}>
              <ChipState label="drop cap" state="none" kind="component"/>
              <ChipState label="footnote marker" state="none" kind="component"/>
              <span className="hf-chip" style={{borderStyle:'dashed', color: H.ink3}}>more ▾</span>
            </div>
          </div>
        </div>
        {[
          ['BOUNDING BOX', 'x:124 y:418 · 92×54 px', 'F'],
          ['REBOX', 'redraw on zoomed region', 'B', H.accent],
          ['ERASE PIXELS', 'brush · rect · lasso · auto-detect', 'X', H.mismatch],
          ['STRUCTURE', 'merge · split · neighbors', ''],
          ['CHAR RANGES', 'partial-word style or component', 'R'],
          ['CHARACTER FIXER', 'edit per-char bboxes', ''],
        ].map(([l, sub, hot, accent], i) => (
          <div key={i} style={{
            display:'flex', alignItems:'center', gap: 10, padding:'10px 12px',
            background: accent ? accent+'0c' : H.bgSunk,
            border:`1px solid ${accent ? accent+'33' : H.border1}`, borderRadius: 6,
          }}>
            <span style={{width: 14, color: accent || H.ink2, fontSize: 11}}>▶</span>
            <span style={{fontSize: 10.5, fontWeight: 700, letterSpacing:'0.05em', color: accent || H.ink1}}>{l}</span>
            <span style={{fontSize: 10, color: H.ink3}}>{sub}</span>
            <div style={{flex:1}}></div>
            {hot && <span className="hf-key">{hot}</span>}
          </div>
        ))}
        <div style={{marginTop: 6, display:'flex', gap: 6}}>
          <span className="hf-btn primary lg" style={{flex:1}}>
            ✓ Validate &amp; Next
            <span className="hf-key" style={{background:'#0008', borderColor:'#0006', color:'#fff', marginLeft: 4}}>⏎</span>
          </span>
          <span className="hf-btn lg ghost">Skip</span>
          <span className="hf-btn lg danger icon">🗑</span>
        </div>
      </div>
    </div>
  );
}

// ============= 3 · Word Detail full-page (expanded sections) =============
function WordDetailFull() {
  return (
    <div className="hf" style={{display:'flex', flexDirection:'column'}}>
      <StudioHeader/>
      <div style={{flex:1, display:'flex', minHeight: 0}}>
        <Rail/>
        <div style={{flex:1, background: H.bgSurface, padding: 28,
          overflow:'auto', display:'flex', justifyContent:'center'}}>
          <div style={{width: '100%', maxWidth: 1100, display:'flex', flexDirection:'column', gap: 18}}>
            <Breadcrumb active="word"/>
            <div style={{display:'flex', alignItems:'center', gap: 12}}>
              <span style={{fontSize: 18, fontWeight: 700}}>Line 7 · Word 1</span>
              <span className="hf-pip" style={{background: H.mismatch+'1a', color: H.mismatch, border:`1px solid ${H.mismatch}55`}}>
                <span className="dot" style={{background: H.mismatch}}></span>mismatch · 42%
              </span>
              <span style={{fontSize: 12, color: H.ink3}}>"The"</span>
              <div style={{flex:1}}></div>
              <span style={{fontSize:11, color: H.ink3}}>1 of 7 in worklist</span>
              <span className="hf-btn">◀ Prev</span>
              <span className="hf-btn">Next ▶</span>
            </div>

            {/* word image with char bboxes hint */}
            <div style={{display:'flex', alignItems:'center', gap: 12}}>
              <span className="hf-label">Word image</span>
              <label style={{display:'inline-flex', alignItems:'center', gap: 6, fontSize: 11, color: H.ink2}}>
                <span style={{width: 24, height: 14, borderRadius: 7, background: H.exact, padding: 2,
                  display:'inline-flex'}}>
                  <span style={{width: 10, height: 10, borderRadius: 5, background:'#fff', marginLeft:'auto'}}></span>
                </span>
                char bboxes <span style={{color: H.ink3}}>· from OCR</span>
              </label>
              <span style={{fontSize: 10, color: H.ink3, fontStyle:'italic'}}>
                click a char bbox → opens Character Fixer
              </span>
            </div>
            <div style={{background:'#f5efdf', borderRadius: 8, border:`2px solid ${H.accent}`,
              padding:'28px 32px', position:'relative',
              display:'flex', alignItems:'flex-end', justifyContent:'center', gap: 0}}>
              {'The'.split('').map((ch, i) => (
                <div key={i} style={{display:'flex', flexDirection:'column', alignItems:'center', gap: 6, padding:'0 10px'}}>
                  <span style={{
                    display:'inline-flex', padding:'4px 6px',
                    border:`1.5px dashed ${H.word}88`, borderRadius: 2,
                  }}>
                    <span style={{fontFamily:'serif', fontSize: 92, color:'#1a140a', lineHeight: 1}}>{ch}</span>
                  </span>
                  <span style={{fontSize: 11, color:'#5c5448', fontFamily: H.mono}}>{i+1}</span>
                </div>
              ))}
            </div>

            {/* OCR / GT */}
            <div style={{display:'grid', gridTemplateColumns:'80px 1fr auto auto', rowGap: 10, columnGap: 12, alignItems:'center'}}>
              <span className="hf-label">OCR</span>
              <div className="hf-mono" style={{padding:'10px 14px', background: H.bgSunk, border:`1px solid ${H.border1}`,
                borderRadius: 6, fontSize: 15, color: H.ink2}}>tbe</div>
              <span className="hf-btn">OCR → GT</span>
              <span></span>
              <span className="hf-label">GT</span>
              <input className="hf-input lg" defaultValue="The" style={{width:'100%', fontSize: 16, height: 38}}/>
              <span className="hf-btn" style={{background: H.ocr+'1a', borderColor: H.ocr+'66', color: H.ocr}}>Ω chars ▾</span>
              <span></span>
            </div>

            {/* Unicode picker (expanded preview) */}
            <div style={{background: H.bgSunk, border:`1px solid ${H.ocr}55`, borderRadius: 8,
              padding: 16, display:'flex', flexDirection:'column', gap: 12}}>
              <div style={{display:'flex', alignItems:'center', gap: 10}}>
                <span style={{fontSize: 11, fontWeight: 700, color: H.ocr, letterSpacing:'0.05em'}}>Ω UNICODE CHARACTERS</span>
                <span style={{fontSize: 10, color: H.ink3}}>insert into GT at cursor</span>
                <div style={{flex:1}}></div>
                <span style={{fontSize: 10, color: H.ink3}}>
                  tip: type <span className="hf-mono" style={{background: H.bgRaised, padding:'1px 5px', borderRadius:3}}>\emdash</span> directly
                </span>
              </div>
              <div style={{display:'flex', alignItems:'center', gap: 6}}>
                <div style={{flex: 1, height: 30, padding:'0 12px',
                  background: H.bgRaised, border:`1px solid ${H.border2}`, borderRadius: 5,
                  display:'flex', alignItems:'center', gap: 8, fontSize: 12}}>
                  <span style={{color: H.ink3}}>⌕</span>
                  <span style={{flex: 1}}>em dash</span>
                  <span style={{fontSize: 10, color: H.ink3}}>4 results</span>
                </div>
              </div>
              <div style={{display:'flex', flexWrap:'wrap', gap: 4}}>
                <span className="hf-label">Sets</span>
                {['Quotes “”','Dashes – —','Ligatures ﬁ','Diacritics é','Historic ſ','Greek α','Math ≈','Punctuation ¶'].map((l, i) => (
                  <span key={i} className="hf-chip" style={i===1 ? {
                    background: H.ocr+'1a', color: H.ocr, borderColor: H.ocr+'55',
                  } : {}}>{l}</span>
                ))}
              </div>
              <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap: 6}}>
                {[
                  ['—','U+2014','EM DASH','\\emdash', true],
                  ['–','U+2013','EN DASH','\\endash'],
                  ['−','U+2212','MINUS SIGN','\\minus'],
                  ['‒','U+2012','FIGURE DASH','\\figdash'],
                ].map(([g, cp, name, hot, active], i) => (
                  <div key={i} style={{
                    display:'flex', alignItems:'center', gap: 10,
                    padding:'10px 12px', background: H.bgRaised,
                    border:`1px solid ${active ? H.ocr : H.border2}`,
                    borderRadius: 5,
                    boxShadow: active ? `0 0 0 1px ${H.ocr}55 inset` : 'none',
                  }}>
                    <span style={{fontFamily:'serif', fontSize: 30, color: H.ink1, width: 30, textAlign:'center'}}>{g}</span>
                    <div style={{display:'flex', flexDirection:'column', gap: 1, minWidth: 0}}>
                      <span style={{fontFamily: H.mono, fontSize: 10, color: H.ink3}}>{cp}</span>
                      <span style={{fontSize: 11, fontWeight: 600}}>{name}</span>
                      <span style={{fontFamily: H.mono, fontSize: 9, color: H.ink3}}>{hot}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Whole-word styles + components */}
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 14,
              padding: 16, background: H.bgSunk, borderRadius: 8, border:`1px solid ${H.border1}`}}>
              <div>
                <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom: 10}}>
                  <span style={{fontSize: 11, fontWeight: 700, color: H.ocr, letterSpacing:'0.05em'}}>STYLE</span>
                  <span style={{fontSize: 10, color: H.ink3}}>whole word</span>
                </div>
                <div style={{display:'flex', flexWrap:'wrap', gap: 6}}>
                  <ChipState label="small caps" hot="S" state="none"/>
                  <ChipState label="italic" hot="I" state="none"/>
                  <ChipState label="ALL CAPS" hot="C" state="none"/>
                  <ChipState label="blackletter" hot="B" state="none"/>
                </div>
                <details style={{marginTop: 8}}>
                  <summary style={{fontSize: 10.5, fontWeight: 600, color: H.ink3, cursor:'default'}}>
                    More · bold, super, sub, strike
                  </summary>
                </details>
              </div>
              <div>
                <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom: 10}}>
                  <span style={{fontSize: 11, fontWeight: 700, color: H.gt, letterSpacing:'0.05em'}}>COMPONENT</span>
                  <span style={{fontSize: 10, color: H.ink3}}>additive</span>
                </div>
                <div style={{display:'flex', flexWrap:'wrap', gap: 6}}>
                  <ChipState label="drop cap" state="none" kind="component"/>
                  <ChipState label="footnote marker" state="none" kind="component"/>
                </div>
              </div>
            </div>

            {/* Bounding box section */}
            <div className="hf-section">
              <div className="hf-section-h">
                <span className="l">BOUNDING BOX</span>
                <span className="sub">geometry of this word</span>
                <div style={{flex:1}}></div>
                <span style={{fontSize: 10, color: H.ink3, fontFamily: H.mono}}>x:124 y:418 · 92×54 px</span>
              </div>
              <div style={{display:'flex', gap: 6, flexWrap:'wrap'}}>
                <span className="hf-btn sm">Refine <span className="hf-key">F</span></span>
                <span className="hf-btn sm">Expand + Refine</span>
                <div style={{flex:1}}></div>
              </div>
              <div style={{display:'flex', gap: 6, alignItems:'center', flexWrap:'wrap'}}>
                <span className="hf-label" style={{minWidth: 40}}>Nudge</span>
                {['1','5','10'].map(s => (
                  <span key={s} className="hf-btn sm" style={{width: 22, padding: 0,
                    background: s==='5' ? H.ink1 : H.bgRaised, color: s==='5' ? H.bgPage : H.ink1,
                    borderColor: s==='5' ? H.ink1 : H.border2,
                  }}>{s}</span>
                ))}
                <span style={{fontSize: 10, color: H.ink3}}>px</span>
                <div style={{width: 1, height: 18, background: H.border1, margin:'0 4px'}}></div>
                {['L','R','T','B'].map(n => (
                  <div key={n} style={{display:'flex', gap: 2, alignItems:'center'}}>
                    <span style={{fontSize: 11, fontWeight: 600, width: 10}}>{n}</span>
                    <span className="hf-btn sm" style={{width: 22, padding: 0}}>−</span>
                    <span className="hf-btn sm" style={{width: 22, padding: 0}}>＋</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Rebox expanded preview */}
            <div className="hf-section" style={{background: H.accent+'08', borderColor: H.accent+'33'}}>
              <div className="hf-section-h">
                <span style={{fontSize: 10.5, fontWeight: 700, letterSpacing:'0.05em', color: H.accent}}>REBOX</span>
                <span className="sub">drag a new bbox on the zoomed region</span>
                <div style={{flex:1}}></div>
                <span className="hf-key">B</span>
              </div>
              <div style={{position:'relative', height: 240, background:'#08080c', borderRadius: 6, overflow:'hidden'}}>
                <div style={{
                  position:'absolute', inset:'24px 60px', background:'#f5efdf',
                  border:`1px solid ${H.border1}`,
                  display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                  gap: 14, padding:'18px 30px', fontFamily:'serif',
                }}>
                  <div style={{display:'flex', gap: 14, fontSize: 28, color:'#5c5448', opacity:0.65}}>
                    <span>A</span><span>HISTORY</span><span>OF</span>
                  </div>
                  <div style={{display:'flex', gap: 18, fontSize: 38, position:'relative', alignItems:'baseline', color:'#1a140a'}}>
                    <span>WOODROW</span>
                    <span style={{position:'relative'}}>
                      <span style={{fontVariant:'small-caps'}}>Mr.</span>Wilson,
                      <span style={{position:'absolute', left:-6, right:-3, top:-5, bottom:-5,
                        border:`1.5px dashed ${H.ink3}`, borderRadius: 2}}></span>
                    </span>
                    <span style={{fontVariant:'small-caps', fontSize: 28}}>Ph.D.,</span>
                    <div style={{position:'absolute', left:'30%', width:'24%', top:-12, bottom:-14,
                      border:`2.5px solid ${H.accent}`, background: H.accent+'15', borderRadius: 2}}>
                      {[[-4,-4,null],[-4,null,-4],[null,-4,-4],[null,null,-4,-4]].map((p, i) => {
                        const [t,l,b,r] = p; const st={};
                        if(t!=null)st.top=t; if(l!=null)st.left=l; if(b!=null)st.bottom=b; if(r!=null)st.right=r;
                        return <span key={i} style={{position:'absolute', ...st,
                          width: 8, height: 8, borderRadius: 1.5,
                          background:'#fff', border:`1.5px solid ${H.accent}`}}></span>;
                      })}
                    </div>
                  </div>
                </div>
                <div style={{position:'absolute', top: 8, left: 8, padding:'4px 8px',
                  background: H.bgPage, border:`1px solid ${H.border2}`, borderRadius: 5,
                  display:'flex', alignItems:'center', gap: 6, fontSize: 10, color: H.ink2}}>
                  <span style={{width: 22, height: 12, borderRadius: 6, background: H.exact, padding: 1,
                    display:'inline-flex'}}>
                    <span style={{width: 10, height: 10, borderRadius: 5, background:'#fff', marginLeft:'auto'}}></span>
                  </span>
                  <span style={{fontWeight: 600}}>Snap to source pixels</span>
                </div>
                <div style={{position:'absolute', top: 8, right: 8, display:'flex', gap: 3, padding: 3,
                  background: H.bgPage, border:`1px solid ${H.border2}`, borderRadius: 5}}>
                  <span className="hf-btn sm" style={{background: H.ink1, color: H.bgPage, borderColor: H.ink1, height: 22, padding:'0 8px', fontSize: 10}}>✎ Draw</span>
                  <span className="hf-btn ghost sm" style={{height: 22, padding:'0 8px', fontSize: 10}}>✋ Pan</span>
                </div>
                <div style={{position:'absolute', bottom: 8, left: '50%', transform:'translateX(-50%)',
                  display:'flex', alignItems:'center', gap: 3, padding: 3,
                  background: H.bgPage, border:`1px solid ${H.border2}`, borderRadius: 6}}>
                  <span className="hf-btn ghost sm icon" style={{width: 22, height: 22, fontSize: 11}}>−</span>
                  <span style={{fontFamily: H.mono, fontSize: 11, minWidth: 44, textAlign:'center'}}>320%</span>
                  <span className="hf-btn ghost sm icon" style={{width: 22, height: 22, fontSize: 11}}>＋</span>
                  <div style={{width: 1, height: 14, background: H.border2, margin:'0 3px'}}></div>
                  {['2×','5×','10×'].map(z => (
                    <span key={z} className="hf-btn sm" style={{height: 22, padding:'0 7px', fontSize: 10,
                      background: z==='5×' ? H.ink1 : H.bgRaised,
                      color: z==='5×' ? H.bgPage : H.ink1,
                      borderColor: z==='5×' ? H.ink1 : H.border2}}>{z}</span>
                  ))}
                </div>
              </div>
              <div style={{display:'flex', alignItems:'center', gap: 8, flexWrap:'wrap'}}>
                <span style={{display:'inline-flex', alignItems:'center', gap: 6, fontSize: 11}}>
                  <span style={{width: 24, height: 14, borderRadius: 7, background: H.exact, padding: 2,
                    display:'inline-flex'}}>
                    <span style={{width: 10, height: 10, borderRadius: 5, background:'#fff', marginLeft:'auto'}}></span>
                  </span>
                  <span style={{fontWeight: 600}}>Auto-refine on apply</span>
                </span>
                <div style={{flex:1}}></div>
                <span className="hf-btn ghost sm">Cancel</span>
                <span className="hf-btn primary sm">Apply rebox</span>
              </div>
            </div>

            {[
              ['ERASE PIXELS', 'brush · rect · lasso · auto-detect · 4 ops', 'X', H.mismatch],
              ['STRUCTURE', 'merge · split · neighbors', ''],
              ['CHAR RANGES', 'partial-word style or component', 'R'],
              ['CHARACTER FIXER', 'edit per-char bboxes · edge cases', ''],
            ].map(([l, sub, hot, accent], i) => (
              <div key={i} style={{
                display:'flex', alignItems:'center', gap: 10, padding:'12px 14px',
                background: accent ? accent+'0c' : H.bgSunk,
                border:`1px solid ${accent ? accent+'33' : H.border1}`, borderRadius: 6,
              }}>
                <span style={{width: 14, color: accent || H.ink2, fontSize: 11}}>▶</span>
                <span style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: accent || H.ink1}}>{l}</span>
                <span style={{fontSize: 10, color: H.ink3}}>{sub}</span>
                <div style={{flex:1}}></div>
                {hot && <span className="hf-key">{hot}</span>}
              </div>
            ))}

            <div style={{display:'flex', gap: 8, marginTop: 6}}>
              <span className="hf-btn primary lg" style={{flex: 1}}>
                ✓ Validate &amp; Next
                <span className="hf-key" style={{background:'#0008', borderColor:'#0006', color:'#fff', marginLeft: 4}}>⏎</span>
              </span>
              <span className="hf-btn lg ghost">Skip <span className="hf-key">␣</span></span>
              <span className="hf-btn lg danger">🗑 Delete word</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============= 4 · Line · Words tab =============
function LineWordsView() {
  return (
    <div className="hf" style={{display:'flex', flexDirection:'column'}}>
      <StudioHeader/>
      <div style={{flex:1, display:'flex', minHeight:0}}>
        <Rail activeTarget="Line"/>
        <Drawer view="worklist"/>
        <CanvasArea highlight="Line"/>
        <div style={{flex:'0 0 580px', width: 580, background: H.bgSurface,
          display:'flex', flexDirection:'column', minWidth: 0}}>
          <Breadcrumb active="line"/>
          <div style={{display:'flex', alignItems:'center', padding:'0 14px',
            borderBottom:`1px solid ${H.border1}`}}>
            <span className="hf-tab">▦ Line</span>
            <span className="hf-tab active">☷ Words <span className="count">5</span></span>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 10, color: H.ink3}}>
              <span className="hf-key">⇥</span> swap
            </span>
          </div>
          <BulkBar density="cards" selected={3} total={5}/>
          <div style={{padding:'4px 14px', fontSize: 10, color: H.ink3, background: H.bgPage,
            borderBottom: `1px solid ${H.border1}`, display:'flex', alignItems:'center', gap: 6}}>
            <span className="hf-label" style={{fontSize: 8.5}}>SCOPE</span>
            <span style={{color: H.ink2, fontWeight: 600}}>Line 4 (5 words)</span>
            <span style={{color: H.ink3}}>· grouped by line</span>
          </div>
          <div style={{flex: 1, overflow:'auto', padding: 12, background: H.bgPage}}>
            <WordCardGroupHi line={4} exact={3} fuzzy={2} miss={0}
              words={[
                {l:4,w:1,gt:'WOODROW',ocr:'WOODROW',s:'exact',sel:true,chips:['All Caps']},
                {l:4,w:2,gt:'WILSON,',ocr:'WILSON,',s:'exact',sel:true,chips:['All Caps']},
                {l:4,w:3,gt:'Ph.D.,',ocr:'PH.D.,',s:'fuzzy',sel:true,sc:true,chips:['Sm. Caps']},
                {l:4,w:4,gt:'Litt.D.,',ocr:'LITT.D.,',s:'fuzzy',sel:false,sc:true,chips:['Sm. Caps']},
                {l:4,w:5,gt:'LL.D.',ocr:'LL.D.',s:'exact',sel:false,chips:['All Caps']},
              ]}/>
          </div>
        </div>
      </div>
    </div>
  );
}

function BulkBar({ selected, total, extra, viewSegs }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 8, padding:'10px 14px',
      background: H.bgSurface, borderBottom:`1px solid ${H.border1}`,
    }}>
      <label style={{display:'inline-flex', alignItems:'center', gap: 6, fontSize: 11}}>
        <span style={{
          width: 14, height: 14, borderRadius: 3, background: selected===total ? H.ink1 : H.bgSunk,
          border:`1.5px solid ${selected ? H.ink1 : H.border3}`,
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 9, color: H.bgPage, fontWeight: 700,
        }}>
          {selected === total && total > 0 ? '✓' : selected > 0 ? '−' : ''}
        </span>
        <span style={{fontWeight: 600, color: H.ink1}}>{selected}</span>
        <span style={{color: H.ink3}}>of {total} selected</span>
      </label>
      <div style={{flex:1}}></div>
      <span className="hf-btn sm">✓ Validate</span>
      <span className="hf-btn sm">OCR → GT</span>
      <span className="hf-btn sm">Refine</span>
      <span className="hf-btn sm">Apply style…</span>
      {viewSegs && (
        <>
          <div style={{width:1, height:18, background: H.border1}}></div>
          {viewSegs}
        </>
      )}
      <div style={{width:1, height:18, background: H.border1}}></div>
      <div style={{display:'flex', alignItems:'center', gap: 4, fontSize: 10, color: H.ink3}}>
        <span>Density</span>
        <div style={{display:'flex', background: H.bgSunk, border:`1px solid ${H.border2}`, borderRadius: 4, padding: 1}}>
          <span style={{padding:'2px 8px', borderRadius: 3, fontSize: 10, fontWeight: 600,
            background: '#fff'+'00', color: H.ink1, backgroundColor: H.bgRaised}}>Cards</span>
          <span style={{padding:'2px 8px', fontSize: 10, color: H.ink3}}>Rows</span>
        </div>
      </div>
      <span className="hf-btn sm danger icon">🗑</span>
    </div>
  );
}

function WordCardGroupHi({ line, paraLabel, exact, fuzzy, miss, words }) {
  const selN = words.filter(w => w.sel).length;
  return (
    <div style={{
      background: H.bgSurface, border:`1px solid ${H.border1}`, borderRadius: 6,
      marginBottom: 10, overflow:'hidden',
    }}>
      <div style={{
        display:'flex', alignItems:'center', gap: 10, padding:'7px 10px',
        background: H.bgRaised, borderBottom:`1px solid ${H.border1}`,
      }}>
        <span style={{
          width: 14, height: 14, borderRadius: 3,
          background: selN === words.length ? H.ink1 : (selN > 0 ? H.bgRaised : H.bgSunk),
          border:`1.5px solid ${selN > 0 ? H.ink1 : H.border3}`,
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 9, color: H.bgPage, fontWeight: 700,
        }}>
          {selN === words.length ? '✓' : selN > 0 ? '−' : ''}
        </span>
        <span style={{
          padding:'2px 8px', borderRadius: 8, fontSize: 10, fontWeight: 600,
          background: H.line+'1a', color: H.line, border:`1px solid ${H.line}55`,
        }}>line {line}</span>
        {paraLabel && <span style={{fontSize: 10, color: H.ink3}}>{paraLabel}</span>}
        <span style={{fontSize: 10, color: H.ink3}}>{words.length} words</span>
        <div style={{display:'flex', gap: 8, fontSize: 10}}>
          <span style={{color: H.exact}}>✓{exact}</span>
          {fuzzy>0 && <span style={{color: H.fuzzy}}>~{fuzzy}</span>}
          {miss>0 && <span style={{color: H.mismatch}}>✗{miss}</span>}
        </div>
        <div style={{flex:1}}></div>
        <span style={{fontSize: 10, color: H.ink3}}>{selN} selected</span>
      </div>
      <div style={{display:'flex', gap: 8, padding: 10, overflowX:'auto', background: H.bgPage}}>
        {words.map((w, i) => (
          <WordCardHi key={i} word={w}/>
        ))}
      </div>
    </div>
  );
}

function WordCardHi({ word: w }) {
  return (
    <div style={{
      width: 140, flex:'0 0 auto',
      display:'flex', flexDirection:'column', gap: 4,
      padding: 8, borderRadius: 5,
      border: w.sel ? `1.5px solid ${H.accent}` : `1px solid ${H.border1}`,
      background: w.sel ? H.bgRaised : H.bgSurface,
    }}>
      <div style={{display:'flex', alignItems:'center', gap: 6, justifyContent:'space-between'}}>
        <div style={{display:'flex', alignItems:'center', gap: 5}}>
          <span style={{
            width: 13, height: 13, borderRadius: 3,
            background: w.sel ? H.ink1 : H.bgSunk,
            border:`1.5px solid ${w.sel ? H.ink1 : H.border3}`,
            display:'inline-flex', alignItems:'center', justifyContent:'center',
            fontSize: 9, color: H.bgPage, fontWeight: 700,
          }}>{w.sel ? '✓' : ''}</span>
          <span style={{fontSize: 9, color: H.ink3, fontFamily: H.mono}}>L{w.l}·W{w.w}</span>
        </div>
        <span className="hf-pip" style={{
          background: ({exact: H.exact, fuzzy: H.fuzzy, mismatch: H.mismatch})[w.s]+'1a',
          color: ({exact: H.exact, fuzzy: H.fuzzy, mismatch: H.mismatch})[w.s],
          border:`1px solid ${({exact: H.exact, fuzzy: H.fuzzy, mismatch: H.mismatch})[w.s]}55`,
        }}>
          <span className="dot" style={{background: ({exact: H.exact, fuzzy: H.fuzzy, mismatch: H.mismatch})[w.s]}}></span>
          {({exact:'✓',fuzzy:'~',mismatch:'✗'})[w.s]}
        </span>
      </div>
      <div style={{
        height: 38, background:'#f5efdf',
        border:`1px dashed ${H.border3}`, borderRadius: 3,
        display:'flex', alignItems:'center', justifyContent:'center',
        fontFamily:'serif', fontSize: w.sc ? 14 : 16,
        fontVariant: w.sc ? 'small-caps' : 'normal',
        color:'#1a140a',
      }}>{w.gt}</div>
      <div className="hf-mono" style={{
        fontSize: 10.5, color: H.ink3,
        padding:'2px 5px', background: H.bgSunk, borderRadius: 2,
        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
      }}>{w.ocr}</div>
      <div className="hf-mono" style={{
        fontSize: 10.5, color: H.ink1,
        padding:'3px 5px', background: H.bgPage,
        border:`1px solid ${w.sel ? H.accent : H.border2}`, borderRadius: 2,
        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
      }}>{w.gt}</div>
      {w.chips && (
        <div style={{display:'flex', flexWrap:'wrap', gap: 3}}>
          {w.chips.map((c, i) => (
            <span key={i} className="hf-chip" style={{fontSize: 9, height: 15, padding:'0 5px'}}>{c}</span>
          ))}
        </div>
      )}
    </div>
  );
}

// ============= 5 · Block · Items · Words =============
function BlockItemsView() {
  return (
    <div className="hf" style={{display:'flex', flexDirection:'column'}}>
      <StudioHeader/>
      <div style={{flex:1, display:'flex', minHeight: 0}}>
        <Rail activeTarget="Block"/>
        <Drawer view="hierarchy"/>
        <CanvasArea highlight="Block"/>
        <div style={{flex:'0 0 640px', width: 640, background: H.bgSurface,
          display:'flex', flexDirection:'column', minWidth: 0}}>
          <Breadcrumb active="block"/>
          <div style={{display:'flex', alignItems:'center', padding:'0 14px',
            borderBottom:`1px solid ${H.border1}`}}>
            <span className="hf-tab">⊞ Layout</span>
            <span className="hf-tab active">☷ Items <span className="count">40</span></span>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 10, color: H.ink3}}>
              <span className="hf-key">⇥</span> swap
            </span>
          </div>
          <BulkBar selected={2} total={26}
            viewSegs={
              <div style={{display:'flex', alignItems:'center', gap: 4, fontSize: 10, color: H.ink3}}>
                <span>View</span>
                <div style={{display:'flex', background: H.bgSunk, border:`1px solid ${H.border2}`, borderRadius: 4, padding: 1}}>
                  <span style={{padding:'2px 8px', fontSize: 10, color: H.ink3}}>Blocks</span>
                  <span style={{padding:'2px 8px', fontSize: 10, color: H.ink3}}>¶</span>
                  <span style={{padding:'2px 8px', fontSize: 10, color: H.ink3}}>Lines</span>
                  <span style={{padding:'2px 8px', borderRadius: 3, background: H.bgRaised,
                    color: H.ink1, fontSize: 10, fontWeight: 600}}>Words</span>
                </div>
              </div>
            }/>
          <div style={{padding:'4px 14px', fontSize: 10, color: H.ink3, background: H.bgPage,
            borderBottom:`1px solid ${H.border1}`, display:'flex', alignItems:'center', gap: 6}}>
            <span className="hf-label" style={{fontSize: 8.5}}>SCOPE</span>
            <span style={{color: H.ink2, fontWeight: 600}}>Block quote (2 paragraphs · 6 lines · 26 words)</span>
            <span style={{color: H.ink3}}>· grouped by line</span>
          </div>
          <div style={{flex: 1, overflow:'auto', padding: 12, background: H.bgPage}}>
            <WordCardGroupHi line={1} paraLabel="¶ #1 · body text (within block quote)" exact={5} fuzzy={0} miss={0}
              words={[
                {l:1,w:1,gt:'"I',ocr:'"I',s:'exact',sel:false},
                {l:1,w:2,gt:'have',ocr:'have',s:'exact',sel:false},
                {l:1,w:3,gt:'no',ocr:'no',s:'exact',sel:false},
                {l:1,w:4,gt:'purpose',ocr:'purpose',s:'exact',sel:false},
                {l:1,w:5,gt:'but',ocr:'but',s:'exact',sel:false},
              ]}/>
            <WordCardGroupHi line={2} exact={4} fuzzy={1} miss={0}
              words={[
                {l:2,w:1,gt:'to',ocr:'to',s:'exact',sel:false},
                {l:2,w:2,gt:'serve',ocr:'serve',s:'exact',sel:false},
                {l:2,w:3,gt:'the',ocr:'the',s:'exact',sel:false},
                {l:2,w:4,gt:'present',ocr:'pre$ent',s:'fuzzy',sel:true,chips:['Italic']},
                {l:2,w:5,gt:'age,',ocr:'age,',s:'exact',sel:false},
              ]}/>
            <WordCardGroupHi line={3} exact={4} fuzzy={0} miss={0}
              words={[
                {l:3,w:1,gt:'my',ocr:'my',s:'exact',sel:false},
                {l:3,w:2,gt:'calling',ocr:'calling',s:'exact',sel:false},
                {l:3,w:3,gt:'to',ocr:'to',s:'exact',sel:false},
                {l:3,w:4,gt:'fulfill;',ocr:'fulfill;',s:'exact',sel:false},
              ]}/>
            <WordCardGroupHi line={4} paraLabel="¶ #2 · body text (within block quote)" exact={5} fuzzy={1} miss={0}
              words={[
                {l:4,w:1,gt:'O',ocr:'O',s:'exact',sel:false},
                {l:4,w:2,gt:'may',ocr:'may',s:'exact',sel:false},
                {l:4,w:3,gt:'it',ocr:'it',s:'exact',sel:false},
                {l:4,w:4,gt:'all',ocr:'all',s:'exact',sel:false},
                {l:4,w:5,gt:'my',ocr:'mv',s:'fuzzy',sel:true},
                {l:4,w:6,gt:'powers',ocr:'powers',s:'exact',sel:false},
              ]}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============= 6 · Block · Layout =============
function BlockLayoutView() {
  const types = {
    Structural: ['body (main)','column','sidebar','header band','footer band','footnote band','marginalia','figure region','table region'],
    Content: ['body text','chapter heading','section heading','title','byline','block quote','epigraph','list','caption','footnote'],
  };
  return (
    <div className="hf" style={{display:'flex', flexDirection:'column'}}>
      <StudioHeader/>
      <div style={{flex:1, display:'flex', minHeight: 0}}>
        <Rail activeTarget="Block"/>
        <Drawer view="hierarchy"/>
        <CanvasArea highlight="Block"/>
        <div style={{flex:'0 0 640px', width: 640, background: H.bgSurface,
          display:'flex', flexDirection:'column', minWidth: 0}}>
          <Breadcrumb active="block"/>
          <div style={{display:'flex', alignItems:'center', padding:'0 14px',
            borderBottom:`1px solid ${H.border1}`}}>
            <span className="hf-tab active">⊞ Layout</span>
            <span className="hf-tab">☷ Items <span className="count">40</span></span>
            <div style={{flex:1}}></div>
          </div>
          <div style={{flex: 1, overflow:'auto', padding: 16,
            display:'flex', flexDirection:'column', gap: 14}}>
            <div style={{display:'flex', alignItems:'center', gap: 10}}>
              <span style={{fontSize: 13, fontWeight: 700}}>Block quote · layout type</span>
              <span style={{padding:'2px 8px', borderRadius: 9, fontSize: 10, fontWeight: 600,
                background: H.block+'1a', color: H.block, border:`1px solid ${H.block}55`}}>
                structural · 2 children
              </span>
              <div style={{flex:1}}></div>
              <input className="hf-input" placeholder="Search…" style={{width: 160, fontSize: 11, height: 26}}/>
            </div>
            {/* preview */}
            <div style={{background:'#f5efdf', border:`1.5px solid ${H.block}`, borderRadius: 6,
              padding: 16, position:'relative',
              fontFamily:'serif', fontSize: 14, color:'#3a3026', lineHeight: 1.5,
            }}>
              <span style={{position:'absolute', top: -9, left: 12, padding:'0 6px',
                background: H.bgSurface, fontSize: 9, fontWeight: 700, letterSpacing:'0.05em',
                color: H.block}}>BLOCK · structural</span>
              <span style={{fontStyle:'italic', paddingLeft: 16, borderLeft:`2px solid ${H.border3}`}}>
                "I have no purpose but to serve the present age, my calling to fulfill;
                O may it all my powers engage to do my Master's will." — two paragraphs of extended verse.
              </span>
            </div>
            {/* model suggest */}
            <div style={{display:'flex', alignItems:'center', gap: 10,
              padding:'10px 12px', background: H.fuzzy+'12',
              border:`1px solid ${H.fuzzy}55`, borderRadius: 6}}>
              <span style={{width: 24, height: 24, borderRadius: 12, background: H.fuzzy, color:'#1a0f08',
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                fontSize: 13, fontWeight: 700}}>?</span>
              <span style={{fontSize: 12}}>
                Model suggests <b style={{color: H.ink1}}>block quote</b> · 71% confidence
              </span>
              <div style={{flex:1}}></div>
              <span className="hf-btn sm primary">Accept ⏎</span>
              <span className="hf-btn sm">Reject</span>
            </div>
            {/* groups */}
            {Object.entries(types).map(([g, labels]) => (
              <div key={g}>
                <div style={{
                  fontSize: 9, fontWeight: 700, letterSpacing:'0.12em',
                  color: H.ink3, marginBottom: 8,
                  display:'flex', alignItems:'center', gap: 8,
                }}>
                  {g.toUpperCase()}
                  <span style={{flex:1, height: 1, background: H.border1}}></span>
                  <span style={{fontWeight: 500, color: H.ink4, letterSpacing: 0}}>
                    {g === 'Structural' ? 'typically contains other blocks' : 'typically a leaf (paragraph)'}
                  </span>
                </div>
                <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(130px, 1fr))', gap: 6}}>
                  {labels.map(l => {
                    const a = l === 'block quote';
                    return (
                      <div key={l} style={{
                        padding: 10, borderRadius: 5,
                        background: a ? H.accent+'12' : H.bgSunk,
                        border: a ? `1.5px solid ${H.accent}` : `1px solid ${H.border1}`,
                        display:'flex', flexDirection:'column', gap: 6,
                        position:'relative',
                      }}>
                        <div style={{height: 28, background: H.bgRaised, border:`1px solid ${H.border1}`, borderRadius: 3}}></div>
                        <span style={{fontSize: 11, fontWeight: 600, color: a ? H.ink1 : H.ink2,
                          whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{l}</span>
                        {a && (
                          <span style={{position:'absolute', top: 6, right: 6,
                            width: 14, height: 14, borderRadius: 7, background: H.accent, color:'#1a0f08',
                            display:'inline-flex', alignItems:'center', justifyContent:'center',
                            fontSize: 9, fontWeight: 700}}>✓</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
            <div style={{marginTop: 'auto', display:'flex', gap: 8, paddingTop: 8}}>
              <span className="hf-btn primary lg" style={{flex: 1}}>✓ Save layout type</span>
              <span className="hf-btn lg ghost">Skip</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============= top picker + stage =============
const VIEWS = [
  { k:'studio',     label:'1 · Studio',        Comp: StudioView },
  { k:'word',       label:'2 · Word · Detail (full)', Comp: WordDetailFull },
  { k:'line-words', label:'3 · Line · Words',  Comp: LineWordsView },
  { k:'block-items',label:'4 · Block · Items · Words', Comp: BlockItemsView },
  { k:'block-layout',label:'5 · Block · Layout', Comp: BlockLayoutView },
];

function ScaledStage({ children, width=1920, height=1200 }) {
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const fit = () => {
      const sx = window.innerWidth / width;
      const sy = (window.innerHeight - 44) / height;
      setScale(Math.min(sx, sy));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div style={{
      width:'100%', flex: 1,
      display:'flex', alignItems:'center', justifyContent:'center',
      background:'#000', overflow:'hidden',
    }}>
      <div style={{width, height,
        transform:`scale(${scale})`, transformOrigin:'center center',
        boxShadow: '0 30px 80px rgba(0,0,0,0.8)'}}>
        {children}
      </div>
    </div>
  );
}

function App() {
  const [view, setView] = React.useState(() => {
    return window.location.hash.replace('#','') || 'studio';
  });
  React.useEffect(() => {
    const onHash = () => setView(window.location.hash.replace('#','') || 'studio');
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const Cur = (VIEWS.find(v => v.k === view) || VIEWS[0]).Comp;
  return (
    <div style={{height:'100vh', display:'flex', flexDirection:'column', background:'#000'}}>
      <div style={{height: 44, flex:'0 0 44px',
        background: H.bgPage, borderBottom:`1px solid ${H.border1}`,
        display:'flex', alignItems:'center', padding:'0 12px', gap: 4,
      }}>
        <span style={{fontSize: 12, color: H.ink3, fontWeight: 600, marginRight: 8, letterSpacing:'0.05em'}}>HI-FI VIEW</span>
        {VIEWS.map(v => (
          <a key={v.k} href={`#${v.k}`} onClick={() => setView(v.k)} style={{
            padding:'7px 12px', borderRadius: 5,
            background: v.k === view ? H.bgRaised : 'transparent',
            border: v.k === view ? `1px solid ${H.border3}` : '1px solid transparent',
            color: v.k === view ? H.ink1 : H.ink2,
            fontSize: 12, fontWeight: 500, textDecoration:'none', cursor:'pointer',
          }}>{v.label}</a>
        ))}
        <div style={{flex:1}}></div>
        <span style={{fontSize: 10, color: H.ink3}}>scaled to fit · 1920×1200 reference</span>
      </div>
      <ScaledStage>
        <Cur/>
      </ScaledStage>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
