# OCR Labeler · Design Handoff

This bundle contains **two parallel design surfaces** — read both. They cover different things:

## What's in the bundle

### `hifi.html` + `hifi-projectpage.jsx` — hi-fi pass (5 views)

Pixel-accurate visual reference for the dark theme, color system, typography, and component primitives. 5 views accessible from the top tab strip:

1. **Studio** — full ProjectPage (header + rail + drawer + canvas + right panel)
2. **Word · Detail (full)** — focused word editor with **Unicode picker expanded** and **Rebox accordion expanded** showing the inline zoomed canvas pattern. Per-character bboxes visible on the word zoom.
3. **Line · Words** — bulk-edit cards grouped by line, density toggle
4. **Block · Items · Words** — bulk-edit cards across a structural block (block-quote with 2 child paragraphs surfaced as group sublabels)
5. **Block · Layout** — type picker with grouped Structural / Content cards + model-suggest callout

Use this as the **visual + interaction reference**.

### `wireframes/` — full wireframe set (everything else)

The hi-fi pass deliberately covers the most important 5 surfaces in detail. The wireframe set covers **everything else** — about 30 artboards spanning every screen, dialog, and detail:

- **All right-panel states** at every level (matches, word, line detail/words, paragraph layout/items, block layout/items, structural block · items · words view)
- **Drawer states** — worklist open, hierarchy open, both collapsed variants
- **Word Detail editor — every section expanded** (Bounding Box, Rebox, Erase Pixels [brush/rect/lasso/auto-detect with pixel snapping], Structure [neighbors + merge previews + split + nested vertical split], Char Ranges [multi-range editor with overlap markers], Character Fixer [full edit grid + per-char detail])
- **Bulk action explorations** (chip palettes, inspector chips, char-range picker variants, keyboard-first flow)
- **Page hierarchy tree (full view)** — referenced from the drawer
- **Canvas overlay reference** — how blocks render with nesting depth
- **Breadcrumb behavior** — 4 nesting scenarios including deep-nesting overflow
- **Style tile** — the original tokens
- **RootPage** — project picker
- **Hotkey overlay** — `⌘/` cheatsheet
- **Toast / progress stack** — error / success / progress patterns

Open `wireframes/wireframes.html`. It renders a pan-zoom canvas with all artboards organized top-down: Page+Block → Paragraph → Line → Word → Supporting.

Use this as the **completeness reference** — when a detail isn't in the hi-fi, look here.

### `DESIGN_LANGUAGE.md`

Tokens distilled from the hi-fi. Copy this into the app's token layer first.

### `IMPLEMENTATION_PROMPT.md`

Starting prompt for Claude Code with build order and behavioral notes.

## How to use this bundle

1. **Read** `DESIGN_LANGUAGE.md` end-to-end. The color semantics are load-bearing.
2. **Browse** `hifi.html` and click through the 5 view tabs to see the visual target.
3. **Browse** `wireframes/wireframes.html` to see every other surface — drag to pan, scroll to zoom; click an artboard label to open it fullscreen.
4. **Hand off** by giving Claude Code this folder + the prompt in `IMPLEMENTATION_PROMPT.md`.

## File index

| File                                | What                                                  |
|-------------------------------------|-------------------------------------------------------|
| `hifi.html`                         | Hi-fi entry point                                     |
| `hifi-projectpage.jsx`              | All hi-fi components in one file                      |
| `DESIGN_LANGUAGE.md`                | Reusable tokens                                       |
| `IMPLEMENTATION_PROMPT.md`          | Starting prompt for Claude Code                       |
| `wireframes/wireframes.html`        | Wireframe entry point                                 |
| `wireframes/app.jsx`                | Wireframe canvas wiring                               |
| `wireframes/hybrid-variants.jsx`    | ProjectPage N1–N5 (with current rail + drawer + tabs) |
| `wireframes/tabbed-panels.jsx`      | Right-panel tabbed editors + bulk word view + density |
| `wireframes/picker-consolidated.jsx`| **Word Detail editor — full version** (all sections)  |
| `wireframes/block-layout-system.jsx`| Block enum, tree, breadcrumb, block pickers, overlays |
| `wireframes/sketch-primitives.jsx`  | Wireframe tokens, status pip, word cell, page scan    |
| `wireframes/extras.jsx`             | RootPage, hotkey overlay, toast stack, style tile     |
| `wireframes/projectpage-variants.jsx`| Earlier ProjectPage explorations (V1–V5) — reference |
| `wireframes/dialog-variants.jsx`    | Earlier word-edit-dialog variants — reference         |
| `wireframes/bulk-actions-explorations.jsx`| Bulk-action exploration — reference             |
| `wireframes/design-canvas.jsx`      | Pan/zoom canvas vendor wrapper                        |

## Fidelity by surface

| Surface                    | Hi-fi here? | Wireframe here? |
|----------------------------|:-----------:|:---------------:|
| Studio shell               | ✓           | ✓               |
| Word Detail editor         | partial     | **full**        |
| Line panel (both tabs)     | Words only  | both            |
| Paragraph panel            | —           | both            |
| Block panel (both tabs)    | both        | both            |
| Bulk word actions          | inline      | dedicated       |
| Char range multi-edit      | —           | **full**        |
| Character Fixer            | —           | **full**        |
| Rebox accordion            | ✓           | ✓               |
| Erase Pixels accordion     | —           | **full** (with auto-detect, brush, rect, lasso) |
| Unicode picker             | ✓           | ✓               |
| Page hierarchy tree        | drawer only | dedicated full  |
| Canvas overlay reference   | —           | ✓               |
| Breadcrumb behavior        | inline      | dedicated demo  |
| RootPage / project picker  | —           | ✓               |
| Hotkey overlay             | —           | ✓               |
| Toast stack                | —           | ✓               |
| Style tile                 | —           | ✓               |

Where "—" or "partial" in the hi-fi column, **use the wireframe version** as the spec and apply the hi-fi color/type system on top.
