# Claude Code · implementation prompt

## Goal

Recreate the OCR Labeler ProjectPage redesign in our existing codebase. The bundle in this folder is a **hi-fi prototype in HTML + inline JSX** — use it as the visual + behavioral reference, but implement using the codebase's actual framework, component library, and conventions.

## What's in the bundle

- `hifi.html` — entry point. Open it in a browser to navigate 5 hi-fi views via the top tab strip (or via URL hash: `#studio`, `#word`, `#line-words`, `#block-items`, `#block-layout`).
- `hifi-projectpage.jsx` — all components, all design tokens, all CSS, in one file. Babel-transpiled in browser.
- `DESIGN_LANGUAGE.md` — distilled color / type / spacing / component tokens to reuse anywhere in the app.

## Implementation expectations

### Fidelity

**High** for layout, spacing, density, color, typography, interaction. Match the prototype closely. The dark theme + warm-amber accent + four-layer color system are intentional and tested through several rounds with the user. Don't reinvent.

### Stack

Use whatever the codebase uses. Do **not** ship the HTML/JSX from the bundle directly. Reimplement using existing component primitives (buttons, chips, dialogs, accordions, tabs).

If no design system exists yet, copy the tokens from `DESIGN_LANGUAGE.md` into a `tokens.{ts,css}` file at the start, then build the primitives once and reuse.

### Scope priorities

Build in this order:

1. **Design tokens** — copy `DESIGN_LANGUAGE.md` values into the app's token layer first.
2. **Studio shell** — Header + Rail + Drawer + Canvas + Right Panel. Drawer should toggle between Worklist and Hierarchy.
3. **Breadcrumb** — shared across all right-panel views. Clickable segments. Keyboard `⌥↑/↓/←/→` walks tree.
4. **Word Detail editor** (`#word` view) — the densest screen; deserves a focused implementation phase. All sections (Bounding Box, Rebox, Erase, Structure, Char Ranges, Character Fixer) should ship as collapsible accordions with the patterns shown.
5. **Line · Words** — bulk-edit cards grouped by line.
6. **Block · Items · Words** — same component as line, but groups span paragraphs within the block (paragraph label appears on first line of each child paragraph).
7. **Block · Layout** — layout-type picker with model-suggest callout.

### Behavior to preserve

- **Theme** — the app supports both **dark and light modes**. Default dark, respect `prefers-color-scheme` on first run, persist user toggle to localStorage. Expose toggle in user menu (top-right avatar) and Settings. Every surface must render correctly in both modes; tokens drive the swap (see `DESIGN_LANGUAGE.md`).
- **Selection target on rail** governs canvas drag-select scope. `1/2/3` keys cycle Block / Line / Word.
- **Right panel adapts** to whatever is selected. Word = single Detail editor (no tabs). Line = tabs (Line / Words). Block = tabs (Layout / Items).
- **Worklist filter chips** drive both the queue and the bulk actions.
- **Hierarchy drawer** is an alternative to Worklist — same drawer slot.
- **Density toggle (Cards | Rows)** in bulk views — persist per scope.
- **View segmented picker** in bulk views — at line scope no picker (always Words); at paragraph scope `Lines | Words`; at column / structural-block scope `Paragraphs | Lines | Words`; at body `Blocks | Paragraphs | Lines | Words`. Default to deepest.
- **Status pips** — green / amber / red for exact / fuzzy / mismatch.
- **Layer colors** — taupe block, green paragraph, pink line, blue word. Always.
- **Tri-state chips** in style/component pickers — none / some / all for the current selection. Conflict styles (italic vs blackletter) dim and strike-through when the other is active.
- **Hotkeys everywhere** — show key caps next to affordances.

### Data model

A page is a tree of blocks. A block contains other blocks OR lines. A leaf block whose children are lines is what users call a **paragraph** — it's emergent, not a separate type. Every block carries a single layout type from a shared enum used at every depth.

A word has: bbox, ocr text, gt text, status, `chars[]` for per-character segmentation (optional), and `ranges[]` for partial-word styles and components.

See `DESIGN_LANGUAGE.md` for the full enum list (Structural and Content groups).

### What's NOT in the prototype

- No real OCR backend — wire to the labeler's existing project storage.
- No real page scans — render the actual TIFF/JPG behind the overlays.
- No real model — the "Auto-detect" and "Model suggests…" callouts are placeholders for whatever segmentation + classification pipeline is in place.
- Mouse-driven canvas interactions (drag-select, draw, lasso, etc.) are sketched but not wired. Real implementation needs hit-testing and bbox math against the actual scan resolution.
- Per-character bbox editing (Character Fixer) is sketched but real implementation needs OCR's character-level output exposed through the project API.

## Starting prompt for Claude Code

> I'm implementing a redesign of the OCR Labeler app. The folder `design_handoff_hifi/` contains an HTML+JSX prototype showing the target design at high fidelity, plus a `DESIGN_LANGUAGE.md` with the full token set. The prototype renders 5 views from a top tab strip — start by opening `hifi.html` in a browser to see them all.
>
> Implement this redesign in our existing codebase. Don't ship the prototype HTML directly; recreate it using our component patterns. Start by copying the design tokens from `DESIGN_LANGUAGE.md` into our token layer, then build the Studio shell (header + rail + drawer + canvas + right panel). Once the shell is rendering, build the Word Detail editor as the next milestone — it's the densest screen and exercises most of the primitives.
>
> See `IMPLEMENTATION_PROMPT.md` (this file) for the build order and behavioral notes. Read `DESIGN_LANGUAGE.md` end-to-end before writing any code; the color and layer semantics are load-bearing.

## Questions to expect

- "What's our existing token layer?" — point Claude Code at it.
- "Where does the page-scan image come from?" — the project's storage. Stub if needed.
- "What replaces JetBrains Mono?" — the **PGDP custom monospace** font. The user has the file; surface a TODO if it's not in the bundle.
- "Should I implement the model-suggest callouts?" — leave as stubs that show 100% confidence, wire to the real model later.
