// Consolidated word & paragraph pickers — after round-2 feedback.
//
// • Styles ordered by frequency: small caps + italic primary, then less common.
// • Components: drop cap + footnote marker primary, no more chapter_start/end.
// • Char-range picker (V3-A character cells) lives inside the detail word
//   editor, collapsible accordion.
// • Canvas badges (V4) ride along.
// • NEW: paragraph/block layout-type picker feeding a separate classifier
//   model. Exclusive (single primary type per paragraph) but extensible.

const STYLE_LIST = [
  // primary
  {k:'smcaps',     l:'small caps',  hot:'S', tier:1},
  {k:'italic',     l:'italic',      hot:'I', tier:1, conflicts:['blackletter']},
  // secondary
  {k:'allcaps',    l:'ALL CAPS',    hot:'C', tier:2},
  {k:'blackletter',l:'blackletter', hot:'B', tier:2, conflicts:['italic']},
  // rare
  {k:'bold',       l:'bold',        hot:'D', tier:3},
  {k:'super',      l:'super',       hot:'⇧6', tier:3},
  {k:'sub',        l:'sub',         hot:'⇧-', tier:3},
  {k:'strike',     l:'strike',      hot:'⇧X', tier:3},
];

const COMPONENT_LIST = [
  {k:'dropcap',    l:'drop cap',         tier:1},
  {k:'footnote',   l:'footnote marker',  tier:1},
  {k:'catchword',  l:'catchword',        tier:2},
  {k:'marginalia', l:'marginalia',       tier:2},
  {k:'signature',  l:'signature mark',   tier:3},
  {k:'runhead',    l:'running header',   tier:3},
];

// Paragraph / block layout types. Drives a separate classifier.
// Grouped by structural role.
const LAYOUT_TYPES = [
  // headings
  {g:'Heading',   k:'chap_head',   l:'chapter heading',   shape:'h1', tier:1},
  {g:'Heading',   k:'sec_head',    l:'section heading',   shape:'h2', tier:1},
  {g:'Heading',   k:'sub_head',    l:'subsection heading',shape:'h3', tier:2},
  {g:'Heading',   k:'title',       l:'title',             shape:'title', tier:2},
  {g:'Heading',   k:'subtitle',    l:'subtitle',          shape:'subtitle', tier:3},
  {g:'Heading',   k:'byline',      l:'byline / author',   shape:'byline', tier:3},
  // body
  {g:'Body',      k:'body',        l:'body text',         shape:'body', tier:1, defaultType:true},
  {g:'Body',      k:'blockquote',  l:'block quote',       shape:'quote', tier:2},
  {g:'Body',      k:'epigraph',    l:'epigraph',          shape:'epigraph', tier:3},
  {g:'Body',      k:'list',        l:'list',              shape:'list', tier:2},
  {g:'Body',      k:'verse',       l:'verse / poem',      shape:'verse', tier:3},
  // apparatus
  {g:'Apparatus', k:'footnote_blk',l:'footnote block',    shape:'footnote', tier:2},
  {g:'Apparatus', k:'caption',     l:'figure / table caption', shape:'caption', tier:2},
  {g:'Apparatus', k:'table',       l:'table',             shape:'table', tier:3},
  {g:'Apparatus', k:'header',      l:'running header',    shape:'rhead', tier:2},
  {g:'Apparatus', k:'footer',      l:'footer / page no.', shape:'rfoot', tier:2},
  // front/back matter
  {g:'Matter',    k:'toc',         l:'table of contents', shape:'toc', tier:3},
  {g:'Matter',    k:'dedication',  l:'dedication',        shape:'dedication', tier:3},
  {g:'Matter',    k:'index',       l:'index entry',       shape:'index', tier:3},
];

// =====================================================================
// Final tri-state chip (slimmed down from prior StateChip)
// =====================================================================
function PickerChip({ label, hot, state='none', conflict, kind='style', big }) {
  const base = kind === 'style' ? W.ocrOnly : W.gtOnly;
  const cMap = {
    none: { bg: W.panel,     fg: W.ink2,   bd: W.ink4 },
    some: { bg: W.panel,     fg: base,     bd: base },
    all:  { bg: base + '1a', fg: base,     bd: base },
  };
  const c = cMap[state];
  return (
    <div style={{
      display:'inline-flex', alignItems:'center', gap: 6,
      height: big ? 30 : 26, padding: big ? '0 10px 0 8px' : '0 9px 0 7px',
      background: c.bg,
      border: `1.5px solid ${c.bd}`,
      borderRadius: 14,
      fontSize: big ? 12 : 11, fontWeight: 600,
      color: c.fg,
      opacity: conflict ? 0.42 : 1,
      textDecoration: conflict ? 'line-through' : 'none',
    }}>
      <span style={{
        width: 13, height: 13, borderRadius: 7,
        background: state === 'all' ? base : 'transparent',
        border: `1.5px solid ${state === 'none' ? W.ink4 : base}`,
        backgroundImage: state === 'some'
          ? `repeating-linear-gradient(45deg, ${base} 0 2px, transparent 2px 4px)`
          : 'none',
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontSize: 8, color: '#fff', fontWeight: 700,
      }}>
        {state === 'all' ? '✓' : ''}
      </span>
      <span style={{
        fontStyle: label === 'italic' ? 'italic' : 'normal',
        fontVariant: label === 'small caps' ? 'small-caps' : 'normal',
        fontWeight: label === 'bold' ? 700 : 600,
      }}>{label}</span>
      {hot && (
        <span className="wf-key" style={{
          height: 14, minWidth: 14, fontSize: 9, marginLeft: 2, opacity: 0.7,
        }}>{hot}</span>
      )}
    </div>
  );
}

// =====================================================================
// FINAL · Bulk word picker (slimmed style/component sets, tiered)
// =====================================================================
function FinalBulkPicker() {
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'hidden'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Final · Bulk word picker</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Slimmed enum, ordered by frequency. Common above the fold;
          rare ones in a "more" expander. Conflict styles dim &amp; strike.
        </div>
      </header>

      <SelectionSummary count={3} items={['Ph.D.,', 'Litt.D.,', 'LL.D.']} line={4} para={4}/>

      <div style={{
        marginTop: 14, background: W.panel,
        border: `1px solid ${W.rule}`, borderRadius: 6, padding: 14,
        display:'flex', flexDirection:'column', gap: 14,
      }}>
        {/* STYLE */}
        <div>
          <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom: 8,
            paddingBottom: 6, borderBottom: `1px solid ${W.ruleSoft}`,
          }}>
            <span style={{fontSize: 12, fontWeight: 700}}>Style</span>
            <span style={{fontSize: 10, color: W.ink3}}>typographic · whole word in bulk</span>
          </div>
          {/* primary tier */}
          <div style={{display:'flex', gap: 6, flexWrap: 'wrap', marginBottom: 6}}>
            <PickerChip label="small caps" hot="S" state="all" big/>
            <PickerChip label="italic"     hot="I" state="none" big conflict/>
          </div>
          {/* secondary */}
          <div style={{display:'flex', gap: 6, flexWrap: 'wrap', marginBottom: 6}}>
            <PickerChip label="ALL CAPS"    hot="C" state="none"/>
            <PickerChip label="blackletter" hot="B" state="some"/>
          </div>
          {/* rare — expander */}
          <details style={{
            background: W.paperAlt, border: `1px dashed ${W.ink4}`,
            borderRadius: 4, padding: '6px 10px', marginTop: 4,
          }}>
            <summary style={{fontSize: 11, fontWeight: 600, color: W.ink2, cursor:'default'}}>
              More · bold, super, sub, strike
            </summary>
            <div style={{display:'flex', gap: 6, flexWrap:'wrap', marginTop: 8}}>
              <PickerChip label="bold" hot="D" state="none"/>
              <PickerChip label="super" hot="⇧6" state="none"/>
              <PickerChip label="sub" hot="⇧-" state="none"/>
              <PickerChip label="strike" hot="⇧X" state="none"/>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3, height:26, padding:'0 9px', fontSize:11}}>+ custom…</span>
            </div>
          </details>
        </div>

        {/* COMPONENT */}
        <div>
          <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom: 8,
            paddingBottom: 6, borderBottom: `1px solid ${W.ruleSoft}`,
          }}>
            <span style={{fontSize: 12, fontWeight: 700}}>Component</span>
            <span style={{fontSize: 10, color: W.ink3}}>structural role · additive</span>
          </div>
          <div style={{display:'flex', gap: 6, flexWrap: 'wrap', marginBottom: 6}}>
            <PickerChip label="drop cap"        kind="component" state="none" big/>
            <PickerChip label="footnote marker" kind="component" state="none" big/>
          </div>
          <details style={{
            background: W.paperAlt, border: `1px dashed ${W.ink4}`,
            borderRadius: 4, padding: '6px 10px', marginTop: 4,
          }}>
            <summary style={{fontSize: 11, fontWeight: 600, color: W.ink2, cursor:'default'}}>
              More · catchword, marginalia, running header, signature mark
            </summary>
            <div style={{display:'flex', gap: 6, flexWrap:'wrap', marginTop: 8}}>
              <PickerChip label="catchword" kind="component" state="none"/>
              <PickerChip label="marginalia" kind="component" state="none"/>
              <PickerChip label="running header" kind="component" state="none"/>
              <PickerChip label="signature mark" kind="component" state="none"/>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3, height:26, padding:'0 9px', fontSize:11}}>+ custom…</span>
            </div>
          </details>
        </div>

        <div style={{fontSize: 10, color: W.ink3, fontStyle:'italic'}}>
          Per-character ranges? Open one word in the detail editor → "Char range" accordion.
        </div>
      </div>
    </div>
  );
}

// =====================================================================
// FINAL · Detail word editor with multi-range char editor folded in
// =====================================================================
function FinalDetailEditor() {
  const word = 'Mr.Wilson';
  const ranges = [
    { kind:'style',     label:'small caps', span:{from:1,to:3}, active:true,  fontVariant:'small-caps' },
    { kind:'component', label:'drop cap',   span:{from:1,to:1} },
    { kind:'style',     label:'italic',     span:{from:4,to:9}, fontStyle:'italic' },
  ];
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 12}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Final · Detail word editor</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          One-word focus. Whole-word style + component chips up top, char-range
          multi-editor accordion below. Most words won't need partial-word
          ranges — the accordion collapses to a one-liner when empty.
        </div>
      </header>

      <div style={{
        background: W.panel, border: `1px solid ${W.rule}`, borderRadius: 6,
        padding: 18, display:'flex', flexDirection:'column', gap: 14,
      }}>
        {/* header strip */}
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Line 4 · Word 3</span>
          <StatusPip kind="fuzzy" label="83%"/>
          <div style={{flex:1}}></div>
          <span className="wf-btn sm">◀ Prev</span>
          <span className="wf-btn sm">Next ▶</span>
        </div>

        {/* word zoom with range bars */}
        {/* word image toolbar — outside the zoom */}
        <div style={{
          display:'flex', alignItems:'center', gap: 10,
        }}>
          <span className="wf-h-label">Word image</span>
          <label style={{display:'inline-flex', alignItems:'center', gap: 6, fontSize:11, color: W.ink2}}>
            <span style={{
              width: 22, height: 12, borderRadius: 6,
              background: W.exact, padding: 1,
              display:'inline-flex', alignItems:'center',
            }}>
              <span style={{width: 10, height: 10, borderRadius: 5, background:'#fff', marginLeft:'auto'}}></span>
            </span>
            <span style={{fontWeight:600}}>char bboxes</span>
            <span style={{color: W.ink3}}>· from OCR</span>
          </label>
          <span style={{fontSize: 10, color: W.ink3, fontStyle:'italic'}}>
            (off by default · enable to see per-char outlines · click a char bbox → opens Character Fixer)
          </span>
        </div>

        {/* word zoom with range bars + per-character bboxes */}
        <div style={{
          background:'#fff', border:`1.5px solid ${W.accent}`, borderRadius: 6,
          padding: '14px 18px 22px',
          position:'relative',
        }}>
          <div style={{display:'flex', justifyContent:'center', alignItems:'flex-end', gap: 0}}>
            {word.split('').map((ch, i) => {
              const idx = i + 1;
              return (
                <div key={i} style={{
                  display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
                  padding: '0 6px',
                }}>
                  <span style={{
                    display:'inline-flex', alignItems:'center', justifyContent:'center',
                    padding: '2px 3px',
                    border: `1px dashed ${W.ink4}`,
                    borderRadius: 2,
                  }}>
                    <span style={{
                      fontFamily:'serif', fontSize: 52,
                      color: W.ink,
                      fontVariant: idx >= 1 && idx <= 3 ? 'small-caps' : 'normal',
                      fontStyle: idx >= 4 && idx <= 9 ? 'italic' : 'normal',
                      lineHeight: 1,
                    }}>{ch}</span>
                  </span>
                  <span style={{fontSize: 8, color: W.ink3, fontFamily: W.mono}}>{idx}</span>
                </div>
              );
            })}
          </div>
          <div style={{position:'absolute', left:18, right:18, bottom: 6,
            display:'flex', flexDirection:'column', gap: 2}}>
            {ranges.map((r, i) => {
              const c = r.kind === 'style' ? W.ocrOnly : W.gtOnly;
              const wpct = 100 / word.length;
              const left = (r.span.from - 1) * wpct;
              const w = (r.span.to - r.span.from + 1) * wpct;
              return (
                <div key={i} style={{height: 4, position:'relative'}}>
                  <div style={{
                    position:'absolute', left:`${left}%`, width:`${w}%`,
                    height: 4, borderRadius: 2, background: c,
                    opacity: r.active ? 1 : 0.55,
                  }}></div>
                </div>
              );
            })}
          </div>
        </div>

        {/* OCR / GT */}
        <div style={{display:'grid', gridTemplateColumns:'80px 1fr auto', rowGap:8, columnGap:10, alignItems:'center'}}>
          <span className="wf-h-label">OCR</span>
          <div className="wf-mono" style={{padding:'7px 10px', background:W.panelSunk, borderRadius:4, fontSize:13}}>Mr.Wilson</div>
          <span className="wf-btn sm">OCR → GT</span>
          <span className="wf-h-label">GT</span>
          <input className="wf-input lg" defaultValue="Mr.Wilson" style={{width:'100%', fontSize:14}}/>
          <span className="wf-btn sm" style={{
            background: W.ocrOnly + '15', color: W.ocrOnly, borderColor: W.ocrOnly,
            display:'inline-flex', alignItems:'center', gap: 5,
          }}>Ω chars ▾</span>
        </div>

        {/* Unicode character picker — shown open in this mock */}
        <div style={{
          background:'#fff', border:`1px solid ${W.ocrOnly}66`, borderRadius: 5,
          boxShadow: `0 4px 14px rgba(0,0,0,0.06)`,
          padding: 12,
          display:'flex', flexDirection:'column', gap: 10,
          marginTop: -4,
        }}>
          <div style={{display:'flex', alignItems:'center', gap: 8}}>
            <span style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: W.ocrOnly}}>Ω UNICODE CHARACTERS</span>
            <span style={{fontSize: 10, color: W.ink3}}>insert into GT at cursor</span>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 10, color: W.ink3}}>
              tip: type <span className="wf-mono" style={{background:W.panelSunk, padding:'1px 4px', borderRadius:2}}>\emdash</span> to insert directly
            </span>
            <span style={{
              width: 18, height: 18, borderRadius: 4, color: W.ink3,
              display:'inline-flex', alignItems:'center', justifyContent:'center',
              fontSize: 12, border:`1px solid ${W.ink4}`,
            }}>✕</span>
          </div>

          {/* search */}
          <div style={{display:'flex', alignItems:'center', gap: 6}}>
            <div style={{
              flex: 1, height: 28, padding: '0 10px',
              background: W.paperAlt, border:`1px solid ${W.ink3}`, borderRadius: 4,
              display:'flex', alignItems:'center', gap: 8,
              fontSize: 12,
            }}>
              <span style={{color: W.ink3}}>⌕</span>
              <span style={{flex: 1, color: W.ink}}>em dash</span>
              <span style={{fontSize: 10, color: W.ink3}}>4 results</span>
            </div>
            <span className="wf-btn sm ghost">Clear</span>
          </div>

          {/* Character set chips */}
          <div style={{display:'flex', gap: 5, flexWrap:'wrap', alignItems:'center'}}>
            <span className="wf-h-label" style={{marginRight: 4}}>Sets</span>
            {[
              {l:'Quotes “ ”', active:false},
              {l:'Dashes – —', active:true},
              {l:'Ligatures ﬁ', active:false},
              {l:'Diacritics é', active:false},
              {l:'Historic ſ', active:false},
              {l:'Greek α', active:false},
              {l:'Math ≈', active:false},
              {l:'Punctuation ¶', active:false},
              {l:'Currency $', active:false},
              {l:'Fractions ½', active:false},
            ].map((s, i) => (
              <span key={i} className="wf-chip" style={{
                background: s.active ? W.ocrOnly + '18' : W.panel,
                borderColor: s.active ? W.ocrOnly : W.ink4,
                color: s.active ? W.ocrOnly : W.ink2,
                height: 22, padding:'0 9px', fontSize: 11,
              }}>{s.l}</span>
            ))}
          </div>

          {/* Recent */}
          <div style={{display:'flex', gap: 6, alignItems:'center', fontSize: 11, color: W.ink2}}>
            <span className="wf-h-label">Recent</span>
            {['–', '—', '"', '"', "'", "'", 'ſ', '¶', '†'].map((g, i) => (
              <span key={i} style={{
                fontFamily:'serif', fontSize: 18,
                width: 28, height: 26,
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                background: W.panel, border:`1px solid ${W.ruleSoft}`, borderRadius: 3,
                color: W.ink,
              }}>{g}</span>
            ))}
          </div>

          {/* Result grid */}
          <div>
            <div style={{
              display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap: 6,
            }}>
              {[
                { glyph:'—', cp:'U+2014', name:'EM DASH',     hot:'\\emdash' },
                { glyph:'–', cp:'U+2013', name:'EN DASH',     hot:'\\endash' },
                { glyph:'−', cp:'U+2212', name:'MINUS SIGN',  hot:'\\minus' },
                { glyph:'‒', cp:'U+2012', name:'FIGURE DASH', hot:'\\figdash' },
              ].map((c, i) => (
                <div key={i} style={{
                  display:'flex', alignItems:'center', gap: 10,
                  padding: '8px 10px', background: W.panel,
                  border: `1px solid ${i===0 ? W.ocrOnly : W.ruleSoft}`,
                  borderRadius: 4,
                  boxShadow: i===0 ? `0 0 0 1px ${W.ocrOnly}66 inset` : 'none',
                }}>
                  <span style={{
                    fontFamily:'serif', fontSize: 30, color: W.ink,
                    width: 32, textAlign:'center',
                  }}>{c.glyph}</span>
                  <div style={{display:'flex', flexDirection:'column', gap: 1, minWidth: 0}}>
                    <span style={{fontFamily: W.mono, fontSize: 10, color: W.ink3}}>{c.cp}</span>
                    <span style={{fontSize: 11, fontWeight: 600, color: W.ink}}>{c.name}</span>
                    <span style={{fontFamily: W.mono, fontSize: 9, color: W.ink3}}>{c.hot}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* BOUNDING BOX */}
        <div style={{
          padding: 12, background: W.paperAlt, borderRadius: 5,
          border: `1px solid ${W.ruleSoft}`,
          display:'flex', flexDirection:'column', gap: 10,
        }}>
          <div style={{display:'flex', alignItems:'baseline', gap:8}}>
            <span style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: W.ink2}}>BOUNDING BOX</span>
            <span style={{fontSize: 10, color: W.ink3}}>geometry of this word</span>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 10, color: W.ink3, fontFamily: W.mono}}>x:124 y:418 · 92×54 px</span>
          </div>
          <div style={{display:'flex', gap: 6, flexWrap:'wrap', alignItems:'center'}}>
            <span className="wf-btn sm">Refine <span className="wf-key" style={{height:13, fontSize:9, marginLeft:3}}>F</span></span>
            <span className="wf-btn sm">Expand + Refine</span>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 10, color: W.ink3, fontStyle:'italic'}}>Rebox &amp; Erase live in their own panels below</span>
          </div>
          {/* Nudge row */}
          <div style={{display:'flex', gap: 8, alignItems:'center', flexWrap:'wrap'}}>
            <span className="wf-h-label" style={{minWidth: 38}}>Nudge</span>
            {['1','5','10'].map(s => (
              <span key={s} className="wf-btn sm" style={{width:22, padding:0,
                background: s==='5'?W.ink:W.panel, color: s==='5'?'#fff':W.ink, borderColor: s==='5'?W.ink:W.ink3,
              }}>{s}</span>
            ))}
            <span style={{fontSize:10, color:W.ink3}}>px</span>
            <div style={{width: 1, height: 18, background: W.rule, margin: '0 4px'}}></div>
            {[['L'],['R'],['T'],['B']].map(([n]) => (
              <div key={n} style={{display:'flex', gap:2, alignItems:'center'}}>
                <span style={{fontSize:11, fontWeight:600, width: 10}}>{n}</span>
                <span className="wf-btn sm" style={{width:22, padding:0}}>−</span>
                <span className="wf-btn sm" style={{width:22, padding:0}}>＋</span>
              </div>
            ))}
            <span style={{fontSize:10, color:W.ink3, marginLeft:6, fontFamily: W.mono}}>arrows · ⇧arrows = grow</span>
          </div>
          {/* Crop + pending */}
          <div style={{display:'flex', gap: 8, alignItems:'center', flexWrap:'wrap'}}>
            <span className="wf-h-label" style={{minWidth: 38}}>Crop</span>
            <span className="wf-btn sm">Above ▲</span>
            <span className="wf-btn sm">Below ▼</span>
            <span className="wf-btn sm">Left ◀</span>
            <span className="wf-btn sm">Right ▶</span>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 11, color: W.ink3, fontFamily: W.mono,
              padding: '3px 9px', background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 3,
            }}>pending L:0 R:0 T:0 B:0 px</span>
            <span className="wf-btn sm ghost">Reset</span>
            <span className="wf-btn sm">Apply</span>
            <span className="wf-btn sm primary">Apply + Refine</span>
          </div>
        </div>

        {/* REBOX accordion — expanded */}
        <div style={{
          background: W.paperAlt, border: `1px solid ${W.ruleSoft}`, borderRadius: 5,
          overflow: 'hidden',
        }}>
          <div style={{
            display:'flex', alignItems:'center', gap: 8, padding: '8px 12px',
            borderBottom: `1px solid ${W.ruleSoft}`,
            background: W.accent + '0a',
          }}>
            <span style={{
              width: 14, transform: 'rotate(90deg)',
              color: W.accent, fontSize: 11,
            }}>▶</span>
            <span style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: W.accent}}>REBOX</span>
            <span style={{fontSize: 10, color: W.ink3}}>drag a new bbox on the zoomed page region</span>
            <div style={{flex:1}}></div>
            <span className="wf-key" style={{height: 16, fontSize: 9}}>B</span>
          </div>
          <div style={{padding: 12, display:'flex', flexDirection:'column', gap: 10}}>
            {/* mini canvas */}
            <div style={{
              position:'relative', height: 260,
              background: '#3c3833', borderRadius: 4, overflow: 'hidden',
            }}>
              <div style={{
                position:'absolute', inset: '24px 36px',
                background: '#faf6ec', border: `1px solid ${W.rule}`,
                display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center',
                gap: 14, padding: '20px 30px',
                fontFamily: 'serif',
              }}>
                <div style={{display:'flex', gap: 10, fontSize: 20, color: W.ink2, opacity: 0.65}}>
                  <span>A</span><span>HISTORY</span><span>OF</span>
                </div>
                <div style={{display:'flex', gap: 16, fontSize: 30, position:'relative', alignItems:'baseline'}}>
                  <span>WOODROW</span>
                  <span style={{position:'relative'}}>
                    <span style={{fontVariant:'small-caps'}}>Mr.</span>Wilson,
                    {/* old bbox dashed */}
                    <span style={{
                      position:'absolute', left: -6, right: -3, top: -5, bottom: -5,
                      border: `1.5px dashed ${W.ink3}`, borderRadius: 2,
                    }}></span>
                  </span>
                  <span style={{fontVariant:'small-caps', fontSize: 22}}>Ph.D.,</span>
                  {/* new bbox — accent */}
                  <div style={{
                    position:'absolute',
                    left: '34%', width: '24%',
                    top: -10, bottom: -12,
                    border: `2.5px solid ${W.accent}`,
                    background: W.accent + '12',
                    borderRadius: 2,
                  }}>
                    {[{top:-4,left:-4},{top:-4,right:-4},{bottom:-4,left:-4},{bottom:-4,right:-4}].map((p,i) => (
                      <span key={i} style={{position:'absolute', ...p,
                        width: 8, height: 8, borderRadius: 1.5,
                        background:'#fff', border:`1.5px solid ${W.accent}`,
                      }}></span>
                    ))}
                    <span style={{
                      position:'absolute', top: -20, right: -2,
                      fontFamily: W.mono, fontSize: 9, color:'#fff', fontWeight: 600,
                      background: W.accent, padding:'1px 5px', borderRadius: 2,
                    }}>new · 104×62</span>
                  </div>
                </div>
                <div style={{display:'flex', gap: 10, fontSize: 18, color: W.ink2, opacity: 0.55}}>
                  <span>IN</span><span>FIVE</span><span>VOLUMES</span>
                </div>
              </div>
              {/* snap-to-pixels (top-left) */}
              <div style={{
                position:'absolute', top: 8, left: 8,
                display:'flex', alignItems:'center', gap: 6,
                padding: '4px 8px',
                background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 5,
                fontSize: 10, color: W.ink2,
                boxShadow: '0 3px 10px rgba(0,0,0,0.15)',
              }}>
                <span style={{
                  width: 22, height: 12, borderRadius: 6,
                  background: W.exact, padding: 1,
                  display:'inline-flex', alignItems:'center', flex:'0 0 auto',
                }}>
                  <span style={{width: 10, height: 10, borderRadius: 5, background:'#fff', marginLeft:'auto'}}></span>
                </span>
                <span style={{fontWeight:600}}>Snap to source pixels</span>
                <span style={{color:W.ink3, fontSize: 9}}>integer x,y,w,h</span>
              </div>
              {/* mode toolbar — top right */}
              <div style={{
                position:'absolute', top: 8, right: 8,
                display:'flex', gap: 3, padding: 3,
                background: '#fff', border:`1px solid ${W.rule}`, borderRadius: 5,
                boxShadow: '0 3px 10px rgba(0,0,0,0.15)',
              }}>
                <span className="wf-btn sm" style={{background: W.ink, color:'#fff', borderColor: W.ink, height: 22, padding:'0 8px', fontSize: 10}}>✎ Draw</span>
                <span className="wf-btn sm ghost" style={{height: 22, padding:'0 8px', fontSize: 10}}>✋ Pan</span>
              </div>
              {/* zoom — bottom center */}
              <div style={{
                position:'absolute', bottom: 8, left: '50%', transform:'translateX(-50%)',
                display:'flex', alignItems:'center', gap: 3, padding: 3,
                background: '#fff', border:`1px solid ${W.rule}`, borderRadius: 6,
                boxShadow: '0 3px 10px rgba(0,0,0,0.15)',
              }}>
                <span className="wf-btn sm icon" style={{width: 22, height: 22, fontSize: 11}}>−</span>
                <span style={{fontFamily: W.mono, fontSize: 11, minWidth: 44, textAlign:'center', color: W.ink}}>320%</span>
                <span className="wf-btn sm icon" style={{width: 22, height: 22, fontSize: 11}}>＋</span>
                <div style={{width: 1, height: 14, background: W.rule, margin: '0 3px'}}></div>
                {['2×','5×','10×'].map(z => (
                  <span key={z} className="wf-btn sm" style={{
                    height: 22, padding:'0 7px', fontSize: 10,
                    background: z==='5×'?W.ink:W.panel, color: z==='5×'?'#fff':W.ink, borderColor: z==='5×'?W.ink:W.ink3,
                  }}>{z}</span>
                ))}
                <div style={{width: 1, height: 14, background: W.rule, margin: '0 3px'}}></div>
                <span className="wf-btn sm" style={{height: 22, padding:'0 7px', fontSize: 10}}>Fit</span>
              </div>
              {/* coord readout — bottom left */}
              <div style={{
                position:'absolute', bottom: 8, left: 8,
                background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 5,
                padding:'4px 8px', fontSize: 10, fontFamily: W.mono, color: W.ink2,
                display:'flex', gap: 6,
              }}>
                <span style={{color:W.ink3}}>x</span><span>148</span>
                <span style={{color:W.ink3}}>y</span><span>412</span>
                <span style={{color:W.ink3}}>w</span><span>104</span>
                <span style={{color:W.ink3}}>h</span><span>62</span>
                <span style={{color: W.exact, marginLeft: 2}}>+12×+8</span>
              </div>
            </div>

            {/* commit row */}
            <div style={{display:'flex', alignItems:'center', gap: 8, flexWrap:'wrap'}}>
              <span style={{display:'inline-flex', alignItems:'center', gap: 6, fontSize: 11}}>
                <span style={{
                  width: 26, height: 14, borderRadius: 7,
                  background: W.exact, padding: 2, display:'inline-flex', alignItems:'center',
                }}>
                  <span style={{width: 10, height: 10, borderRadius: 5, background:'#fff', marginLeft:'auto'}}></span>
                </span>
                <span style={{fontWeight: 600}}>Auto-refine on apply</span>
                <span style={{fontSize: 10, color: W.ink3}}>tighten to pixels</span>
              </span>
              <div style={{flex:1}}></div>
              <span style={{fontSize: 10, color: W.ink3}}>
                <span className="wf-key" style={{height:13, fontSize:9}}>esc</span> cancel ·
                <span className="wf-key" style={{height:13, fontSize:9, marginLeft:4}}>⏎</span> apply
              </span>
              <span className="wf-btn sm ghost">Cancel</span>
              <span className="wf-btn sm primary">Apply rebox</span>
            </div>
          </div>
        </div>

        {/* ERASE PIXELS accordion — expanded · with brush + auto-detect */}
        <div style={{
          background: W.paperAlt, border: `1px solid ${W.ruleSoft}`, borderRadius: 5,
          overflow: 'hidden',
        }}>
          <div style={{
            display:'flex', alignItems:'center', gap: 8, padding: '8px 12px',
            borderBottom: `1px solid ${W.ruleSoft}`,
            background: W.mismatch + '0c',
          }}>
            <span style={{width: 14, transform: 'rotate(90deg)', color: W.mismatch, fontSize: 11}}>▶</span>
            <span style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: W.mismatch}}>ERASE PIXELS</span>
            <span style={{fontSize: 10, color: W.ink3}}>brush, rect, lasso, or auto-detect · 4 ops + 2 pending</span>
            <div style={{flex:1}}></div>
            <span className="wf-key" style={{height: 16, fontSize: 9}}>X</span>
          </div>

          <div style={{padding: 12, display:'flex', flexDirection:'column', gap: 10}}>
            {/* Top action row: auto-detect quick button */}
            <div style={{
              display:'flex', alignItems:'center', gap: 10,
              padding: '8px 10px', background: W.fuzzy + '12',
              border: `1px dashed ${W.fuzzy}88`, borderRadius: 4,
              fontSize: 11,
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: 11,
                background: W.fuzzy, color: '#fff',
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                fontSize: 12, fontWeight: 700,
              }}>✨</span>
              <span style={{fontWeight:600, color:W.ink}}>Auto-detect specks</span>
              <span style={{color:W.ink2}}>
                model found <b>5 suspicious blobs</b> outside character bboxes ·
                review &amp; accept individually below
              </span>
              <div style={{flex:1}}></div>
              <span className="wf-btn sm" style={{borderColor:W.fuzzy, color:W.fuzzy}}>Detect</span>
              <span className="wf-btn sm" style={{background:W.fuzzy, color:'#fff', borderColor:W.fuzzy}}>Accept all 5</span>
            </div>

            {/* mini canvas */}
            <div style={{
              position:'relative', height: 230,
              background: '#3c3833', borderRadius: 4, overflow: 'hidden',
            }}>
              <div style={{
                position:'absolute', inset:'18px 40px',
                background:'#faf6ec', border:`1px solid ${W.rule}`,
                display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                gap: 10, padding: '16px 26px',
                fontFamily:'serif',
              }}>
                <div style={{display:'flex', gap: 18, fontSize: 32, position:'relative', alignItems:'baseline'}}>
                  <span style={{position:'relative'}}>
                    <span style={{fontVariant:'small-caps'}}>Mr.</span>Wilson,

                    {/* AUTO-DETECTED specks — yellow with ?/✓ marker */}
                    {[
                      {left:'-3%', top:'18%', w:6, h:6, accepted:true},
                      {left:'8%',  top:'-12%', w:5, h:5, accepted:false},
                      {right:'18%', bottom:'-10%', w:7, h:5, accepted:true},
                      {left:'45%', top:'-8%',  w:4, h:4, accepted:false},
                      {right:'2%',  top:'8%',   w:6, h:4, accepted:false},
                    ].map((s, i) => {
                      const c = s.accepted ? W.mismatch : W.fuzzy;
                      return (
                        <span key={i} style={{
                          position:'absolute',
                          left: s.left, right: s.right, top: s.top, bottom: s.bottom,
                          width: s.w, height: s.h,
                          background: s.accepted ? W.mismatch + '88' : W.fuzzy + '88',
                          border: `1.5px solid ${c}`, borderRadius: '50%',
                        }}></span>
                      );
                    })}

                    {/* LASSO committed — irregular closed polygon over a smudge */}
                    <svg style={{
                      position:'absolute', left: '-15%', top: '-30%',
                      width: 70, height: 36, overflow:'visible',
                      pointerEvents:'none',
                    }} viewBox="0 0 70 36">
                      <polygon
                        points="6,14 14,4 28,2 38,10 44,4 56,8 60,18 52,28 38,32 22,30 12,24"
                        fill={W.mismatch + '55'}
                        stroke={W.mismatch}
                        strokeWidth="1.5"
                        strokeDasharray="2 1.5"
                      />
                      {/* small vertex dots */}
                      {[[6,14],[14,4],[28,2],[38,10],[44,4],[56,8],[60,18],[52,28],[38,32],[22,30],[12,24]].map((p, i) => (
                        <circle key={i} cx={p[0]} cy={p[1]} r="1.2" fill={W.mismatch}/>
                      ))}
                    </svg>

                    {/* brush stroke remains (underline residue) */}
                    <span style={{
                      position:'absolute', left: '-5%', bottom: '-12%',
                      width: '108%', height: 5,
                      background: W.mismatch + '88',
                      border: `1.5px solid ${W.mismatch}`,
                      borderRadius: 99,
                    }}>
                      <span style={{
                        position:'absolute', top: -14, left: 8,
                        fontSize: 9, color:'#fff', fontWeight: 600,
                        background: W.mismatch, padding:'1px 5px', borderRadius: 2,
                        fontFamily: W.mono, whiteSpace:'nowrap',
                      }}>brush · 6px</span>
                    </span>

                    {/* rect committed */}
                    <span style={{
                      position:'absolute', right: '-7%', top: '20%',
                      width: 12, height: 30,
                      background: W.mismatch + '55',
                      border: `1px solid ${W.mismatch}aa`,
                      borderRadius: 1,
                    }}></span>

                    {/* in-progress lasso path (open, vertex being placed) */}
                    <svg style={{
                      position:'absolute', left: '32%', top: '-8%',
                      width: 50, height: 32, overflow:'visible',
                      pointerEvents:'none',
                    }} viewBox="0 0 50 32">
                      <polyline
                        points="4,18 10,8 22,4 32,12 38,6"
                        fill="none"
                        stroke={W.mismatch}
                        strokeWidth="1.8"
                        strokeDasharray="3 2"
                      />
                      {[[4,18],[10,8],[22,4],[32,12]].map((p, i) => (
                        <circle key={i} cx={p[0]} cy={p[1]} r="1.5" fill={W.mismatch}/>
                      ))}
                      {/* live cursor vertex */}
                      <circle cx={38} cy={6} r="3.5" fill="#fff" stroke={W.mismatch} strokeWidth="1.8"/>
                    </svg>
                    <span style={{
                      position:'absolute', left: '52%', top: '-22%',
                      fontSize: 9, color: '#fff', fontWeight: 600,
                      background: W.mismatch, padding:'1px 5px', borderRadius: 2,
                      fontFamily: W.mono, whiteSpace: 'nowrap',
                    }}>lasso · double-click to close</span>
                  </span>
                </div>
              </div>

              {/* mode toolbar: brush / rect / pan + brush size */}
              <div style={{
                position:'absolute', top: 8, right: 8,
                display:'flex', gap: 3, padding: 3,
                background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 5,
                boxShadow: '0 3px 10px rgba(0,0,0,0.15)',
              }}>
                <span className="wf-btn sm ghost" style={{height: 22, padding:'0 8px', fontSize: 10}}>⚪ Brush</span>
                <span className="wf-btn sm ghost" style={{height:22, padding:'0 8px', fontSize:10}}>▭ Rect</span>
                <span className="wf-btn sm" style={{background: W.mismatch, color:'#fff', borderColor: W.mismatch, height: 22, padding:'0 8px', fontSize: 10}}>⌒ Lasso</span>
                <span className="wf-btn sm ghost" style={{height:22, padding:'0 8px', fontSize:10}}>✋ Pan</span>
              </div>

              {/* tool-options widget (top-left) */}
              <div style={{
                position:'absolute', top: 8, left: 8,
                display:'flex', flexDirection:'column', gap: 4,
                padding: '6px 8px',
                background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 5,
                fontSize: 10, color: W.ink2,
                boxShadow: '0 3px 10px rgba(0,0,0,0.15)',
                minWidth: 168,
              }}>
                <div style={{display:'flex', alignItems:'center', gap: 6}}>
                  <span style={{fontWeight:600}}>Brush</span>
                  <div style={{position:'relative', width: 80, height: 4, background: W.panelSunk, borderRadius: 2}}>
                    <div style={{position:'absolute', inset: 0, width: '30%', background: W.mismatch, borderRadius:2}}></div>
                    <div style={{position:'absolute', left: '30%', top: -3, width: 10, height: 10, borderRadius: 5,
                      background:'#fff', border:`2px solid ${W.mismatch}`, transform:'translateX(-50%)',
                    }}></div>
                  </div>
                  <span style={{fontFamily: W.mono, color: W.ink, fontWeight: 600, minWidth: 26}}>6 px</span>
                  <span style={{color:W.ink3, fontSize: 9}}>[ ]</span>
                </div>
                <div style={{display:'flex', alignItems:'center', gap: 6,
                  paddingTop: 4, borderTop: `1px solid ${W.ruleSoft}`,
                }}>
                  <span style={{
                    width: 22, height: 12, borderRadius: 6,
                    background: W.exact, padding: 1,
                    display:'inline-flex', alignItems:'center', flex:'0 0 auto',
                  }}>
                    <span style={{width: 10, height: 10, borderRadius: 5, background:'#fff', marginLeft:'auto'}}></span>
                  </span>
                  <span style={{fontWeight:600}}>Snap to source pixels</span>
                  <span style={{color:W.ink3, fontSize: 9, marginLeft:'auto'}}>integer x,y</span>
                </div>
              </div>

              {/* zoom */}
              <div style={{
                position:'absolute', bottom: 8, left: '50%', transform:'translateX(-50%)',
                display:'flex', alignItems:'center', gap: 3, padding: 3,
                background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 6,
                boxShadow:'0 3px 10px rgba(0,0,0,0.15)',
              }}>
                <span className="wf-btn sm icon" style={{width:22, height:22, fontSize:11}}>−</span>
                <span style={{fontFamily:W.mono, fontSize:11, minWidth: 44, textAlign:'center'}}>420%</span>
                <span className="wf-btn sm icon" style={{width:22, height:22, fontSize:11}}>＋</span>
                <div style={{width:1, height:14, background:W.rule, margin:'0 3px'}}></div>
                {['2×','5×','10×'].map(z => (
                  <span key={z} className="wf-btn sm" style={{height:22, padding:'0 7px', fontSize:10,
                    background: z==='10×'?W.ink:W.panel, color: z==='10×'?'#fff':W.ink, borderColor: z==='10×'?W.ink:W.ink3,
                  }}>{z}</span>
                ))}
                <div style={{width:1, height:14, background:W.rule, margin:'0 3px'}}></div>
                <span className="wf-btn sm" style={{height:22, padding:'0 7px', fontSize:10}}>Fit</span>
              </div>
            </div>

            {/* Ops list with type icons */}
            <div>
              <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom:6}}>
                <span className="wf-h-label">Erase ops</span>
                <span style={{fontSize:10, color:W.ink3}}>3 committed · 2 pending (yellow specks)</span>
                <div style={{flex:1}}></div>
                <span className="wf-btn sm ghost" style={{height:22, padding:'0 8px', fontSize:10}}>Reject all pending</span>
              </div>
              <div style={{display:'flex', flexDirection:'column', gap: 4}}>
                {[
                  { type:'auto',   icon:'✨', region:'x:152 y:404 · ø 6',    note:'detected speck',     state:'committed' },
                  { type:'auto',   icon:'✨', region:'x:218 y:446 · ø 7',    note:'detected speck',     state:'committed' },
                  { type:'brush',  icon:'⚪', region:'stroke · 12 dabs · ø6', note:'underline residue',  state:'committed' },
                  { type:'lasso',  icon:'⌒', region:'polygon · 11 vertices · pixel-aligned',  note:'irregular smudge',   state:'committed' },
                  { type:'rect',   icon:'▭', region:'x:240 y:418 · 12×30',  note:'bleed-through',      state:'pending' },
                  { type:'auto',   icon:'✨', region:'x:176 y:402 · ø 4',    note:'speck (low conf 41%)', state:'pending' },
                ].map((op, i) => {
                  const isPending = op.state === 'pending';
                  return (
                    <div key={i} style={{
                      display:'flex', alignItems:'center', gap: 10,
                      padding:'5px 10px', background:'#fff', borderRadius: 4,
                      border: `1px solid ${isPending ? W.fuzzy : W.ruleSoft}`,
                    }}>
                      <span style={{
                        width: 22, height: 22, borderRadius: 4,
                        background: isPending ? W.fuzzy + '15' : W.panelSunk,
                        color: isPending ? W.fuzzy : W.ink2,
                        display:'inline-flex', alignItems:'center', justifyContent:'center',
                        fontSize: 12,
                      }}>{op.icon}</span>
                      <span style={{fontFamily: W.mono, fontSize:11, color: W.ink2, minWidth: 170}}>{op.region}</span>
                      <span style={{fontSize: 10, color: W.ink3, fontStyle:'italic'}}>{op.note}</span>
                      {isPending && <span style={{fontSize:9, fontWeight:700, color:W.fuzzy, letterSpacing:'0.06em'}}>PENDING</span>}
                      <div style={{flex:1}}></div>
                      {isPending ? (
                        <>
                          <span className="wf-btn sm" style={{height:22, padding:'0 8px', fontSize:10, color:W.mismatch, borderColor:W.mismatch}}>Accept</span>
                          <span className="wf-btn sm ghost" style={{height:22, padding:'0 8px', fontSize:10}}>Reject</span>
                        </>
                      ) : (
                        <span className="wf-btn sm ghost" style={{height: 22, padding:'0 8px', fontSize:10}}>Undo</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* commit */}
            <div style={{display:'flex', gap: 6, alignItems:'center'}}>
              <span style={{fontSize:10, color:W.ink3}}>destructive · committed pixels can be restored from project history</span>
              <div style={{flex:1}}></div>
              <span className="wf-btn sm ghost">Cancel</span>
              <span className="wf-btn sm danger">Apply erase</span>
            </div>
          </div>
        </div>

        {/* STRUCTURE — merge / split / delete (accordion) */}
        <div style={{
          background: W.paperAlt, border: `1px solid ${W.ruleSoft}`, borderRadius: 5,
          overflow: 'hidden',
        }}>
          <div style={{
            display:'flex', alignItems:'center', gap: 8, padding: '8px 12px',
            borderBottom: `1px solid ${W.ruleSoft}`,
          }}>
            <span style={{
              width: 14, transform: 'rotate(90deg)',
              color: W.ink2, fontSize: 11,
            }}>▶</span>
            <span style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: W.ink2}}>STRUCTURE</span>
            <span style={{fontSize: 10, color: W.ink3}}>combine with neighbors · split into pieces</span>
          </div>
          <div style={{padding: 12, display:'flex', flexDirection:'column', gap: 10}}>
            {/* NEIGHBORS strip */}
            <div>
              <span className="wf-h-label">Neighbors</span>
              <div style={{display:'flex', gap: 6, marginTop: 6}}>
                {[
                  { kind:'prev', word:'WOODROW',   id:'L4·W1', status:'exact', size: 26 },
                  { kind:'curr', word:'Mr.Wilson', id:'L4·W2 · this', status:'fuzzy', sc:true, size: 28 },
                  { kind:'next', word:'Ph.D.,',    id:'L4·W3', status:'exact', sc:true, size: 24 },
                ].map((n, i) => (
                  <div key={i} style={{
                    flex: 1, padding: '8px 10px', borderRadius: 4,
                    background: '#fff',
                    border: n.kind === 'curr' ? `1.5px solid ${W.accent}` : `1px solid ${W.ruleSoft}`,
                    display:'flex', flexDirection:'column', gap: 4, alignItems:'center',
                  }}>
                    <span style={{fontSize: 9, color: W.ink3, fontWeight: 700, letterSpacing:'0.06em',
                      textTransform:'uppercase'}}>
                      {n.kind === 'prev' ? '← prev' : n.kind === 'next' ? 'next →' : 'current'}
                    </span>
                    <span style={{
                      fontFamily:'serif', fontSize: n.size, color: W.ink,
                      fontVariant: n.sc ? 'small-caps' : 'normal',
                      lineHeight: 1.05,
                    }}>{n.word}</span>
                    <div style={{display:'flex', gap:6, alignItems:'center'}}>
                      <span style={{fontSize: 9, color: W.ink3, fontFamily: W.mono}}>{n.id}</span>
                      <StatusPip kind={n.status}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* MERGE row with previews */}
            <div>
              <div style={{display:'flex', alignItems:'baseline', gap:8, marginBottom: 6}}>
                <span className="wf-h-label">Merge</span>
                <label style={{display:'inline-flex', alignItems:'center', gap: 5, fontSize:11, color: W.ink2}}>
                  <span style={{
                    width: 12, height: 12, borderRadius: 3, background:'#fff',
                    border: `1.5px solid ${W.ink3}`,
                    display:'inline-flex', alignItems:'center', justifyContent:'center',
                    fontSize: 9, color: W.ink,
                  }}>✓</span>
                  join with space
                </label>
                <span style={{fontSize: 10, color: W.ink3}}>preview shows merged result + new bbox size</span>
              </div>
              <div style={{display:'flex', flexDirection:'column', gap: 5}}>
                {[
                  { dir:'prev', label:'⟵ Merge with prev', preview:'WOODROW Mr.Wilson', bbox:'168×54', sc:true },
                  { dir:'next', label:'Merge with next ⟶', preview:'Mr.Wilson Ph.D.,',  bbox:'176×54', sc:true },
                ].map((m, i) => (
                  <div key={i} style={{
                    display:'flex', alignItems:'center', gap: 10,
                    padding: '6px 10px', background: '#fff', borderRadius: 4,
                    border: `1px solid ${W.ruleSoft}`,
                  }}>
                    <span className="wf-btn sm" style={{minWidth: 150, height: 26}}>{m.label}</span>
                    <span style={{fontSize: 10, color: W.ink3, fontWeight: 700, letterSpacing:'0.06em'}}>→</span>
                    <span style={{
                      fontFamily:'serif', fontSize: 20, color: W.ink,
                      fontVariant: m.sc ? 'small-caps' : 'normal',
                      padding: '2px 8px', background: W.accent + '10',
                      border: `1px dashed ${W.accent}`, borderRadius: 2,
                    }}>{m.preview}</span>
                    <div style={{flex:1}}></div>
                    <span style={{fontSize: 10, color: W.ink3, fontFamily: W.mono}}>
                      bbox {m.bbox}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Split row with between-char picker */}
            <div style={{display:'flex', flexDirection:'column', gap: 8}}>
              <div style={{display:'flex', gap: 8, alignItems:'center'}}>
                <span className="wf-h-label" style={{minWidth: 50}}>Split</span>
                <span style={{fontSize: 11, color: W.ink2}}>click a gap between characters</span>
                <div style={{flex:1}}></div>
              </div>
              {/* between-char picker */}
              <div style={{
                display:'flex', justifyContent:'center', alignItems:'center', gap: 0,
                padding: '10px 8px', background:'#fff', borderRadius: 4,
                border: `1px solid ${W.rule}`,
              }}>
                {'Mr.Wilson'.split('').map((ch, i, arr) => {
                  const isPicked = i === 2;
                  return (
                    <React.Fragment key={i}>
                      <span style={{
                        fontFamily:'serif', fontSize: 26, color: W.ink,
                        padding: '0 1px',
                      }}>{ch}</span>
                      {i < arr.length - 1 && (
                        <span style={{
                          width: isPicked ? 4 : 2,
                          height: 32,
                          background: isPicked ? W.accent : W.ink4,
                          borderRadius: 2,
                          margin: '0 3px',
                          opacity: isPicked ? 1 : 0.5,
                          position:'relative',
                        }}>
                          {isPicked && (
                            <span style={{
                              position:'absolute', top: -14, left: '50%', transform: 'translateX(-50%)',
                              fontSize: 9, color: W.accent, fontWeight: 700, fontFamily: W.mono,
                              whiteSpace: 'nowrap',
                            }}>split here</span>
                          )}
                        </span>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
              <div style={{display:'flex', gap: 6, alignItems:'center', flexWrap:'wrap'}}>
                <span style={{fontFamily: W.mono, fontSize: 11, color: W.ink2,
                  padding: '3px 9px', background:'#fff', borderRadius: 3,
                  border: `1px solid ${W.rule}`,
                }}>“Mr.” | “Wilson”</span>
                <span style={{fontSize: 10, color: W.ink3}}>preview · two new words after split</span>
                <div style={{flex:1}}></div>
                <span className="wf-btn sm ghost">Cancel</span>
                <span className="wf-btn sm primary">Split <span className="wf-key" style={{height:13, fontSize:9, marginLeft:3, background:'#0003', borderColor:'transparent', color:'#fff'}}>S</span></span>
              </div>

              {/* Nested · Split vertically (rare) — expanded */}
              <div style={{
                background: '#fff', border: `1px dashed ${W.ink4}`, borderRadius: 4,
                overflow: 'hidden', marginTop: 2,
              }}>
                <div style={{
                  display:'flex', alignItems:'center', gap: 8, padding: '6px 10px',
                  borderBottom: `1px dashed ${W.ink4}`,
                }}>
                  <span style={{width: 12, color: W.ink2, fontSize: 10, transform:'rotate(90deg)'}}>▶</span>
                  <span style={{fontSize: 11, fontWeight: 600, color: W.ink2}}>Split vertically (stacked text)</span>
                  <span style={{fontSize: 10, color: W.ink3}}>rare · for words mistakenly grouped across two physical lines</span>
                </div>
                <div style={{padding: 10, display:'flex', flexDirection:'column', gap: 8}}>
                  {/* mini canvas with vertically-stacked content + draggable split line */}
                  <div style={{
                    position:'relative', height: 130,
                    background:'#faf6ec', border:`1px solid ${W.ruleSoft}`, borderRadius: 3,
                    display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                    gap: 4, fontFamily:'serif',
                  }}>
                    {/* top half — above split */}
                    <div style={{
                      position:'absolute', top: 0, left: 0, right: 0,
                      height: '46%', background: W.accent + '0a',
                      borderBottom: `1px solid ${W.accent}33`,
                    }}></div>
                    {/* bottom half */}
                    <div style={{
                      position:'absolute', bottom: 0, left: 0, right: 0,
                      height: '50%', background: W.ocrOnly + '08',
                    }}></div>
                    {/* the two text lines */}
                    <span style={{fontSize: 26, color: W.ink, position:'relative', zIndex:1,
                      fontVariant:'small-caps',
                    }}>Mr.Wilson</span>
                    <span style={{fontSize: 22, color: W.ink, position:'relative', zIndex:1,
                      fontVariant:'small-caps',
                    }}>Ph.D.,</span>
                    {/* draggable horizontal split line */}
                    <div style={{
                      position:'absolute', top: '47%', left: -4, right: -4,
                      height: 3, background: W.accent, borderRadius: 2,
                      boxShadow: `0 0 0 1px #fff`,
                    }}>
                      <span style={{
                        position:'absolute', left: -6, top: -5, width: 13, height: 13,
                        background:'#fff', border:`2px solid ${W.accent}`, borderRadius: 7,
                        cursor:'ns-resize',
                      }}></span>
                      <span style={{
                        position:'absolute', right: -6, top: -5, width: 13, height: 13,
                        background:'#fff', border:`2px solid ${W.accent}`, borderRadius: 7,
                        cursor:'ns-resize',
                      }}></span>
                      <span style={{
                        position:'absolute', left: '50%', top: -22, transform:'translateX(-50%)',
                        fontSize: 9, color: W.accent, fontWeight: 700, fontFamily: W.mono,
                        background:'#fff', padding:'1px 5px', borderRadius: 2,
                        border:`1px solid ${W.accent}`,
                        whiteSpace:'nowrap',
                      }}>split here · y=32</span>
                    </div>
                    {/* zone labels */}
                    <span style={{
                      position:'absolute', top: 4, left: 6,
                      fontSize: 8, fontWeight: 700, letterSpacing:'0.06em',
                      color: W.accent, fontFamily: W.mono,
                    }}>ABOVE → new word</span>
                    <span style={{
                      position:'absolute', bottom: 4, left: 6,
                      fontSize: 8, fontWeight: 700, letterSpacing:'0.06em',
                      color: W.ocrOnly, fontFamily: W.mono,
                    }}>BELOW → new word</span>
                  </div>
                  {/* preview row */}
                  <div style={{display:'flex', gap: 6, alignItems:'center', flexWrap:'wrap'}}>
                    <span style={{fontSize: 10, color: W.ink3, fontWeight: 700, letterSpacing:'0.05em'}}>PREVIEW</span>
                    <span style={{
                      fontFamily:'serif', fontSize: 14, color: W.ink, fontVariant:'small-caps',
                      padding:'2px 8px', background: W.accent + '10',
                      border:`1px dashed ${W.accent}`, borderRadius: 2,
                    }}>Mr.Wilson</span>
                    <span style={{fontSize: 11, color: W.ink3}}>+</span>
                    <span style={{
                      fontFamily:'serif', fontSize: 14, color: W.ink, fontVariant:'small-caps',
                      padding:'2px 8px', background: W.ocrOnly + '10',
                      border:`1px dashed ${W.ocrOnly}`, borderRadius: 2,
                    }}>Ph.D.,</span>
                    <span style={{fontSize: 10, color: W.ink3, marginLeft:4}}>each becomes its own word + bbox</span>
                    <div style={{flex:1}}></div>
                    <span className="wf-btn sm ghost">Cancel</span>
                    <span className="wf-btn sm primary">Split vertically</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Whole-word STYLE + COMPONENT — both up top */}
        <div style={{
          display:'grid', gridTemplateColumns:'1fr 1fr', gap: 14,
          padding: 12, background: W.paperAlt, borderRadius: 5,
          border: `1px solid ${W.ruleSoft}`,
        }}>
          <div>
            <div style={{display:'flex', alignItems:'baseline', gap:8, marginBottom:8}}>
              <span style={{fontSize: 11, fontWeight: 700, color: W.ocrOnly, letterSpacing:'0.05em'}}>STYLE</span>
              <span style={{fontSize: 10, color: W.ink3}}>whole word</span>
            </div>
            <div style={{display:'flex', gap: 6, flexWrap:'wrap'}}>
              <PickerChip label="small caps" hot="S" state="none"/>
              <PickerChip label="italic"     hot="I" state="none"/>
              <PickerChip label="ALL CAPS"   hot="C" state="none"/>
              <PickerChip label="blackletter" hot="B" state="none"/>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3, height:26, padding:'0 9px', fontSize:11}}>more ▾</span>
            </div>
          </div>
          <div>
            <div style={{display:'flex', alignItems:'baseline', gap:8, marginBottom:8}}>
              <span style={{fontSize: 11, fontWeight: 700, color: W.gtOnly, letterSpacing:'0.05em'}}>COMPONENT</span>
              <span style={{fontSize: 10, color: W.ink3}}>whole word · additive</span>
            </div>
            <div style={{display:'flex', gap: 6, flexWrap:'wrap'}}>
              <PickerChip label="drop cap"        kind="component" state="none"/>
              <PickerChip label="footnote marker" kind="component" state="none"/>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3, height:26, padding:'0 9px', fontSize:11}}>more ▾</span>
            </div>
          </div>
        </div>

        {/* CHAR RANGE — full multi-range editor as an accordion */}
        <div style={{
          background: W.paperAlt, border: `1px solid ${W.ruleSoft}`, borderRadius: 5,
        }}>
          <div style={{
            display:'flex', alignItems:'center', gap: 8, padding: '8px 12px',
            borderBottom: `1px solid ${W.ruleSoft}`,
          }}>
            <span style={{
              width: 14, transform: 'rotate(90deg)',
              color: W.ink2, fontSize: 11,
            }}>▶</span>
            <span style={{fontSize: 12, fontWeight: 700}}>Char ranges</span>
            <span style={{fontSize: 10, color: W.ink3}}>partial-word style or component · {ranges.length} applied</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm primary" style={{height: 24, fontSize: 11}}>
              ＋ Add range <span className="wf-key" style={{height:14, fontSize:9, background:'#0003', borderColor:'transparent', color:'#fff', marginLeft:4}}>R</span>
            </span>
          </div>
          <div style={{padding: 12, display:'flex', flexDirection:'column', gap: 12}}>
            {/* Ranges list */}
            <div style={{display:'flex', flexDirection:'column', gap: 5}}>
              {ranges.map((r, i) => (
                <RangeListRow key={i}
                  kind={r.kind} label={r.label} span={r.span}
                  fontStyle={r.fontStyle} fontVariant={r.fontVariant}
                  word={word} active={r.active}/>
              ))}
            </div>

            {/* Active range editor (boxed) */}
            <div style={{
              border: `2px solid ${W.ocrOnly}88`,
              borderRadius: 6, padding: 12,
              background: W.ocrOnly + '08',
            }}>
              <div style={{display:'flex', alignItems:'center', gap: 8, marginBottom: 10}}>
                <span style={{fontSize: 10, fontWeight: 700, color: W.ocrOnly, letterSpacing:'0.05em'}}>EDITING</span>
                <span style={{
                  display:'inline-flex', alignItems:'center', gap: 5,
                  padding: '2px 8px', borderRadius: 10,
                  background: '#fff', color: W.ocrOnly, fontSize: 11, fontWeight: 600,
                  border: `1px solid ${W.ocrOnly}55`,
                  fontVariant:'small-caps',
                }}>small caps</span>
                <span style={{fontSize: 11, color: W.ink2, fontFamily: W.mono}}>chars 1–3 · "Mr."</span>
                <div style={{flex:1}}></div>
                <span style={{fontSize: 10, color: W.ink3}}>
                  <span className="wf-key" style={{height:14, fontSize:9}}>←</span>
                  <span className="wf-key" style={{height:14, fontSize:9}}>→</span> shrink ·
                  <span className="wf-key" style={{height:14, fontSize:9}}>⇧←</span>
                  <span className="wf-key" style={{height:14, fontSize:9}}>⇧→</span> grow
                </span>
              </div>

              {/* Interactive cells with overlap markers */}
              <div style={{
                display:'flex', justifyContent:'center', gap: 0,
                padding: '10px 0', background:'#fff', borderRadius: 4,
                border: `1px solid ${W.rule}`,
              }}>
                {word.split('').map((ch, i) => {
                  const idx = i + 1;
                  const inActive = idx >= 1 && idx <= 3;
                  const isDropCap = idx === 1;
                  const isItalic  = idx >= 4 && idx <= 9;
                  return (
                    <div key={i} style={{
                      display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
                      padding: '0 5px', minWidth: 26,
                    }}>
                      <span style={{
                        fontFamily:'serif', fontSize: 28,
                        color: inActive ? W.ink : W.ink2,
                        fontVariant: inActive ? 'small-caps' : 'normal',
                        fontStyle: isItalic && !inActive ? 'italic' : 'normal',
                      }}>{ch}</span>
                      <span style={{fontSize: 8, color: W.ink3, fontFamily: W.mono}}>{idx}</span>
                      <span style={{
                        width: 20, height: 20, borderRadius: 4,
                        background: inActive ? W.ocrOnly : '#fff',
                        border: `1.5px solid ${inActive ? W.ocrOnly : W.ink4}`,
                        display:'inline-flex', alignItems:'center', justifyContent:'center',
                        color: '#fff', fontSize: 11,
                      }}>{inActive ? '✓' : ''}</span>
                      <div style={{display:'flex', gap: 2, height: 4}}>
                        {isDropCap && <span style={{width:6, height:3, background: W.gtOnly, borderRadius: 1.5}}></span>}
                        {isItalic && <span style={{width:6, height:3, background: W.ocrOnly+'88', borderRadius: 1.5}}></span>}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Label switcher */}
              <div style={{display:'flex', flexDirection:'column', gap: 8, marginTop: 10}}>
                <div style={{display:'flex', alignItems:'center', gap: 8, flexWrap:'wrap'}}>
                  <span style={{fontSize: 9, fontWeight: 700, color: W.ocrOnly, letterSpacing:'0.08em', minWidth: 64}}>STYLE</span>
                  <PickerChip label="small caps" hot="S" state="all"/>
                  <PickerChip label="italic"     hot="I" state="none"/>
                  <PickerChip label="ALL CAPS"   hot="C" state="none"/>
                  <PickerChip label="blackletter" hot="B" state="none"/>
                </div>
                <div style={{display:'flex', alignItems:'center', gap: 8, flexWrap:'wrap'}}>
                  <span style={{fontSize: 9, fontWeight: 700, color: W.gtOnly, letterSpacing:'0.08em', minWidth: 64}}>COMPONENT</span>
                  <PickerChip label="drop cap"        kind="component" state="none"/>
                  <PickerChip label="footnote marker" kind="component" state="none"/>
                  <PickerChip label="catchword"       kind="component" state="none"/>
                </div>
              </div>

              {/* commit row */}
              <div style={{
                display:'flex', gap: 6, marginTop: 12, alignItems:'center',
                paddingTop: 10, borderTop: `1px solid ${W.ocrOnly}33`,
              }}>
                <span className="wf-btn sm danger">Delete range</span>
                <div style={{flex:1}}></div>
                <span className="wf-btn sm ghost">Cancel</span>
                <span className="wf-btn sm primary">Save range <span className="wf-key" style={{height:14, fontSize:9, background:'#0003', borderColor:'transparent', color:'#fff', marginLeft:4}}>⏎</span></span>
              </div>
            </div>
          </div>
        </div>

        {/* CHARACTER FIXER — expanded */}
        <div style={{
          background: W.paperAlt, border: `1px solid ${W.ruleSoft}`, borderRadius: 5,
          overflow: 'hidden',
        }}>
          <div style={{
            display:'flex', alignItems:'center', gap: 8, padding: '8px 12px',
            borderBottom: `1px solid ${W.ruleSoft}`,
            background: W.wordColor + '08',
          }}>
            <span style={{width: 14, transform:'rotate(90deg)', color: W.ink2, fontSize: 11}}>▶</span>
            <span style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: W.ink2}}>CHARACTER FIXER</span>
            <span style={{fontSize: 10, color: W.ink3}}>edit individual character bboxes · add / delete / resize when OCR segmentation is wrong</span>
            <div style={{flex:1}}></div>
            <span style={{
              fontSize: 9, fontWeight: 700, letterSpacing: '0.06em',
              padding: '2px 7px', borderRadius: 9,
              background: W.fuzzy + '15', color: W.fuzzy,
              border: `1px solid ${W.fuzzy}55`,
            }}>EDGE CASES</span>
          </div>
          <div style={{padding: 12, display:'flex', flexDirection:'column', gap: 12}}>
            {/* big editable word with per-char bboxes */}
            <div style={{
              background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 5,
              padding: '14px 18px 18px',
              position:'relative',
            }}>
              <div style={{display:'flex', justifyContent:'center', alignItems:'flex-end', gap: 0}}>
                {'Mr.Wilson'.split('').map((ch, i) => {
                  const idx = i + 1;
                  const isActive = idx === 4; // W is the active char
                  return (
                    <div key={i} style={{
                      display:'flex', flexDirection:'column', alignItems:'center', gap: 5,
                      padding: '0 5px',
                    }}>
                      <span style={{
                        position:'relative',
                        display:'inline-flex', alignItems:'center', justifyContent:'center',
                        padding: '3px 5px',
                        border: isActive ? `2px solid ${W.accent}` : `1px solid ${W.wordColor}aa`,
                        background: isActive ? W.accent + '10' : W.wordColor + '08',
                        borderRadius: 2,
                      }}>
                        <span style={{
                          fontFamily:'serif', fontSize: 44,
                          color: W.ink, lineHeight: 1,
                        }}>{ch}</span>
                        {isActive && (
                          <>
                            {/* corner handles */}
                            {[{top:-4,left:-4},{top:-4,right:-4},{bottom:-4,left:-4},{bottom:-4,right:-4}].map((p, j) => (
                              <span key={j} style={{position:'absolute', ...p,
                                width: 8, height: 8, background:'#fff',
                                border:`1.5px solid ${W.accent}`, borderRadius: 1,
                              }}></span>
                            ))}
                            {/* edge handles */}
                            {[{top:'50%',left:-4,marginTop:-4},{top:'50%',right:-4,marginTop:-4},
                              {bottom:-4,left:'50%',marginLeft:-4},{top:-4,left:'50%',marginLeft:-4}].map((p, j) => (
                              <span key={j} style={{position:'absolute', ...p,
                                width: 8, height: 8, background:'#fff',
                                border:`1.5px solid ${W.accent}`, borderRadius: 4,
                              }}></span>
                            ))}
                          </>
                        )}
                      </span>
                      <span style={{fontSize:8, color: isActive ? W.accent : W.ink3, fontFamily: W.mono,
                        fontWeight: isActive ? 700 : 400,
                      }}>{idx}</span>
                    </div>
                  );
                })}
              </div>
              {/* hint */}
              <div style={{
                position:'absolute', bottom: 4, right: 10,
                fontSize: 9, color: W.ink3, fontStyle:'italic', fontFamily: W.mono,
              }}>arrow keys nudge · drag handles to resize</div>
            </div>

            {/* characters strip */}
            <div>
              <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom: 6}}>
                <span className="wf-h-label">Characters</span>
                <span style={{fontSize: 10, color: W.ink3}}>9 chars · GT length matches</span>
                <div style={{flex:1}}></div>
                <span className="wf-btn sm">＋ Insert char</span>
                <span className="wf-btn sm danger">Delete selected</span>
              </div>
              <div style={{
                display:'grid', gridTemplateColumns:'repeat(9, 1fr)', gap: 4,
              }}>
                {'Mr.Wilson'.split('').map((ch, i) => {
                  const idx = i + 1;
                  const isActive = idx === 4;
                  return (
                    <div key={i} style={{
                      display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
                      padding: '6px 4px',
                      background: isActive ? W.accent + '12' : '#fff',
                      border: isActive ? `1.5px solid ${W.accent}` : `1px solid ${W.ruleSoft}`,
                      borderRadius: 4,
                    }}>
                      <span style={{fontSize: 9, fontFamily: W.mono, color: isActive ? W.accent : W.ink3, fontWeight: isActive ? 700 : 400}}>
                        #{idx}
                      </span>
                      <input className="wf-input" defaultValue={ch} style={{
                        width: 32, height: 26, textAlign:'center', fontSize: 14, fontFamily:'serif',
                        padding: 0,
                      }}/>
                      <span style={{fontSize: 9, fontFamily: W.mono, color: W.ink3}}>
                        {[10,8,4,16,8,4,7,8,7][i]}px
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Active char detail row */}
            <div style={{
              background:'#fff', border:`1px solid ${W.accent}55`, borderRadius: 4,
              padding: '8px 10px',
              display:'flex', alignItems:'center', gap: 12, flexWrap:'wrap',
            }}>
              <span style={{fontSize: 10, color: W.accent, fontWeight: 700, letterSpacing:'0.05em'}}>EDITING #4</span>
              <span style={{
                fontFamily:'serif', fontSize: 24, color: W.ink,
                width: 32, textAlign:'center',
              }}>W</span>
              <div style={{display:'flex', gap: 6, alignItems:'center', fontSize: 11, fontFamily: W.mono}}>
                <span style={{color: W.ink3}}>x</span><input className="wf-input" defaultValue="172" style={{width:48, height: 22, fontSize: 11, textAlign:'right'}}/>
                <span style={{color: W.ink3}}>y</span><input className="wf-input" defaultValue="412" style={{width:48, height: 22, fontSize: 11, textAlign:'right'}}/>
                <span style={{color: W.ink3}}>w</span><input className="wf-input" defaultValue="16"  style={{width:40, height: 22, fontSize: 11, textAlign:'right'}}/>
                <span style={{color: W.ink3}}>h</span><input className="wf-input" defaultValue="42"  style={{width:40, height: 22, fontSize: 11, textAlign:'right'}}/>
              </div>
              <div style={{flex:1}}></div>
              <span className="wf-btn sm">Refine to pixels</span>
              <span className="wf-btn sm">Split this char</span>
              <span className="wf-btn sm">Merge with #3</span>
            </div>

            {/* commit */}
            <div style={{display:'flex', gap: 6, alignItems:'center'}}>
              <span style={{fontSize: 10, color: W.ink3, fontStyle:'italic'}}>
                changes here affect char-range labels &amp; the OCR training output
              </span>
              <div style={{flex:1}}></div>
              <span className="wf-btn sm ghost">Reset to OCR</span>
              <span className="wf-btn sm">Cancel</span>
              <span className="wf-btn sm primary">Apply</span>
            </div>
          </div>
        </div>

        {/* commit */}
        <div style={{marginTop:6, display:'flex', gap:8}}>
          <span className="wf-btn primary lg" style={{flex:1}}>
            ✓ Validate &amp; Next <span className="wf-key" style={{height:16, fontSize:9, background:'#0003', color:'#fff', borderColor:'transparent', marginLeft:4}}>⏎</span>
          </span>
          <span className="wf-btn lg ghost">Skip</span>
          <span className="wf-btn lg danger">🗑</span>
        </div>
      </div>
    </div>
  );
}

// =====================================================================
// NEW · Paragraph / Block layout-type picker
// =====================================================================
function LayoutTypeShape({ kind, active, size=36 }) {
  const c = active ? W.ink : W.ink3;
  // tiny abstracted typesetting glyph per layout
  const lines = {
    h1:       [{y:18,w:30}],
    h2:       [{y:14,w:24},{y:24,w:20}],
    h3:       [{y:18,w:18}],
    title:    [{y:10,w:34},{y:20,w:24},{y:30,w:14}],
    subtitle: [{y:14,w:26},{y:24,w:18}],
    byline:   [{y:18,w:14},{y:26,w:20}],
    body:     [{y:8,w:30},{y:16,w:32},{y:24,w:28},{y:32,w:26}],
    quote:    [{y:8,w:24,x:6},{y:16,w:24,x:6},{y:24,w:20,x:6}],
    epigraph: [{y:10,w:18,x:14},{y:18,w:16,x:14}],
    list:     [{y:10,w:2,x:4},{y:10,w:24,x:8},{y:18,w:2,x:4},{y:18,w:22,x:8},{y:26,w:2,x:4},{y:26,w:20,x:8}],
    verse:    [{y:8,w:20,x:6},{y:16,w:24,x:6},{y:24,w:18,x:6}],
    footnote: [{y:6,w:6,x:2},{y:14,w:30,x:2},{y:22,w:28,x:2},{y:30,w:18,x:2}],
    caption:  [{y:6,w:34,x:0,box:true},{y:24,w:24,x:5}],
    table:    'table',
    rhead:    [{y:6,w:28},{y:30,w:34,faint:true}],
    rfoot:    [{y:6,w:34,faint:true},{y:30,w:12,x:12}],
    toc:      [{y:8,w:20,x:0},{y:8,w:6,x:28,right:true},{y:18,w:18,x:0},{y:18,w:6,x:28,right:true},{y:28,w:22,x:0},{y:28,w:6,x:28,right:true}],
    dedication:[{y:14,w:18,x:9},{y:22,w:14,x:11}],
    index:    [{y:6,w:6,x:0},{y:6,w:24,x:8},{y:14,w:6,x:2},{y:14,w:20,x:10},{y:22,w:6,x:2},{y:22,w:16,x:10}],
  };
  const data = lines[kind];
  const W2 = 38, H2 = 36;
  return (
    <svg viewBox={`0 0 ${W2} ${H2}`} width={size} height={size}
      style={{display:'block'}}>
      {/* paper background */}
      <rect x={1} y={1} width={W2-2} height={H2-2}
        rx={2} ry={2}
        fill={active ? '#fff' : W.paperAlt}
        stroke={active ? c : W.ruleSoft} strokeWidth={active ? 1.2 : 0.8}/>
      {data === 'table' ? (
        <g stroke={c} strokeWidth={0.8}>
          <line x1={4}  y1={10} x2={34} y2={10}/>
          <line x1={4}  y1={18} x2={34} y2={18}/>
          <line x1={4}  y1={26} x2={34} y2={26}/>
          <line x1={14} y1={6}  x2={14} y2={30}/>
          <line x1={24} y1={6}  x2={24} y2={30}/>
        </g>
      ) : Array.isArray(data) && data.map((l, i) => (
        <rect key={i}
          x={4 + (l.x ?? 0)} y={l.y}
          width={l.w} height={2}
          rx={1} ry={1}
          fill={l.faint ? c+'88' : c}
          opacity={l.faint ? 0.5 : 1}
        />
      ))}
    </svg>
  );
}

function LayoutTypeCard({ label, kind, active, hint }) {
  return (
    <div style={{
      display:'flex', flexDirection:'column', alignItems:'flex-start', gap: 6,
      padding: 10, borderRadius: 6,
      background: active ? W.ink + '08' : W.panel,
      border: active ? `1.5px solid ${W.ink}` : `1px solid ${W.rule}`,
      position:'relative', minWidth: 0,
    }}>
      <LayoutTypeShape kind={kind} active={active}/>
      <div style={{display:'flex', flexDirection:'column', gap: 1, minWidth:0, width:'100%'}}>
        <span style={{
          fontSize: 11, fontWeight: 600,
          color: active ? W.ink : W.ink2,
          whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
          width:'100%',
        }}>{label}</span>
        {hint && <span style={{fontSize: 9, color: W.ink3}}>{hint}</span>}
      </div>
      {active && (
        <span style={{
          position:'absolute', top: 6, right: 6,
          width: 14, height: 14, borderRadius: 7, background: W.ink, color: '#fff',
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 9, fontWeight: 700,
        }}>✓</span>
      )}
    </div>
  );
}

function ParagraphLayoutPicker() {
  // grouped by 'g' in LAYOUT_TYPES
  const groups = {};
  LAYOUT_TYPES.forEach(t => { (groups[t.g] ||= []).push(t); });

  return (
    <div className="wf" style={{padding: 0, background: W.panel, display:'flex', flexDirection:'column', overflow:'hidden'}}>
      {/* breadcrumb tab header (same vocabulary as the hybrid right panel) */}
      <div style={{
        display:'flex', alignItems:'center', gap: 2,
        padding: '0 12px', borderBottom: `1px solid ${W.rule}`, background: W.panel,
      }}>
        <span style={{padding:'8px 12px', fontSize:12, color:W.ink3, fontWeight:600}}>Matches</span>
        <span style={{color:W.ink4, padding:'0 3px'}}>›</span>
        <span style={{padding:'8px 12px', fontSize:12, fontWeight:600,
          color:W.ink, borderBottom:`2px solid ${W.ink}`, marginBottom:-1,
          display:'flex', alignItems:'center', gap:5,
        }}>
          Para <span style={{fontSize:10, color:W.ink3, fontWeight:500}}>7</span>
        </span>
        <div style={{flex:1}}></div>
        <span style={{fontSize:11, color:W.ink3}}>2 paragraphs share this layout on page</span>
      </div>

      <div style={{padding: 16, flex: 1, overflow:'auto', display:'flex', flexDirection:'column', gap: 14}}>
        {/* heading row */}
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Paragraph 7 · layout type</span>
          <span style={{fontSize: 10, color: W.ink3,
            padding:'2px 8px', background: W.paperAlt, borderRadius: 9,
            border: `1px solid ${W.rule}`,
          }}>
            feeds the page-segmentation classifier
          </span>
        </div>

        {/* paragraph preview */}
        <div style={{
          background: '#fff', border: `1.5px solid ${W.accent}`, borderRadius: 6,
          padding: '12px 16px',
          display:'flex', alignItems:'center', justifyContent:'center', gap: 14,
          fontFamily:'"UnifrakturCook", "Times New Roman", serif',
          fontSize: 38, color: W.ink,
        }}>
          <span>The</span><span>Founding</span><span>of</span><span>the</span><span>Government</span>
        </div>

        {/* model suggestion */}
        <div style={{
          display:'flex', alignItems:'center', gap: 10,
          padding: '10px 12px',
          background: W.fuzzy + '12', borderRadius: 5,
          border: `1px solid ${W.fuzzy}55`,
        }}>
          <span style={{
            display:'inline-flex', alignItems:'center', justifyContent:'center',
            width: 24, height: 24, borderRadius: 12,
            background: W.fuzzy, color:'#fff',
            fontSize: 13, fontWeight: 700,
          }}>?</span>
          <div style={{display:'flex', flexDirection:'column', gap: 2}}>
            <span style={{fontSize: 12, fontWeight: 600, color: W.ink}}>
              Model suggests <span style={{textDecoration: 'underline', textUnderlineOffset: 2}}>chapter heading</span> · 87% confidence
            </span>
            <span style={{fontSize: 10, color: W.ink2}}>
              Confirm to keep, or pick a different type below — your choice becomes training data.
            </span>
          </div>
          <div style={{flex:1}}></div>
          <span className="wf-btn sm primary">Accept ⏎</span>
          <span className="wf-btn sm">Reject</span>
        </div>

        {/* type picker — single-select, grouped */}
        <div style={{
          display:'flex', alignItems:'center', gap: 10,
        }}>
          <span style={{fontSize: 12, fontWeight: 600}}>Layout type</span>
          <span style={{fontSize: 10, color: W.ink3}}>single value · click to set</span>
          <div style={{flex:1}}></div>
          <input className="wf-input" placeholder="Search types…" style={{width: 160, height:24, fontSize: 11}}/>
        </div>
        {Object.entries(groups).map(([g, items]) => (
          <div key={g}>
            <div style={{
              fontSize: 9, fontWeight: 700, letterSpacing: '0.12em',
              color: W.ink3, marginBottom: 6,
              display:'flex', alignItems:'center', gap: 8,
            }}>
              {g.toUpperCase()}
              <span style={{flex:1, height: 1, background: W.ruleSoft}}></span>
              <span style={{fontWeight: 500, color: W.ink4, letterSpacing: 0}}>{items.length}</span>
            </div>
            <div style={{
              display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(150px, 1fr))', gap: 8,
            }}>
              {items.map(t => (
                <LayoutTypeCard key={t.k}
                  label={t.l} kind={t.shape}
                  hint={t.defaultType ? 'default' : null}
                  active={t.k === 'chap_head'}/>
              ))}
            </div>
          </div>
        ))}

        {/* custom */}
        <div style={{
          padding: 10, borderRadius: 6, border: `1px dashed ${W.ink4}`,
          background: W.paperAlt, display:'flex', alignItems:'center', gap: 10,
        }}>
          <span style={{fontSize: 11, fontWeight: 600, color: W.ink2}}>Custom type</span>
          <input className="wf-input" placeholder="e.g. printer's mark, ornament…" style={{flex:1, height:26, fontSize: 11}}/>
          <span className="wf-btn sm">Add to enum</span>
        </div>

        <div style={{marginTop: 'auto', display:'flex', gap: 8, paddingTop: 6}}>
          <span className="wf-btn primary lg" style={{flex:1}}>
            ✓ Save layout type
          </span>
          <span className="wf-btn lg ghost">Skip</span>
        </div>
      </div>
    </div>
  );
}

// =====================================================================
// NEW · Bulk layout-type picker (multi-paragraph selection)
// =====================================================================
function BulkLayoutPicker() {
  const groups = {};
  LAYOUT_TYPES.forEach(t => { (groups[t.g] ||= []).push(t); });

  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Bulk · layout type</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Multi-paragraph selection. Single value because the classifier
          wants one label per block — applying assigns the same type to all.
        </div>
      </header>

      {/* selection summary */}
      <div style={{
        display:'flex', alignItems:'center', gap: 12, padding: '10px 14px',
        background: W.panel, border: `1px solid ${W.rule}`,
        borderRadius: 5, marginBottom: 14,
      }}>
        <span style={{
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          width: 26, height: 26, borderRadius: 6,
          background: W.paraColor + '22', color: W.paraColor,
          border: `1px solid ${W.paraColor}55`,
          fontSize: 13, fontWeight: 700,
        }}>5</span>
        <div style={{display:'flex', flexDirection:'column', gap: 1, minWidth: 0}}>
          <span style={{fontSize: 11, color: W.ink3, fontWeight: 600, letterSpacing: '0.05em'}}>SELECTION · paragraphs</span>
          <span style={{fontSize: 12, color: W.ink}}>Para 4, 5, 7, 9, 11</span>
        </div>
        <div style={{flex:1}}></div>
        <div style={{display:'flex', gap: 8, fontSize: 11, color: W.ink2}}>
          <span><b style={{color:W.ink}}>3</b> body text</span>
          <span><b style={{color:W.ink}}>1</b> chapter heading</span>
          <span style={{color:W.ink3}}><b>1</b> unset</span>
        </div>
        <span className="wf-btn sm ghost">Clear</span>
      </div>

      {/* picker */}
      <div style={{
        background: W.panel, border: `1px solid ${W.rule}`, borderRadius: 6, padding: 14,
        display:'flex', flexDirection:'column', gap: 14,
      }}>
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 12, fontWeight: 700}}>Set layout type for all 5</span>
          <span style={{fontSize: 10, color: W.ink3}}>overwrites any existing values</span>
          <div style={{flex:1}}></div>
          <input className="wf-input" placeholder="Search…" style={{width:160, height:24, fontSize:11}}/>
        </div>
        {Object.entries(groups).map(([g, items]) => (
          <div key={g}>
            <div style={{
              fontSize: 9, fontWeight: 700, letterSpacing: '0.12em',
              color: W.ink3, marginBottom: 6,
              display:'flex', alignItems:'center', gap: 8,
            }}>
              {g.toUpperCase()}
              <span style={{flex:1, height: 1, background: W.ruleSoft}}></span>
            </div>
            <div style={{
              display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(140px, 1fr))', gap: 8,
            }}>
              {items.map(t => (
                <LayoutTypeCard key={t.k}
                  label={t.l} kind={t.shape}
                  active={t.k === 'body'}
                  hint={t.k === 'body' ? '3 of 5 already' : null}/>
              ))}
            </div>
          </div>
        ))}
        <div style={{marginTop: 4, display:'flex', gap: 8}}>
          <span className="wf-btn primary" style={{flex: 1}}>Apply to 5 paragraphs</span>
          <span className="wf-btn ghost">Cancel</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  FinalBulkPicker, FinalDetailEditor, ParagraphLayoutPicker, BulkLayoutPicker,
  PickerChip, LayoutTypeCard, LayoutTypeShape,
});

// =====================================================================
// CHAR-RANGE MULTI-RANGE EDITOR — deep dive on the interaction model
// =====================================================================
//
// Mental model:
//   • A word has 0..N "annotation ranges". Each range has (char span,
//     kind=style|component, label).
//   • Ranges of the same kind+label CANNOT overlap (one footnote marker
//     spans contiguous chars).
//   • Different kinds CAN overlap (drop cap on char 1, italic on char 1).
//   • Existing ranges are listed; one can be "active" (being edited).
//     Editing changes its span and/or label. Save commits, Cancel reverts.
//   • "+ Add range" creates a new active range starting empty; you set
//     the span by clicking/dragging chars, then pick a label.

function RangeListRow({ kind='style', label, span, fontStyle, fontVariant, word, active }) {
  const c = kind === 'style' ? W.ocrOnly : W.gtOnly;
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 12,
      padding: '8px 10px',
      background: active ? c + '0e' : '#fff',
      border: active ? `1.5px solid ${c}` : `1px solid ${W.ruleSoft}`,
      borderRadius: 5,
    }}>
      {/* radio circle */}
      <span style={{
        width: 14, height: 14, borderRadius: 7,
        background: active ? c : '#fff',
        border: `1.5px solid ${c}`,
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        flex:'0 0 auto',
      }}>
        {active && <span style={{width:6, height:6, borderRadius:3, background:'#fff'}}></span>}
      </span>
      {/* label chip */}
      <span style={{
        display:'inline-flex', alignItems:'center', gap: 6,
        padding: '2px 9px', borderRadius: 10,
        background: c + '15',
        color: c, fontSize: 11, fontWeight: 600,
        border: `1px solid ${c}55`,
        flex: '0 0 auto',
        fontStyle, fontVariant,
      }}>{label}</span>
      <span style={{fontFamily: W.mono, fontSize: 11, color: W.ink2}}>
        {span.from === span.to ? `char ${span.from}` : `chars ${span.from}–${span.to}`}
      </span>
      <span style={{fontFamily: W.mono, fontSize: 11, color: W.ink3}}>
        "{word.slice(span.from-1, span.to)}"
      </span>
      {/* mini char strip */}
      <div style={{
        display:'flex', gap: 0, marginLeft: 'auto', alignItems:'center',
      }}>
        {word.split('').map((ch, i) => {
          const idx = i + 1;
          const inSpan = idx >= span.from && idx <= span.to;
          return (
            <span key={i} style={{
              width: 14, height: 18,
              display:'inline-flex', alignItems:'center', justifyContent:'center',
              fontFamily:'serif', fontSize: 11,
              color: inSpan ? c : W.ink3,
              borderBottom: inSpan ? `2px solid ${c}` : `2px solid transparent`,
              fontVariant: kind==='style' && label==='small caps' && inSpan ? 'small-caps' : 'normal',
              fontStyle: kind==='style' && label==='italic' && inSpan ? 'italic' : 'normal',
            }}>{ch}</span>
          );
        })}
      </div>
      <span className="wf-btn sm" style={{height: 22, padding:'0 8px', fontSize: 10}}>{active ? 'editing…' : 'edit'}</span>
      <span style={{
        width: 22, height: 22, borderRadius: 4,
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        color: W.ink3, fontSize: 13,
        border: `1px solid ${W.ink4}`, background:'#fff',
      }}>×</span>
    </div>
  );
}

function MultiRangeEditor() {
  const word = 'Mr.Wilson';   // 9 chars
  // Ranges to mock
  const ranges = [
    { kind:'style',     label:'small caps', span:{from:1,to:3}, active:true,  fontVariant:'small-caps' },
    { kind:'component', label:'drop cap',   span:{from:1,to:1} },
    { kind:'style',     label:'italic',     span:{from:4,to:9}, fontStyle:'italic' },
  ];

  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 12}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Char range · multi-range editing</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          The model: each word has a list of (span, kind, label) ranges.
          One is "active" — its cells &amp; label are editable below. Other
          ranges are still visible on the word so you can see overlap.
        </div>
      </header>

      <div style={{
        background: W.panel, border:`1px solid ${W.rule}`, borderRadius: 6,
        padding: 16, display:'flex', flexDirection:'column', gap: 14,
      }}>
        {/* Big word zoom with ALL ranges visualized */}
        <div style={{
          background: '#fff', border:`1.5px solid ${W.accent}`, borderRadius: 6,
          padding: '18px 22px 28px',
          position:'relative',
        }}>
          {/* the word, char-by-char, with positioning */}
          <div style={{
            display:'flex', justifyContent:'center', alignItems:'flex-end', gap: 0,
          }}>
            {word.split('').map((ch, i) => {
              const idx = i + 1;
              return (
                <div key={i} style={{
                  display:'flex', flexDirection:'column', alignItems:'center', gap: 6,
                  padding: '0 6px', position:'relative',
                }}>
                  <span style={{
                    fontFamily:'serif', fontSize: 52,
                    color: W.ink,
                    // active range = small caps on 1-3
                    fontVariant: idx >= 1 && idx <= 3 ? 'small-caps' : 'normal',
                    fontStyle: idx >= 4 && idx <= 9 ? 'italic' : 'normal',
                  }}>{ch}</span>
                  <span style={{fontSize: 9, color: W.ink3, fontFamily: W.mono}}>{idx}</span>
                </div>
              );
            })}
          </div>

          {/* range bars underneath the row of numbers */}
          <div style={{
            position:'absolute', left: 22, right: 22, bottom: 6,
            display:'flex', flexDirection:'column', gap: 3,
          }}>
            {ranges.map((r, i) => {
              const c = r.kind === 'style' ? W.ocrOnly : W.gtOnly;
              const wpct = 100 / word.length;
              const left = (r.span.from - 1) * wpct;
              const w = (r.span.to - r.span.from + 1) * wpct;
              return (
                <div key={i} style={{
                  height: 5, position: 'relative',
                  background: r.active ? `${c}1a` : 'transparent',
                  borderRadius: 3,
                }}>
                  <div style={{
                    position:'absolute', left: `${left}%`, width: `${w}%`,
                    height: 5, borderRadius: 3,
                    background: c,
                    opacity: r.active ? 1 : 0.55,
                  }}></div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Existing-ranges list */}
        <div>
          <div style={{display:'flex', alignItems:'center', gap: 10, marginBottom: 8}}>
            <span style={{fontSize: 12, fontWeight: 700}}>Ranges on this word</span>
            <span style={{fontSize: 10, color: W.ink3}}>{ranges.length} applied · click "edit" to make a row active</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm primary">＋ Add range <span className="wf-key" style={{height:14, fontSize:9, background:'#0003', borderColor:'transparent', color:'#fff', marginLeft:4}}>R</span></span>
          </div>
          <div style={{display:'flex', flexDirection:'column', gap: 5}}>
            {ranges.map((r, i) => (
              <RangeListRow key={i}
                kind={r.kind} label={r.label} span={r.span}
                fontStyle={r.fontStyle} fontVariant={r.fontVariant}
                word={word} active={r.active}/>
            ))}
          </div>
        </div>

        {/* Active range editor */}
        <div style={{
          border: `2px solid ${W.ocrOnly}88`,
          borderRadius: 6, padding: 14,
          background: W.ocrOnly + '08',
        }}>
          <div style={{display:'flex', alignItems:'center', gap: 10, marginBottom: 12}}>
            <span style={{fontSize: 11, fontWeight: 700, color: W.ocrOnly, letterSpacing:'0.05em'}}>EDITING</span>
            <span style={{
              display:'inline-flex', alignItems:'center', gap: 6,
              padding: '2px 9px', borderRadius: 10,
              background: '#fff', color: W.ocrOnly, fontSize: 11, fontWeight: 600,
              border: `1px solid ${W.ocrOnly}55`,
              fontVariant:'small-caps',
            }}>small caps</span>
            <span style={{fontSize: 11, color: W.ink2}}>
              <span style={{fontFamily: W.mono}}>chars 1–3 · "Mr."</span>
            </span>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 10, color: W.ink3}}>
              click cells to change span ·
              <span className="wf-key" style={{height:14, fontSize:9}}>←</span>
              <span className="wf-key" style={{height:14, fontSize:9}}>→</span> shrink ·
              <span className="wf-key" style={{height:14, fontSize:9}}>⇧←</span>
              <span className="wf-key" style={{height:14, fontSize:9}}>⇧→</span> grow
            </span>
          </div>

          {/* Interactive cells */}
          <div style={{
            display:'flex', justifyContent:'center', gap: 0,
            padding: '12px 0', background:'#fff', borderRadius: 4,
            border: `1px solid ${W.rule}`,
          }}>
            {word.split('').map((ch, i) => {
              const idx = i + 1;
              const inActive = idx >= 1 && idx <= 3;
              // other-range markers: drop cap (char 1) and italic (4-9) — both shown as small underlines
              const isDropCap = idx === 1;
              const isItalic  = idx >= 4 && idx <= 9;
              return (
                <div key={i} style={{
                  display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
                  padding: '0 6px', minWidth: 30,
                  position:'relative',
                }}>
                  <span style={{
                    fontFamily:'serif', fontSize: 30,
                    color: inActive ? W.ink : W.ink2,
                    fontVariant: inActive ? 'small-caps' : 'normal',
                    fontStyle: isItalic && !inActive ? 'italic' : 'normal',
                  }}>{ch}</span>
                  <span style={{fontSize: 9, color: W.ink3, fontFamily: W.mono}}>{idx}</span>
                  <span style={{
                    width: 22, height: 22, borderRadius: 4,
                    background: inActive ? W.ocrOnly : '#fff',
                    border: `1.5px solid ${inActive ? W.ocrOnly : W.ink4}`,
                    display:'inline-flex', alignItems:'center', justifyContent:'center',
                    color: '#fff', fontSize: 12,
                  }}>{inActive ? '✓' : ''}</span>
                  {/* mini markers for other ranges on this char */}
                  <div style={{display:'flex', gap: 2, height: 6}}>
                    {isDropCap && <span style={{width:6, height:3, background: W.gtOnly, borderRadius: 1.5}} title="drop cap"></span>}
                    {isItalic && <span style={{width:6, height:3, background: W.ocrOnly+'88', borderRadius: 1.5}} title="italic"></span>}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Label switcher */}
          <div style={{
            display:'flex', flexDirection:'column', gap: 8, marginTop: 12,
          }}>
            <div style={{display:'flex', alignItems:'center', gap: 8}}>
              <span style={{fontSize: 9, fontWeight: 700, color: W.ocrOnly, letterSpacing:'0.08em', minWidth: 64}}>STYLE</span>
              <PickerChip label="small caps" hot="S" state="all"/>
              <PickerChip label="italic"     hot="I" state="none"/>
              <PickerChip label="ALL CAPS"   hot="C" state="none"/>
              <PickerChip label="blackletter" hot="B" state="none"/>
              <span style={{fontSize:10, color:W.ink3, fontStyle:'italic', marginLeft:4}}>(pick one to change this range's label)</span>
            </div>
            <div style={{display:'flex', alignItems:'center', gap: 8}}>
              <span style={{fontSize: 9, fontWeight: 700, color: W.gtOnly, letterSpacing:'0.08em', minWidth: 64}}>COMPONENT</span>
              <PickerChip label="drop cap"        kind="component" state="none"/>
              <PickerChip label="footnote marker" kind="component" state="none"/>
              <PickerChip label="catchword"       kind="component" state="none"/>
              <span style={{fontSize:10, color:W.ink3, fontStyle:'italic', marginLeft:4}}>switching kind converts the range</span>
            </div>
          </div>

          {/* commit row */}
          <div style={{
            display:'flex', gap: 6, marginTop: 14, alignItems:'center',
            paddingTop: 12, borderTop: `1px solid ${W.ocrOnly}33`,
          }}>
            <span className="wf-btn sm danger">Delete this range</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm ghost">Cancel</span>
            <span className="wf-btn sm primary">Save range <span className="wf-key" style={{height:14, fontSize:9, background:'#0003', borderColor:'transparent', color:'#fff', marginLeft:4}}>⏎</span></span>
          </div>
        </div>

        {/* Conflict hint */}
        <div style={{
          padding: '8px 10px', borderRadius: 4,
          background: W.fuzzy + '12', border: `1px dashed ${W.fuzzy}88`,
          fontSize: 11, color: W.ink2,
          display:'flex', alignItems:'center', gap: 8,
        }}>
          <span style={{
            width: 18, height: 18, borderRadius: 9, background: W.fuzzy, color:'#fff',
            display:'inline-flex', alignItems:'center', justifyContent:'center',
            fontSize: 11, fontWeight: 700,
          }}>!</span>
          Same-label ranges of the same kind merge automatically if they touch.
          Different kinds (style ↔ component) freely overlap.
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MultiRangeEditor });
