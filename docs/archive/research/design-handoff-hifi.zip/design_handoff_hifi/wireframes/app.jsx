// Wires every wireframe into a DesignCanvas.
// Organized top-down: Page → Block → Paragraph → Line → Word → System.
// Each level pairs the in-context ProjectPage view with the chosen
// surface(s) for that level.

function App() {
  return (
    <DesignCanvas>
      {/* ───────────────────────────────────────────────────────────
          1 · PAGE + BLOCK LEVEL
          ─────────────────────────────────────────────────────────── */}
      <DCSection
        id="page-and-block"
        title="1 · Page + Block · studio &amp; structural containers"
        subtitle="Full ProjectPage layout, plus the block surfaces (canvas overlays, hierarchy tree, right-panel Layout / Items tabs). A block whose children are other blocks (column, sidebar, block-quote, figure). Same layout-type enum at every depth."
      >
        <DCArtboard id="page-default"  label="Page · default · matches list + bulk accordion expanded" width={1920} height={1200}>
          <HybridN1/>
        </DCArtboard>
        <DCArtboard id="block-in-context" label="Page · in context · structural block selected → block picker right" width={1920} height={1200}>
          <HybridN5/>
        </DCArtboard>
        <DCArtboard id="block-canvas" label="Canvas overlays · how blocks render on the scan" width={900} height={970}>
          <CanvasWithBlockOverlays/>
        </DCArtboard>
        <DCArtboard id="block-hierarchy" label="Page hierarchy tree" width={1000} height={900}>
          <PageHierarchyTree/>
        </DCArtboard>
        <DCArtboard id="block-layout" label="Right panel · Block · Layout tab" width={780} height={1100}>
          <TabbedBlock_Struct_Layout/>
        </DCArtboard>
        <DCArtboard id="block-items" label="Right panel · Block · Items · Words view · Cards (default)" width={1080} height={1180}>
          <BlockItems_Words_Cards/>
        </DCArtboard>
        <DCArtboard id="block-items-rows" label="Right panel · Block · Items · Words view · Rows" width={1080} height={900}>
          <BlockItems_Words_Rows/>
        </DCArtboard>
        <DCArtboard id="block-items-children" label="Right panel · Block · Items · child-blocks view (alt)" width={900} height={540}>
          <TabbedBlock_Struct_Items/>
        </DCArtboard>
      </DCSection>

      {/* ───────────────────────────────────────────────────────────
          2 · PARAGRAPH LEVEL — leaf block (children = lines)
          ─────────────────────────────────────────────────────────── */}
      <DCSection
        id="paragraph-level"
        title="2 · Paragraph · leaf block (contains lines)"
        subtitle="A paragraph is just a block whose children are lines — emergent from the model. Same picker, just a content-tier layout type."
      >
        <DCArtboard id="para-in-context" label="In context · paragraph selected" width={1920} height={1200}>
          <HybridN4/>
        </DCArtboard>
        <DCArtboard id="para-layout" label="Right panel · Paragraph · Layout tab" width={780} height={1100}>
          <TabbedBlock_Para_Layout/>
        </DCArtboard>
        <DCArtboard id="para-items-cards" label="Right panel · Paragraph · Items · Words view · Cards" width={1000} height={1180}>
          <ParaItems_Cards/>
        </DCArtboard>
        <DCArtboard id="para-items-rows" label="Right panel · Paragraph · Items · Words view · Rows" width={1000} height={1080}>
          <ParaItems_Rows/>
        </DCArtboard>
      </DCSection>

      {/* ───────────────────────────────────────────────────────────
          4 · LINE LEVEL — leaf in the geometry tree (contains words)
          ─────────────────────────────────────────────────────────── */}
      <DCSection
        id="line-level"
        title="3 · Line · contains words"
        subtitle="Line detail editor and a Words tab that mass-acts on the 5 words it owns. Same Cards / Rows density toggle as above."
      >
        <DCArtboard id="line-in-context" label="In context · line selected" width={1920} height={1200}>
          <HybridN3/>
        </DCArtboard>
        <DCArtboard id="line-detail" label="Right panel · Line · Detail tab" width={780} height={900}>
          <TabbedLinePanel_Detail/>
        </DCArtboard>
        <DCArtboard id="line-words-cards" label="Right panel · Line · Words tab · Cards" width={900} height={480}>
          <LineWords_Cards/>
        </DCArtboard>
        <DCArtboard id="line-words-rows" label="Right panel · Line · Words tab · Rows" width={900} height={480}>
          <LineWords_Rows/>
        </DCArtboard>
      </DCSection>

      {/* ───────────────────────────────────────────────────────────
          5 · WORD LEVEL — atomic, owns its bbox + GT + char ranges
          ─────────────────────────────────────────────────────────── */}
      <DCSection
        id="word-level"
        title="4 · Word · detail editor"
        subtitle="The atomic unit. OCR / GT, bbox & rebox, erase, structure, char-range styles & components, unicode picker, char fixer."
      >
        <DCArtboard id="word-in-context" label="In context · word selected from worklist" width={1920} height={1200}>
          <HybridN2/>
        </DCArtboard>
        <DCArtboard id="word-detail" label="Right panel · Word · Detail editor (full)" width={880} height={4180}>
          <FinalDetailEditor/>
        </DCArtboard>
        <DCArtboard id="word-bulk-picker" label="Bulk action · selected words style + component picker" width={780} height={840}>
          <FinalBulkPicker/>
        </DCArtboard>
      </DCSection>

      {/* ───────────────────────────────────────────────────────────
          6 · SUPPORTING — root page, hotkeys, style tile, toasts
          ─────────────────────────────────────────────────────────── */}
      <DCSection
        id="system"
        title="5 · Supporting screens"
        subtitle="Status language, type, buttons, RootPage, hotkey overlay, toast stack."
      >
        <DCArtboard id="rootpage" label="RootPage / project picker" width={1280} height={820}>
          <RootPage/>
        </DCArtboard>
        <DCArtboard id="style-tile" label="Style tile · tokens" width={760} height={1100}>
          <StyleTile/>
        </DCArtboard>
        <DCArtboard id="hotkeys" label="Hotkey cheat sheet (⌘ /)" width={720} height={520}>
          <HotkeyOverlay/>
        </DCArtboard>
        <DCArtboard id="toasts" label="Toast / progress stack" width={420} height={680}>
          <ToastStack/>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
