// Shared sketch wireframe primitives.
// Mid-fi mono aesthetic: cream paper, charcoal ink, Caveat handwriting +
// Inter for UI body text, JetBrains Mono for OCR/GT.

const W = {
  paper: '#f5f1ea',
  paperAlt: '#ede8df',
  ink: '#2a2724',
  ink2: '#5a554c',
  ink3: '#8a857b',
  ink4: '#bdb8ad',
  rule: '#cfc9bc',
  ruleSoft: '#dcd6c8',
  panel: '#fbf8f1',
  panelSunk: '#ebe5d5',
  hi: '#fff8d6',          // pale yellow highlight (selected line in old UI)
  // status colors
  exact: '#5d8a3a',
  fuzzy: '#c89327',
  mismatch: '#b8483c',
  ocrOnly: '#3f6fa6',
  gtOnly: '#7b5aa4',
  // layer colors
  paraColor: '#7ba35c',
  lineColor: '#c87a9d',
  wordColor: '#5a8bc4',
  // brand-ish accent (kept neutral)
  accent: '#c25a3a',
  hand: '"Caveat", "Segoe Script", cursive',
  ui: '"Inter", system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace',
};

// Inject one global stylesheet for sketch primitives.
if (typeof document !== 'undefined' && !document.getElementById('wf-styles')) {
  const s = document.createElement('style');
  s.id = 'wf-styles';
  s.textContent = `
    .wf {
      background: ${W.paper};
      color: ${W.ink};
      font-family: ${W.ui};
      width: 100%; height: 100%;
      box-sizing: border-box;
      position: relative;
      overflow: hidden;
    }
    .wf * { box-sizing: border-box; }
    .wf-hand { font-family: ${W.hand}; font-weight: 600; letter-spacing: 0.01em; }
    .wf-mono { font-family: ${W.mono}; }
    .wf-rule { background: ${W.rule}; }
    .wf-divv { width:1px; background: ${W.rule}; align-self: stretch; }
    .wf-divh { height:1px; background: ${W.rule}; width: 100%; }

    /* generic ghost text */
    .wf-ghost { color: ${W.ink3}; }
    .wf-faint { color: ${W.ink4}; }

    /* Boxes */
    .wf-box { background: ${W.panel}; border:1px solid ${W.rule}; border-radius: 4px; }
    .wf-box-sunk { background: ${W.panelSunk}; border:1px dashed ${W.ink4}; border-radius: 4px; }

    /* Buttons */
    .wf-btn {
      display:inline-flex; align-items:center; justify-content:center; gap:6px;
      height: 28px; padding: 0 12px;
      background: ${W.panel};
      border:1px solid ${W.ink3};
      border-radius: 4px;
      font-family: ${W.ui}; font-size: 12px; font-weight: 500;
      color: ${W.ink}; cursor: default; user-select: none;
    }
    .wf-btn.sm { height: 22px; padding: 0 8px; font-size: 11px; border-radius: 3px; }
    .wf-btn.lg { height: 36px; padding: 0 16px; font-size: 14px; }
    .wf-btn.primary { background: ${W.ink}; color: ${W.paper}; border-color: ${W.ink}; }
    .wf-btn.accent  { background: ${W.accent}; color: #fff; border-color: ${W.accent}; }
    .wf-btn.ghost   { background: transparent; border-color: ${W.ink4}; color: ${W.ink2}; }
    .wf-btn.danger  { background: ${W.panel}; color: ${W.mismatch}; border-color: ${W.mismatch}; }
    .wf-btn.icon    { width: 28px; padding: 0; }

    /* Chips */
    .wf-chip {
      display:inline-flex; align-items:center; gap:4px;
      height: 18px; padding: 0 7px;
      border-radius: 9px;
      background: ${W.panelSunk};
      border:1px solid ${W.ink4};
      font-family: ${W.ui}; font-size: 10px; font-weight: 500;
      color: ${W.ink2};
    }
    .wf-chip .x { color: ${W.ink3}; font-size: 12px; line-height: 1; padding-left: 2px; }

    /* Status pip */
    .wf-pip {
      display:inline-flex; align-items:center; gap:4px;
      height: 16px; padding: 0 6px;
      border-radius: 8px;
      font-family: ${W.ui}; font-size: 10px; font-weight: 600;
      letter-spacing: 0.02em;
    }
    .wf-pip .dot { width: 6px; height: 6px; border-radius: 50%; }

    /* Inputs */
    .wf-input {
      height: 26px; padding: 0 8px;
      background: #fff;
      border:1px solid ${W.ink3};
      border-radius: 3px;
      font-family: ${W.mono}; font-size: 12px; color: ${W.ink};
      min-width: 0;
    }
    .wf-input.lg { height: 32px; font-size: 14px; }

    /* Tabs */
    .wf-tabs { display:flex; gap: 2px; border-bottom: 1px solid ${W.rule}; }
    .wf-tab { padding: 8px 14px; font-size: 12px; font-weight: 500; color: ${W.ink3};
      border-bottom: 2px solid transparent; margin-bottom: -1px; cursor: default; }
    .wf-tab.active { color: ${W.ink}; border-bottom-color: ${W.ink}; }

    /* Header label / section heading */
    .wf-h-label {
      font-family: ${W.ui};
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: ${W.ink3};
    }
    .wf-key {
      display:inline-flex; align-items:center; justify-content:center;
      min-width: 18px; height: 18px; padding: 0 5px;
      background: #fff; border: 1px solid ${W.ink3};
      border-bottom-width: 2px;
      border-radius: 3px;
      font-family: ${W.mono}; font-size: 10px; font-weight: 600;
      color: ${W.ink};
    }

    /* Sketch annotation - red handwritten callouts */
    .wf-note {
      position: absolute;
      font-family: ${W.hand}; font-weight: 700;
      color: ${W.accent}; font-size: 15px;
      pointer-events: none;
      line-height: 1.1;
    }
    .wf-note.sm { font-size: 13px; }
    .wf-arrow {
      position: absolute; pointer-events: none;
    }

    /* Scrollbar-ish hint on the side */
    .wf-scrollbar {
      position: absolute; top: 6px; right: 4px; bottom: 6px;
      width: 6px; border-radius: 3px;
      background: ${W.panelSunk};
    }
    .wf-scrollbar::after {
      content: ""; display:block; width: 100%; height: 30%;
      background: ${W.ink4}; border-radius: 3px; margin-top: 12%;
    }

    /* Drag handles / grippers */
    .wf-grip {
      display:inline-block; width: 8px; height: 14px;
      background-image: radial-gradient(${W.ink4} 1px, transparent 1px);
      background-size: 4px 4px;
      background-position: 0 0;
      opacity: 0.7;
    }
  `;
  document.head.appendChild(s);
}

// ===== Status pip =====
function StatusPip({ kind, label }) {
  const colors = {
    exact:     [W.exact,    'exact', '✓'],
    fuzzy:     [W.fuzzy,    'fuzzy', '~'],
    mismatch:  [W.mismatch, 'mismatch', '✗'],
    ocr:       [W.ocrOnly,  'OCR only', '○'],
    gt:        [W.gtOnly,   'GT only', '○'],
  };
  const [c, lbl, glyph] = colors[kind] || [W.ink3, kind, '·'];
  return (
    <span className="wf-pip" style={{
      background: c + '1a',
      color: c,
      border: `1px solid ${c}66`,
    }}>
      <span className="dot" style={{background:c}}></span>
      {label ?? lbl}
    </span>
  );
}

// ===== Mini word card used in LineCard examples =====
function WordCell({ img, ocr, gt, status, chips=[], style, focused, narrow, w=130 }) {
  return (
    <div style={{
      width: w,
      flex: '0 0 auto',
      display:'flex', flexDirection:'column', gap: 4,
      padding: 6, borderRadius: 4,
      border: focused ? `1.5px solid ${W.accent}` : `1px solid ${W.ruleSoft}`,
      background: focused ? '#fff' : W.panel,
      position: 'relative',
      ...style,
    }}>
      {/* top row: checkbox + edit + validate */}
      <div style={{display:'flex', alignItems:'center', gap:4, justifyContent:'space-between'}}>
        <div style={{display:'flex', alignItems:'center', gap:4}}>
          <span style={{width:10, height:10, border:`1px solid ${W.ink3}`, borderRadius:2, background:'#fff'}}></span>
          <span style={{
            width:14, height:14, borderRadius:'50%',
            background: '#fff', border:`1px solid ${W.ink3}`,
            fontSize: 9, display:'inline-flex', alignItems:'center', justifyContent:'center',
          }}>✎</span>
        </div>
        <StatusPip kind={status} label={{exact:'✓', fuzzy:'~', mismatch:'✗', ocr:'OCR', gt:'GT'}[status]} />
      </div>

      {/* image slot */}
      <div style={{
        height: 38,
        background:`repeating-linear-gradient(90deg, ${W.panelSunk} 0 4px, ${W.paper} 4px 8px)`,
        border: `1px dashed ${W.ink4}`,
        borderRadius: 3,
        display:'flex', alignItems:'center', justifyContent:'center',
        fontFamily: W.hand, color: W.ink3, fontSize: 16,
      }}>{img}</div>

      {/* ocr (read-only) */}
      <div className="wf-mono" style={{
        fontSize: 11, color: W.ink2,
        padding: '2px 5px', background: W.panelSunk, borderRadius: 2,
        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
      }}>{ocr}</div>

      {/* gt (editable) */}
      <div style={{
        fontFamily: W.mono, fontSize: 11, color: W.ink,
        padding: '3px 5px', background: '#fff',
        border:`1px solid ${focused ? W.accent : W.ink3}`,
        borderRadius: 2,
        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
      }}>{gt}</div>

      {/* chips */}
      {chips.length > 0 && (
        <div style={{display:'flex', flexWrap:'wrap', gap:3}}>
          {chips.map((c, i) => (
            <span key={i} className="wf-chip" style={{fontSize:9, height:15, padding:'0 5px'}}>
              {c}<span className="x">×</span>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== Sample data =====
const SAMPLE_WORDS_L4 = [
  { img:'WOODROW',   ocr:'WOODROW',   gt:'WOODROW',   status:'exact', chips:['All Caps'] },
  { img:'WILSON,',   ocr:'WILSON,',   gt:'WILSON,',   status:'exact', chips:['All Caps'] },
  { img:'PH.D.,',    ocr:'PH.D.,',    gt:'Ph.D.,',    status:'fuzzy', chips:['Sm. Caps'] },
  { img:'LITT.D.,',  ocr:'LITT.D.,',  gt:'Litt.D.,',  status:'fuzzy', chips:['Sm. Caps'] },
  { img:'LL.D.',     ocr:'LL.D.',     gt:'LL.D.',     status:'exact', chips:['All Caps'] },
];

const SAMPLE_WORDS_L7 = [
  { img:'The',        ocr:'tbe',        gt:'The',        status:'mismatch', chips:['Blackletter'] },
  { img:'Founding',   ocr:'Jounding',   gt:'Founding',   status:'mismatch', chips:['Blackletter'] },
  { img:'of',         ocr:'of',         gt:'of',         status:'exact',    chips:['Blackletter'] },
  { img:'the',        ocr:'tbe',        gt:'the',        status:'mismatch', chips:['Blackletter'] },
  { img:'Government', ocr:'Gopernment', gt:'Government', status:'mismatch', chips:['Blackletter'] },
];

const SAMPLE_WORDS_L6 = [
  { img:'VOL.', ocr:'VOL.', gt:'Vol.', status:'fuzzy', chips:['Sm. Caps'] },
  { img:'III.', ocr:'III.', gt:'III.', status:'exact', chips:['All Caps'] },
];

// ===== Layer & mode legend =====
function LayerLegend() {
  const items = [
    { color: W.paraColor, label: 'Paragraphs' },
    { color: W.lineColor, label: 'Lines' },
    { color: W.wordColor, label: 'Words' },
  ];
  return (
    <div style={{display:'flex', gap:8, alignItems:'center'}}>
      {items.map((it,i) => (
        <span key={i} className="wf-chip" style={{
          background: it.color + '22', borderColor: it.color + '88', color: it.color,
        }}>
          <span style={{width:8, height:8, background: it.color, borderRadius:2}}></span>
          {it.label}
        </span>
      ))}
    </div>
  );
}

// ===== Page scan placeholder =====
function PageScan({ scale = 1, showLayers = true }) {
  const lineColor = showLayers ? W.lineColor : 'transparent';
  const wordColor = showLayers ? W.wordColor : 'transparent';
  const paraColor = showLayers ? W.paraColor : 'transparent';
  return (
    <div style={{
      width:'100%', height:'100%',
      background: '#fcfaf4',
      backgroundImage: `linear-gradient(${W.ruleSoft} 1px, transparent 1px)`,
      backgroundSize: `100% ${22*scale}px`,
      border: `1px solid ${W.rule}`,
      borderRadius: 4,
      position:'relative',
      overflow: 'hidden',
    }}>
      {/* central rule / paragraph regions stack */}
      <div style={{
        position:'absolute', left: '12%', right:'12%', top:'10%', bottom:'10%',
        display:'flex', flexDirection:'column', gap: 18*scale,
      }}>
        {/* line block #1: title */}
        <Line para={paraColor} line={lineColor} word={wordColor} scale={scale}
              words={[{w:'A',sz:1.4},{w:'HISTORY',sz:1.4},{w:'OF',sz:1.4}]} />
        <Line para={paraColor} line={lineColor} word={wordColor} scale={scale}
              words={[{w:'THE',sz:1.4},{w:'AMERICAN',sz:1.4},{w:'PEOPLE',sz:1.4}]} />
        <div style={{height: 18*scale}}></div>
        <Line para={paraColor} line={lineColor} word={wordColor} scale={scale}
              words={[{w:'BY'}]} center />
        <Line para={paraColor} line={lineColor} word={wordColor} scale={scale}
              words={[{w:'WOODROW'},{w:'WILSON,'},{w:'Ph.D.,'},{w:'Litt.D.,'},{w:'LL.D.'}]} center />
        <div style={{height: 18*scale}}></div>
        <Line para={paraColor} line={lineColor} word={wordColor} scale={scale}
              words={[{w:'IN'},{w:'FIVE'},{w:'VOLUMES'}]} center />
        <Line para={paraColor} line={lineColor} word={wordColor} scale={scale}
              words={[{w:'VOL.'},{w:'III.'}]} center />
        <div style={{height: 26*scale}}></div>
        <Line para={paraColor} line={lineColor} word={wordColor} scale={scale} highlight
              words={[{w:'The',sz:1.2},{w:'Founding',sz:1.2},{w:'of',sz:1.2},{w:'the',sz:1.2},{w:'Government',sz:1.2}]} center />
      </div>
    </div>
  );
}

function Line({ words, scale=1, line, word, para, center, highlight }) {
  return (
    <div style={{
      display:'flex', justifyContent: center ? 'center' : 'flex-start', gap: 6*scale,
      position:'relative',
      padding: '4px 6px',
      outline: highlight ? `1.5px solid ${W.accent}` : `1px solid ${line}80`,
      background: line + '14',
      borderRadius: 2,
    }}>
      {words.map((wd, i) => (
        <span key={i} style={{
          fontFamily: '"Times New Roman", serif',
          fontSize: 16 * (wd.sz||1) * scale,
          fontWeight: 500,
          color: W.ink,
          padding: '0 4px',
          outline: `1px solid ${word}80`,
          background: word + '18',
          borderRadius: 2,
        }}>{wd.w}</span>
      ))}
    </div>
  );
}

// ===== Toolbar action matrix =====
// scope (rows) × action (cols) dense grid.
function ActionMatrix({ compact = false, density='md' }) {
  const rows = ['Page', 'Para', 'Line', 'Word'];
  const cols = ['Merge', 'Refine', 'Exp+Ref', 'Expand', 'Split→', '→Split', 'W→L', '→Para', 'OCR→GT', '✓ Valid', '✗ Inval', '🗑'];
  // which cells are populated (sparse — many cells empty in real spec)
  const legal = {
    'Page':    new Set(['Refine','Exp+Ref','OCR→GT','✓ Valid','✗ Inval']),
    'Para':    new Set(['Merge','Refine','Exp+Ref','Expand','OCR→GT','✓ Valid','✗ Inval','🗑']),
    'Line':    new Set(['Merge','Refine','Exp+Ref','Expand','Split→','OCR→GT','✓ Valid','✗ Inval','🗑']),
    'Word':    new Set(['Merge','Refine','Exp+Ref','Expand','Split→','→Split','W→L','→Para','OCR→GT','✓ Valid','✗ Inval','🗑']),
  };
  const cellH = density === 'sm' ? 20 : 22;
  return (
    <div style={{display:'grid',
      gridTemplateColumns: `auto repeat(${cols.length}, 1fr)`,
      gap: 2,
      fontSize: density === 'sm' ? 9 : 10,
    }}>
      <div></div>
      {cols.map(c => (
        <div key={c} className="wf-h-label" style={{
          fontSize: density==='sm' ? 8 : 9,
          textAlign:'center', padding: '2px 0',
          color: W.ink3,
          writingMode: compact ? 'horizontal-tb' : undefined,
        }}>{c}</div>
      ))}
      {rows.map(r => (
        <React.Fragment key={r}>
          <div className="wf-h-label" style={{
            paddingRight: 6, textAlign:'right',
            color: W.ink2, alignSelf:'center', fontSize: density==='sm' ? 9 : 10,
          }}>{r}</div>
          {cols.map(c => {
            const ok = legal[r].has(c);
            const isDelete = c === '🗑';
            return (
              <div key={c} style={{
                height: cellH,
                display:'flex', alignItems:'center', justifyContent:'center',
                background: ok ? (isDelete ? W.mismatch + '12' : W.panel) : 'transparent',
                border: ok ? `1px solid ${isDelete ? W.mismatch + '55' : W.ink4}` : `1px dashed ${W.ruleSoft}`,
                borderRadius: 3,
                color: ok ? (isDelete ? W.mismatch : W.ink) : 'transparent',
                fontFamily: W.ui, fontSize: density==='sm' ? 9 : 10, fontWeight: 500,
              }}>{ok ? '·' : ''}</div>
            );
          })}
        </React.Fragment>
      ))}
    </div>
  );
}

// ===== Mode segmented switcher =====
function ModeSwitcher({ active='Select', vertical=false, big=false }) {
  const modes = [
    {k:'Select', key:'S'},
    {k:'Rebox',  key:'R'},
    {k:'Add',    key:'A'},
    {k:'Erase',  key:'E'},
  ];
  return (
    <div style={{
      display:'flex',
      flexDirection: vertical ? 'column' : 'row',
      background: W.panelSunk,
      border:`1px solid ${W.rule}`,
      borderRadius: 5,
      padding: 2,
      gap: 2,
    }}>
      {modes.map(m => (
        <div key={m.k} style={{
          padding: big ? '8px 14px' : '5px 10px',
          background: m.k===active ? '#fff' : 'transparent',
          border: m.k===active ? `1px solid ${W.ink3}` : '1px solid transparent',
          boxShadow: m.k===active ? `0 1px 2px rgba(0,0,0,0.05)` : 'none',
          borderRadius: 4,
          fontSize: big ? 13 : 11, fontWeight: 600,
          color: m.k===active ? W.ink : W.ink3,
          display:'flex', alignItems:'center', gap:6,
        }}>
          <span>{m.k}</span>
          <span className="wf-key" style={{height: big?16:14, minWidth:14, fontSize:9}}>{m.key}</span>
        </div>
      ))}
    </div>
  );
}

// Sample line card data exposed globally
Object.assign(window, {
  W, StatusPip, WordCell, LayerLegend, PageScan, ActionMatrix, ModeSwitcher,
  SAMPLE_WORDS_L4, SAMPLE_WORDS_L6, SAMPLE_WORDS_L7,
});
