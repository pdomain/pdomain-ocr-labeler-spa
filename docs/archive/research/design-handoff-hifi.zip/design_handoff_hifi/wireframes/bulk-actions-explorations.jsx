// Bulk Actions — Apply Style & Component deep-dive
// Constraints from the user:
//   - Char range only in detail word editor (not bulk)
//   - Styles mostly additive, some conflict (blackletter vs italic)
//   - Components fully additive
//   - Scopes: char range (detail only), whole word, selected words
//   - Labels: fixed enum + custom additions
//   - Explore: scope picker, applied-state display, char range picker,
//     hotkey-per-style, accordion vs right panel integration

// Canonical sample sets ────────────────────────────────────────
const STYLES = [
  {k:'italic',     l:'italic',      hot:'I', conflicts:['blackletter']},
  {k:'smcaps',     l:'small caps',  hot:'S'},
  {k:'allcaps',    l:'ALL CAPS',    hot:'C'},
  {k:'blackletter',l:'blackletter', hot:'B', conflicts:['italic']},
  {k:'bold',       l:'bold',        hot:'D'},
  {k:'super',      l:'super',       hot:'⇧6'},
  {k:'sub',        l:'sub',         hot:'⇧-'},
  {k:'strike',     l:'strike',      hot:'⇧X'},
];
const COMPONENTS = [
  {k:'dropcap',    l:'drop cap',         hot:''},
  {k:'footnote',   l:'footnote marker',  hot:''},
  {k:'catchword',  l:'catchword',        hot:''},
  {k:'chapstart',  l:'chapter start',    hot:''},
  {k:'chapend',    l:'chapter end',      hot:''},
  {k:'runhead',    l:'running header',   hot:''},
  {k:'marginalia', l:'marginalia',       hot:''},
  {k:'signature',  l:'signature mark',   hot:''},
];

// Chip state: 'all' | 'some' | 'none' (tri-state for a selection of N words)
function StateChip({ label, hot, state='none', conflict, kind='style' }) {
  const isStyle = kind === 'style';
  const base = isStyle ? W.ocrOnly : W.gtOnly;
  const cMap = {
    none: { bg: W.panel,         fg: W.ink2,   bd: W.ink4,        check: '' },
    some: { bg: W.panel,         fg: base,     bd: base,          check: '½' },
    all:  { bg: base + '1a',     fg: base,     bd: base,          check: '✓' },
  };
  const c = cMap[state];
  return (
    <div style={{
      display:'inline-flex', alignItems:'center', gap:5,
      height: 26, padding:'0 8px 0 7px',
      background: c.bg,
      border: `1.5px solid ${c.bd}`,
      borderRadius: 14,
      fontSize: 11, fontWeight: 600,
      color: c.fg,
      opacity: conflict ? 0.4 : 1,
      textDecoration: conflict ? 'line-through' : 'none',
      position:'relative',
    }}>
      <span style={{
        width: 14, height: 14, borderRadius: 7,
        background: state === 'all' ? base : 'transparent',
        border: `1.5px solid ${state === 'none' ? W.ink4 : base}`,
        backgroundImage: state === 'some'
          ? `repeating-linear-gradient(45deg, ${base} 0 2px, transparent 2px 4px)`
          : 'none',
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontSize: 8, color: '#fff', fontWeight: 700,
      }}>
        {state === 'all' ? '✓' : ''}
      </span>
      <span style={{
        fontFamily: c.bd === base && isStyle && (label === 'italic') ? 'serif' : W.ui,
        fontStyle: label === 'italic' ? 'italic' : 'normal',
        fontVariant: label === 'small caps' ? 'small-caps' : 'normal',
      }}>{label}</span>
      {hot && (
        <span className="wf-key" style={{
          height: 14, minWidth: 14, fontSize: 9, marginLeft: 2,
          opacity: 0.75,
        }}>{hot}</span>
      )}
    </div>
  );
}

// Selection summary card ────────────────────────────────────────
function SelectionSummary({ count, items, line, para, dim }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 12, padding: '8px 12px',
      background: W.paperAlt, border: `1px solid ${W.rule}`,
      borderRadius: 5,
    }}>
      <span style={{
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        width: 24, height: 24, borderRadius: 5,
        background: W.wordColor + '22', color: W.wordColor,
        border: `1px solid ${W.wordColor}55`,
        fontSize: 13, fontWeight: 700,
      }}>{count}</span>
      <div style={{display:'flex', flexDirection:'column', gap: 1, minWidth: 0}}>
        <span style={{fontSize: 11, color: W.ink3, fontWeight: 600, letterSpacing: '0.05em'}}>SELECTION · words</span>
        <span style={{fontFamily: W.mono, fontSize: 12, color: W.ink, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', maxWidth: 380}}>
          {items.join(' · ')}
        </span>
      </div>
      <div style={{flex:1}}></div>
      <span style={{fontSize: 11, color: W.ink3}}>Line {line} · Para {para}</span>
      <span className="wf-btn sm ghost">Clear</span>
    </div>
  );
}

// ============================================================
// V1 — Bulk in accordion: chip palette with tri-state
// ============================================================
function BulkPaletteAccordion() {
  return (
    <div className="wf" style={{padding: 18, overflow:'hidden', background: W.paperAlt}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>V1 · Bulk palette in accordion</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Replaces the dropdown+Apply pattern with a chip palette.
          Tri-state per chip (none / some / all of selection).
          Click toggles; double-click "all" to remove. Hotkey on each.
        </div>
      </header>

      <SelectionSummary
        count={3}
        items={['Ph.D.,', 'Litt.D.,', 'LL.D.']}
        line={4} para={4}
      />

      {/* The accordion frame */}
      <div style={{
        marginTop: 14, background: W.panel,
        border: `1px solid ${W.rule}`, borderRadius: 6, overflow: 'hidden',
      }}>
        <div style={{
          display:'flex', alignItems:'center', gap: 8, padding: '8px 12px',
          background: W.paperAlt, borderBottom: `1px solid ${W.rule}`,
        }}>
          <span style={{
            width: 14, height: 14, display:'inline-flex',
            alignItems:'center', justifyContent:'center', color: W.ink2, fontSize: 11,
            transform: 'rotate(90deg)',
          }}>▶</span>
          <span style={{fontSize: 12, fontWeight: 600}}>Bulk actions</span>
          <span style={{fontSize: 10, color: W.ink3}}>applies to 3 selected words</span>
          <div style={{flex:1}}></div>
          <span className="wf-key" style={{height: 16, fontSize: 9}}>G</span>
        </div>

        <div style={{padding: 16, display:'flex', flexDirection:'column', gap: 16}}>
          {/* STYLE SECTION */}
          <div>
            <div style={{
              display:'flex', alignItems:'baseline', gap: 8,
              marginBottom: 8, paddingBottom: 6,
              borderBottom: `1px solid ${W.ruleSoft}`,
            }}>
              <span style={{fontSize: 12, fontWeight: 700}}>Style</span>
              <span style={{fontSize: 10, color: W.ink3}}>typographic treatment · whole word in bulk</span>
              <div style={{flex:1}}></div>
              <span style={{fontSize: 10, color: W.ink3}}>
                <span className="wf-key" style={{height: 14, fontSize: 9}}>?</span> hotkeys when selection is active
              </span>
            </div>
            <div style={{display:'flex', gap: 6, flexWrap: 'wrap', alignItems:'center'}}>
              <StateChip label="italic" hot="I" state="none" conflict/>
              <StateChip label="small caps" hot="S" state="all"/>
              <StateChip label="ALL CAPS" hot="C" state="none"/>
              <StateChip label="blackletter" hot="B" state="some"/>
              <StateChip label="bold" hot="D" state="none"/>
              <StateChip label="super" hot="⇧6" state="none"/>
              <StateChip label="sub" hot="⇧-" state="none"/>
              <StateChip label="strike" hot="⇧X" state="none"/>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3, height:26, padding:'0 9px', fontSize:11}}>+ custom…</span>
            </div>
            <div style={{display:'flex', gap: 14, marginTop: 10, fontSize: 10, color: W.ink3, alignItems:'center'}}>
              <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
                <span style={{
                  width: 12, height: 12, borderRadius: 6, background: W.ocrOnly,
                  display:'inline-flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:7, fontWeight:700,
                }}>✓</span> all selected
              </span>
              <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
                <span style={{
                  width: 12, height: 12, borderRadius: 6,
                  border: `1.5px solid ${W.ocrOnly}`,
                  backgroundImage: `repeating-linear-gradient(45deg, ${W.ocrOnly} 0 2px, transparent 2px 4px)`,
                }}></span> some have it
              </span>
              <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
                <span style={{
                  width: 12, height: 12, borderRadius: 6, border:`1.5px solid ${W.ink4}`, background: 'transparent',
                }}></span> none have it
              </span>
              <span style={{display:'inline-flex', alignItems:'center', gap:5, textDecoration:'line-through', opacity:0.55}}>
                conflicts with small caps
              </span>
            </div>
          </div>

          {/* COMPONENT SECTION */}
          <div>
            <div style={{
              display:'flex', alignItems:'baseline', gap: 8,
              marginBottom: 8, paddingBottom: 6,
              borderBottom: `1px solid ${W.ruleSoft}`,
            }}>
              <span style={{fontSize: 12, fontWeight: 700}}>Component</span>
              <span style={{fontSize: 10, color: W.ink3}}>structural role · fully additive</span>
              <div style={{flex:1}}></div>
            </div>
            <div style={{display:'flex', gap: 6, flexWrap: 'wrap'}}>
              <StateChip label="drop cap" kind="component" state="none"/>
              <StateChip label="footnote marker" kind="component" state="none"/>
              <StateChip label="catchword" kind="component" state="none"/>
              <StateChip label="chapter start" kind="component" state="none"/>
              <StateChip label="chapter end" kind="component" state="none"/>
              <StateChip label="running header" kind="component" state="none"/>
              <StateChip label="marginalia" kind="component" state="none"/>
              <StateChip label="signature mark" kind="component" state="none"/>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3, height:26, padding:'0 9px', fontSize:11}}>+ custom…</span>
            </div>
          </div>

          {/* Scope hint + matrix link */}
          <div style={{
            display:'flex', alignItems:'center', gap: 10,
            padding: '8px 10px', background: W.paperAlt, borderRadius: 4,
            border: `1px dashed ${W.ink4}`, fontSize: 11, color: W.ink2,
          }}>
            <span className="wf-h-label">Scope</span>
            <span>Selected words (3)</span>
            <span style={{color: W.ink4}}>·</span>
            <span style={{color: W.ink3}}>character-range styles → open word in detail editor</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm">Open scope×action matrix ▾</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// V2 — Right panel word inspector: applied chips inline
// ============================================================
function InspectorChips() {
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'hidden'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>V2 · Word inspector chips</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Single-word focus. Chips show what's applied with their scope
          baked in (whole word vs char range). + buttons open a popover with
          the full enum.
        </div>
      </header>

      {/* Word inspector excerpt */}
      <div style={{
        background: W.panel, border: `1px solid ${W.rule}`, borderRadius: 6,
        padding: 18, display: 'flex', flexDirection:'column', gap: 14,
      }}>
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Line 4 · Word 3</span>
          <StatusPip kind="fuzzy" label="83%"/>
          <div style={{flex:1}}></div>
          <span style={{fontSize: 11, color: W.ink3}}>“Ph.D.,”</span>
        </div>

        {/* word zoom */}
        <div style={{
          background:'#fff', border:`1.5px solid ${W.accent}`, borderRadius: 6,
          minHeight: 100, padding: '10px 16px',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontFamily:'serif', fontVariant:'small-caps', fontSize: 60,
        }}>
          Ph.D.,
        </div>

        {/* APPLIED state */}
        <div style={{display:'flex', flexDirection:'column', gap: 8}}>
          <div style={{display:'flex', alignItems:'baseline', gap: 8}}>
            <span className="wf-h-label">Style applied</span>
            <span style={{fontSize: 10, color: W.ink3}}>click chip to edit · × to remove</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm">＋ Add style ▾</span>
          </div>
          <div style={{display:'flex', gap: 6, flexWrap:'wrap'}}>
            {/* applied chip — full word */}
            <span style={{
              display:'inline-flex', alignItems:'center', gap: 6,
              height: 28, padding: '0 4px 0 10px',
              background: W.ocrOnly + '15',
              border: `1.5px solid ${W.ocrOnly}55`,
              borderRadius: 14,
              fontSize: 12, fontWeight: 600, color: W.ocrOnly,
              fontVariant: 'small-caps',
            }}>
              small caps
              <span style={{
                fontFamily: W.mono, fontSize: 10, color: W.ocrOnly,
                background: '#fff', borderRadius: 4, padding: '1px 5px',
                fontVariant: 'normal',
                border: `1px solid ${W.ocrOnly}55`,
              }}>whole</span>
              <span style={{
                width: 18, height: 18, marginLeft: 2, borderRadius: 9,
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                color: W.ocrOnly, fontSize: 12, fontWeight: 400,
              }}>×</span>
            </span>
            {/* applied chip — char range */}
            <span style={{
              display:'inline-flex', alignItems:'center', gap: 6,
              height: 28, padding: '0 4px 0 10px',
              background: W.ocrOnly + '15',
              border: `1.5px solid ${W.ocrOnly}55`,
              borderRadius: 14,
              fontSize: 12, fontWeight: 600, color: W.ocrOnly,
              fontStyle: 'italic',
            }}>
              italic
              <span style={{
                fontFamily: W.mono, fontSize: 10, color: W.ocrOnly,
                background: '#fff', borderRadius: 4, padding: '1px 5px',
                fontStyle: 'normal',
                border: `1px solid ${W.ocrOnly}55`,
              }}>chars 1–3</span>
              <span style={{
                width: 18, height: 18, marginLeft: 2, borderRadius: 9,
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                color: W.ocrOnly, fontSize: 12, fontWeight: 400,
              }}>×</span>
            </span>
          </div>
        </div>

        {/* APPLIED components */}
        <div style={{display:'flex', flexDirection:'column', gap: 8}}>
          <div style={{display:'flex', alignItems:'baseline', gap: 8}}>
            <span className="wf-h-label">Components</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm">＋ Add component ▾</span>
          </div>
          <div style={{display:'flex', gap: 6, flexWrap:'wrap'}}>
            <span style={{
              display:'inline-flex', alignItems:'center', gap: 6,
              height: 28, padding: '0 4px 0 10px',
              background: W.gtOnly + '15',
              border: `1.5px solid ${W.gtOnly}55`,
              borderRadius: 14,
              fontSize: 12, fontWeight: 600, color: W.gtOnly,
            }}>
              drop cap
              <span style={{
                width: 18, height: 18, marginLeft: 2, borderRadius: 9,
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                color: W.gtOnly, fontSize: 12, fontWeight: 400,
              }}>×</span>
            </span>
            <span style={{color: W.ink3, fontSize: 11, padding: '4px 0'}}>(none)</span>
          </div>
        </div>

        {/* Popover preview */}
        <div style={{
          position:'relative', alignSelf:'flex-end',
          marginRight: 8, marginTop: -4,
        }}>
          <div style={{
            background: '#fff', border: `1px solid ${W.ink3}`, borderRadius: 8,
            padding: 8, width: 280,
            boxShadow: '0 8px 28px rgba(0,0,0,0.12)',
          }}>
            <div style={{
              padding: '4px 8px 8px', fontSize: 11, color: W.ink3, fontWeight: 600,
              letterSpacing: '0.05em',
              borderBottom: `1px solid ${W.rule}`,
            }}>ADD STYLE</div>
            <div style={{padding: 6, display:'flex', flexDirection:'column', gap: 2}}>
              {STYLES.map((s, i) => (
                <div key={s.k} style={{
                  display:'flex', alignItems:'center', gap: 8,
                  padding: '6px 8px', borderRadius: 4,
                  background: i === 0 ? W.paperAlt : 'transparent',
                  fontSize: 12,
                }}>
                  <span style={{
                    fontStyle: s.k==='italic' ? 'italic' : 'normal',
                    fontVariant: s.k==='smcaps' ? 'small-caps' : 'normal',
                    fontWeight: s.k==='bold' ? 700 : 500,
                    flex: 1,
                  }}>{s.l}</span>
                  {s.k === 'smcaps' && <span style={{fontSize: 9, color: W.ink3}}>already applied</span>}
                  {s.hot && <span className="wf-key" style={{height: 14, fontSize: 9}}>{s.hot}</span>}
                </div>
              ))}
              <div style={{borderTop:`1px solid ${W.rule}`, marginTop: 4, paddingTop: 4}}>
                <div style={{padding:'6px 8px', fontSize: 12, color: W.ink3}}>＋ Custom label…</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// V3 — Char range picker (in detail word editor) — two variants
// ============================================================
function CharRangePickers() {
  // helper renderer used by both variants
  const word = 'Mr.Wilson';
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>V3 · Char-range pickers (detail editor)</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          For partial-word styles. Two interaction models — pick the one
          that feels best, then I'll commit. Both live INSIDE the detail
          word editor only (per your rule).
        </div>
      </header>

      <div style={{display:'flex', flexDirection:'column', gap: 18}}>
        {/* Variant A — character cells */}
        <div style={{background: W.panel, border:`1px solid ${W.rule}`, borderRadius: 6, padding: 18}}>
          <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom: 10}}>
            <span style={{fontWeight: 700}}>A · Character cells</span>
            <span style={{fontSize: 11, color: W.ink3}}>click or drag across characters to set the range</span>
          </div>

          {/* Visual word with character cells */}
          <div style={{
            display:'flex', justifyContent:'center', gap: 0,
            padding: '14px 0', background: W.paperAlt, borderRadius: 4,
            border: `1px solid ${W.ruleSoft}`,
          }}>
            {word.split('').map((ch, i) => {
              const inRange = i <= 2;
              return (
                <div key={i} style={{
                  display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
                  padding: '0 6px',
                  position: 'relative',
                }}>
                  <span style={{
                    fontFamily:'serif', fontSize: 38,
                    color: inRange ? W.ink : W.ink3,
                    fontVariant: inRange ? 'small-caps' : 'normal',
                  }}>{ch}</span>
                  <span style={{fontSize: 9, color: W.ink3, fontFamily: W.mono}}>{i+1}</span>
                  <span style={{
                    width: 22, height: 22, borderRadius: 4,
                    background: inRange ? W.ocrOnly : '#fff',
                    border: `1.5px solid ${inRange ? W.ocrOnly : W.ink4}`,
                    display:'inline-flex', alignItems:'center', justifyContent:'center',
                    color: '#fff', fontSize: 12,
                  }}>{inRange ? '✓' : ''}</span>
                </div>
              );
            })}
          </div>

          {/* Range readout + apply */}
          <div style={{display:'flex', gap: 12, alignItems:'center', marginTop: 14, flexWrap:'wrap'}}>
            <span className="wf-h-label">Range</span>
            <span style={{fontFamily: W.mono, fontSize: 13,
              padding: '4px 10px', background: W.panelSunk, borderRadius: 4,
            }}>chars 1–3 · “Mr.”</span>
            <div style={{display:'flex', gap: 4}}>
              <span className="wf-btn sm">Whole word</span>
              <span className="wf-btn sm ghost">Clear</span>
            </div>
            <div style={{flex:1}}></div>
            <span className="wf-h-label">Apply</span>
            <span className="wf-btn sm" style={{background: W.ocrOnly + '15', borderColor: W.ocrOnly, color: W.ocrOnly, fontVariant:'small-caps'}}>small caps</span>
            <span className="wf-btn sm" style={{fontStyle:'italic'}}>italic</span>
            <span className="wf-btn sm">bold</span>
            <span className="wf-btn sm">＋ more…</span>
          </div>

          {/* Existing ranges on the word */}
          <div style={{display:'flex', alignItems:'center', gap: 10, marginTop: 14, fontSize: 11, color: W.ink2,
            padding: '8px 10px', background: W.paperAlt, borderRadius: 4,
          }}>
            <span className="wf-h-label">Existing on word</span>
            <span style={{
              display:'inline-flex', alignItems:'center', gap: 6,
              padding: '2px 8px', background:'#fff', borderRadius:10,
              border: `1px solid ${W.ocrOnly}55`, color: W.ocrOnly, fontWeight:600,
            }}>
              <span style={{fontVariant:'small-caps'}}>small caps</span>
              <span style={{fontFamily: W.mono, fontSize: 10, opacity:0.8}}>chars 1–3</span>
            </span>
            <span style={{color: W.ink3}}>· would replace existing range</span>
          </div>
        </div>

        {/* Variant B — drag handles on visual word */}
        <div style={{background: W.panel, border:`1px solid ${W.rule}`, borderRadius: 6, padding: 18}}>
          <div style={{display:'flex', alignItems:'baseline', gap: 8, marginBottom: 10}}>
            <span style={{fontWeight: 700}}>B · Drag handles</span>
            <span style={{fontSize: 11, color: W.ink3}}>two handles on the visual word — feels like a slider</span>
          </div>

          <div style={{
            position:'relative', padding: '24px 30px 32px',
            background: W.paperAlt, borderRadius: 4,
            border: `1px solid ${W.ruleSoft}`,
          }}>
            <div style={{
              display:'flex', justifyContent:'center', alignItems:'baseline', fontFamily:'serif', fontSize: 48, letterSpacing: 1,
            }}>
              <span style={{fontVariant:'small-caps', color: W.ink}}>Mr.</span>
              <span>Wilson</span>
            </div>
            {/* range bar under the word */}
            <div style={{
              position: 'absolute', left: '20%', width: '20%',
              bottom: 12, height: 4, background: W.ocrOnly, borderRadius: 2,
            }}></div>
            {/* handles */}
            <div style={{position:'absolute', left:'20%', bottom: 4, transform:'translateX(-50%)',
              width: 18, height: 18, background:'#fff', border:`2px solid ${W.ocrOnly}`,
              borderRadius: 9, cursor:'ew-resize',
            }}></div>
            <div style={{position:'absolute', left:'40%', bottom: 4, transform:'translateX(-50%)',
              width: 18, height: 18, background:'#fff', border:`2px solid ${W.ocrOnly}`,
              borderRadius: 9, cursor:'ew-resize',
            }}></div>
          </div>

          <div style={{display:'flex', gap: 12, alignItems:'center', marginTop: 14, flexWrap:'wrap'}}>
            <span className="wf-h-label">Range</span>
            <div style={{display:'flex', alignItems:'center', gap: 4}}>
              <span style={{fontSize:11, color:W.ink3}}>from</span>
              <input className="wf-input" defaultValue="1" style={{width: 40, textAlign:'center'}}/>
              <span style={{fontSize:11, color:W.ink3}}>to</span>
              <input className="wf-input" defaultValue="3" style={{width: 40, textAlign:'center'}}/>
            </div>
            <div style={{display:'flex', gap: 4}}>
              <span className="wf-btn sm">Whole word</span>
              <span className="wf-btn sm ghost">Reset</span>
            </div>
            <div style={{flex:1}}></div>
            <span style={{fontSize: 10, color: W.ink3}}>
              <span className="wf-key">←</span>/<span className="wf-key">→</span> shrink ·
              <span className="wf-key">⇧←</span>/<span className="wf-key">⇧→</span> grow
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// V4 — Keyboard-first apply with badges on canvas
// ============================================================
function HotkeyFlow() {
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'hidden'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>V4 · Keyboard-first apply · canvas badges</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Pretend the user is mid-flow. Selection is live. They press a
          hotkey. A floating HUD confirms what changed. Style markers
          show on the canvas overlay so they can see their work.
        </div>
      </header>

      <div style={{display:'flex', gap: 16}}>
        {/* Canvas chunk */}
        <div style={{
          flex: 1, background: '#fff', border: `1px solid ${W.rule}`, borderRadius: 6,
          padding: 18, position: 'relative',
          display:'flex', flexDirection:'column', gap: 14,
        }}>
          <div style={{fontSize: 11, color: W.ink3, fontWeight: 600, letterSpacing:'0.05em'}}>CANVAS — LINE 4 (selected words boxed)</div>
          <div style={{
            padding: 22, background:'#fcfaf4', border:`1px solid ${W.ruleSoft}`, borderRadius: 4,
            display:'flex', gap: 14, alignItems:'baseline', justifyContent:'center', flexWrap:'wrap',
          }}>
            {[
              {w:'WOODROW', style:''},
              {w:'WILSON,', style:''},
              {w:'Ph.D.,', style:'sc', selected:true, badges:['SC']},
              {w:'Litt.D.,', style:'sc', selected:true, badges:['SC']},
              {w:'LL.D.', style:'', selected:true},
            ].map((it, i) => (
              <div key={i} style={{position:'relative', padding: '4px 6px',
                outline: it.selected ? `2px solid ${W.accent}` : 'none',
                background: it.selected ? W.accent + '0c' : 'transparent',
                borderRadius: 3,
              }}>
                <span style={{
                  fontFamily:'serif', fontSize: 38,
                  fontVariant: it.style === 'sc' ? 'small-caps' : 'normal',
                  color: W.ink,
                }}>{it.w}</span>
                {it.badges && (
                  <div style={{
                    position:'absolute', top: -8, right: -6, display:'flex', gap: 2,
                  }}>
                    {it.badges.map((b, j) => (
                      <span key={j} style={{
                        background: W.ocrOnly, color:'#fff',
                        fontFamily: W.mono, fontSize: 9, fontWeight: 700,
                        padding: '1px 5px', borderRadius: 7,
                        border: `1px solid #fff`,
                      }}>{b}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
          <div style={{fontSize: 11, color: W.ink3}}>
            Style markers visible above each tagged word. Hover a marker to see the label;
            toggle <code>1</code>/<code>2</code>/<code>3</code> in the layers rail to hide.
          </div>

          {/* Floating HUD */}
          <div style={{
            position:'absolute', bottom: 18, right: 18,
            background: W.ink, color: '#fff', borderRadius: 8,
            padding: '10px 14px', boxShadow: '0 8px 28px rgba(0,0,0,0.25)',
            display:'flex', alignItems:'center', gap: 12, fontSize: 12,
          }}>
            <span style={{
              width: 26, height: 26, borderRadius: 6,
              background: '#fff', color: W.ink,
              display:'inline-flex', alignItems:'center', justifyContent:'center',
              fontFamily: W.mono, fontSize: 13, fontWeight: 700,
            }}>S</span>
            <div style={{display:'flex', flexDirection:'column', gap: 2}}>
              <span style={{fontWeight: 600}}>Applied <span style={{fontVariant:'small-caps'}}>small caps</span></span>
              <span style={{fontSize: 10, opacity: 0.7}}>to 3 words · L4 W3, W4, W5</span>
            </div>
            <span className="wf-btn sm ghost" style={{
              background:'transparent', borderColor:'#fff4', color:'#fff',
              marginLeft: 4,
            }}>Undo <span className="wf-key" style={{background:'#0006', borderColor:'#fff4', color:'#fff'}}>⌘Z</span></span>
          </div>
        </div>

        {/* Right rail — hotkey cheat / sticky */}
        <div style={{
          flex: '0 0 280px',
          background: W.panel, border: `1px solid ${W.rule}`, borderRadius: 6,
          padding: 14, display:'flex', flexDirection:'column', gap: 12,
        }}>
          <div style={{fontSize: 12, fontWeight: 700}}>Quick apply</div>
          <div style={{fontSize: 10, color: W.ink3, marginTop:-6}}>with selection active</div>
          {STYLES.map(s => (
            <div key={s.k} style={{
              display:'flex', alignItems:'center', gap: 10,
              padding: '5px 4px',
              borderBottom: `1px dashed ${W.ruleSoft}`,
            }}>
              <span className="wf-key" style={{minWidth: 28, height: 22}}>{s.hot}</span>
              <span style={{
                fontSize: 12, flex: 1,
                fontStyle: s.k === 'italic' ? 'italic' : 'normal',
                fontVariant: s.k === 'smcaps' ? 'small-caps' : 'normal',
                fontWeight: s.k === 'bold' ? 700 : 500,
              }}>{s.l}</span>
              {s.conflicts && <span style={{fontSize: 9, color: W.ink3}}>conflicts ⚠</span>}
            </div>
          ))}
          <div style={{
            marginTop: 6, padding: '8px 10px',
            background: W.paperAlt, borderRadius: 4,
            fontSize: 11, color: W.ink2,
          }}>
            <div style={{fontWeight: 600, marginBottom: 4}}>Components</div>
            <div style={{fontSize: 10, color: W.ink3}}>
              No default hotkeys (rare actions). Add a key in Settings, or use
              <span className="wf-key" style={{height:14, fontSize:9, marginLeft:4}}>⌘K</span>
              → "component:…"
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  BulkPaletteAccordion, InspectorChips, CharRangePickers, HotkeyFlow,
  StyleStateChip: StateChip, SelectionSummary,
});
