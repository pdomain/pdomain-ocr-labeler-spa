// ProjectPage wireframe variants — 5 distinct layouts.
// Each is 1920×1200. Mid-fi mono, color reserved for status/layers only.

// ──────────────────────────────────────────────────────────────────
// Common building blocks
// ──────────────────────────────────────────────────────────────────

// Header chip with label above and content below — for project, source, etc.
function HField({ label, value, w, dim }) {
  return (
    <div style={{display:'flex', flexDirection:'column', gap:2, minWidth: w}}>
      <span className="wf-h-label">{label}</span>
      <span style={{fontSize: 12, color: dim ? W.ink3 : W.ink, fontFamily: dim ? W.mono : W.ui, fontWeight: 500,
        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', maxWidth: w}}>{value}</span>
    </div>
  );
}

// Statistic chip used in the metrics strip
function MetricChip({ icon, value, label, color }) {
  return (
    <div style={{display:'inline-flex', alignItems:'baseline', gap:6, fontSize: 12,
      padding:'2px 0', color: W.ink2,
    }}>
      {color && <span style={{width:8, height:8, borderRadius:4, background:color, alignSelf:'center'}}></span>}
      <span style={{fontWeight: 700, color: W.ink, fontSize: 13}}>{value}</span>
      <span style={{color: W.ink3}}>{label}</span>
    </div>
  );
}

// LineCard — used in Matches list
function LineCard({ line, words, highlighted, compact, stacked }) {
  return (
    <div style={{
      border: `1px solid ${W.rule}`,
      borderRadius: 5,
      background: highlighted ? W.hi : W.panel,
      overflow:'hidden',
      marginBottom: 8,
    }}>
      {/* line header row */}
      <div style={{
        display:'flex', alignItems:'center', gap: 10,
        padding: '6px 10px',
        background: highlighted ? '#fff7c4' : W.paperAlt,
        borderBottom:`1px solid ${W.rule}`,
      }}>
        <span style={{width:11, height:11, border:`1px solid ${W.ink3}`, borderRadius:2, background:'#fff'}}></span>
        <span style={{fontSize:11, fontWeight:600}}>Line {line.no}</span>
        <span className="wf-h-label">Para {line.para}</span>
        <div style={{display:'flex', gap:6, marginLeft:8, fontSize:10, color:W.ink2}}>
          <span style={{color:W.exact}}>✓ {line.exact}</span>
          <span style={{color:W.fuzzy}}>~ {line.fuzzy}</span>
          <span style={{color:W.mismatch}}>✗ {line.mismatch}</span>
        </div>
        <div style={{marginLeft:'auto', display:'flex', gap:4}}>
          <span className="wf-btn sm">OCR → GT</span>
          <span className="wf-btn sm ghost">Unvalidate</span>
          <span className="wf-btn sm danger" style={{width:24, padding:0}}>🗑</span>
        </div>
      </div>
      {/* word row */}
      <div style={{
        display:'flex',
        gap: 8,
        padding: 10,
        overflow:'hidden',
        flexDirection: stacked ? 'column' : 'row',
      }}>
        {words.map((w, i) => (
          <WordCell key={i} {...w} focused={i===0 && highlighted} w={stacked ? '100%' : (compact ? 110 : 140)} />
        ))}
      </div>
    </div>
  );
}

// Tabbed panel header
function TabBar({ tabs, active }) {
  return (
    <div className="wf-tabs">
      {tabs.map(t => (
        <span key={t} className={'wf-tab' + (t===active ? ' active' : '')}>{t}</span>
      ))}
    </div>
  );
}

// Page nav (prev / next / page input)
function PageNav({ page=1, total=392, compact }) {
  return (
    <div style={{display:'flex', alignItems:'center', gap: 4}}>
      <span className="wf-btn sm icon">◀</span>
      <span className="wf-btn sm icon">▶</span>
      <input className="wf-input" defaultValue={page} style={{width: 50, textAlign:'center', height:24, fontSize:11}}/>
      <span style={{fontSize: 11, color: W.ink3}}>/ {total}</span>
      {!compact && <span className="wf-btn sm">Go to…</span>}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────
// V1 — COMPACT STUDIO
// Faithful evolution of current layout. Header consolidates 14 buttons
// into File/Page/OCR menus. Two-pane split 60/40 image:text.
// Toolbar action matrix lives at top of right panel; matches list below.
// ──────────────────────────────────────────────────────────────────
function ProjectPageV1() {
  return (
    <div className="wf">
      {/* ─── HEADER ─── */}
      <div style={{
        height: 56,
        borderBottom: `1px solid ${W.rule}`,
        background: W.panel,
        display:'flex', alignItems:'center', gap: 20, padding: '0 18px',
      }}>
        <span style={{fontFamily: W.hand, fontSize: 22, color: W.ink}}>ocr·labeler</span>
        <div style={{width:1, height:24, background:W.rule}}></div>
        <HField label="Project" value="willa-cather-letters" w={170}/>
        <HField label="Source" value="~/source-pgdp-data/output/proj…" w={260} dim/>
        <div style={{flex:1}}></div>
        <span className="wf-btn">File ▾</span>
        <span className="wf-btn">Page ▾</span>
        <span className="wf-btn">OCR ▾</span>
        <span className="wf-btn">Export ▾</span>
        <div style={{width:1, height:24, background:W.rule}}></div>
        <PageNav page={47} total={392}/>
        <span className="wf-btn primary">Save Page</span>
      </div>

      {/* ─── METRICS STRIP ─── */}
      <div style={{
        height: 32,
        borderBottom: `1px solid ${W.rule}`,
        background: W.paperAlt,
        display:'flex', alignItems:'center', gap: 18, padding: '0 18px',
      }}>
        <MetricChip value="22" label="words"/>
        <MetricChip value="15" label="exact (68.2%)" color={W.exact}/>
        <MetricChip value="7"  label="fuzzy" color={W.fuzzy}/>
        <MetricChip value="0"  label="mismatch" color={W.mismatch}/>
        <MetricChip value="0"  label="unmatched OCR" color={W.ocrOnly}/>
        <MetricChip value="0"  label="unmatched GT" color={W.gtOnly}/>
        <div style={{flex:1}}></div>
        <MetricChip value="100%" label="match rate"/>
        <MetricChip value="22/22" label="validated"/>
        <span className="wf-h-label">det DBNet · rec CRNN</span>
        <span className="wf-chip" style={{color:W.accent, borderColor:W.accent+'88', background:W.accent+'10'}}>Export stale</span>
      </div>

      {/* ─── BODY: two panes ─── */}
      <div style={{display:'flex', height: 'calc(100% - 88px)'}}>
        {/* Left: canvas */}
        <div style={{flex: '0 0 58%', borderRight:`1px solid ${W.rule}`, display:'flex', flexDirection:'column'}}>
          {/* canvas toolbar */}
          <div style={{
            display:'flex', alignItems:'center', gap: 14, padding: '8px 16px',
            borderBottom: `1px solid ${W.rule}`, background: W.panel,
          }}>
            <span className="wf-h-label">Layers</span>
            <div style={{display:'flex', gap:6}}>
              {['Paragraphs','Lines','Words'].map((l,i) => (
                <span key={l} className="wf-chip" style={{
                  background:[W.paraColor,W.lineColor,W.wordColor][i]+'22',
                  borderColor:[W.paraColor,W.lineColor,W.wordColor][i]+'88',
                  color:[W.paraColor,W.lineColor,W.wordColor][i],
                  fontSize:11, height:22, padding:'0 8px',
                }}>
                  <span style={{width:9, height:9, background:[W.paraColor,W.lineColor,W.wordColor][i], borderRadius:2}}></span>
                  {l}
                </span>
              ))}
            </div>
            <div style={{width:1, height:20, background:W.rule}}></div>
            <span className="wf-h-label">Mode</span>
            <ModeSwitcher active="Select"/>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm danger">Erase Pixels</span>
            <span className="wf-btn sm">Fit</span>
            <span className="wf-btn sm">100%</span>
          </div>
          {/* canvas itself */}
          <div style={{flex:1, padding: 18, position:'relative'}}>
            <PageScan/>
            <div className="wf-note" style={{top: 30, right: 30}}>
              <span>multiply blend so<br/>overlays don&apos;t wash scan</span>
            </div>
          </div>
        </div>

        {/* Right: tabbed editor */}
        <div style={{flex: 1, display:'flex', flexDirection:'column', minWidth: 0}}>
          {/* action matrix */}
          <div style={{padding: '10px 14px', borderBottom:`1px solid ${W.rule}`, background:W.panel}}>
            <div style={{display:'flex', alignItems:'center', gap: 10, marginBottom: 6}}>
              <span className="wf-h-label">Bulk Actions</span>
              <span style={{fontSize:10, color:W.ink3}}>scope × action — gray dot = applicable</span>
              <div style={{flex:1}}></div>
              <span className="wf-key">G</span><span style={{fontSize:10, color:W.ink3}}>focus grid</span>
            </div>
            <ActionMatrix/>
            {/* style + add-word rows */}
            <div style={{display:'flex', gap:8, marginTop:10, alignItems:'center'}}>
              <span className="wf-h-label" style={{minWidth:60}}>Apply Style</span>
              <select className="wf-input" style={{minWidth:120}} defaultValue="">
                <option value="">All Caps</option></select>
              <select className="wf-input" style={{minWidth:120}} defaultValue=""><option>Whole word</option></select>
              <span className="wf-btn sm">Apply Style</span>
              <span style={{width:1, height:20, background:W.rule}}></span>
              <span className="wf-h-label" style={{minWidth:60}}>Component</span>
              <select className="wf-input" style={{minWidth:120}}><option>Drop Cap</option></select>
              <span className="wf-btn sm">Apply</span>
              <div style={{flex:1}}></div>
              <span className="wf-btn sm primary">＋ Add Word</span>
            </div>
          </div>

          {/* tabs */}
          <div style={{padding: '0 14px', background:W.panel, borderBottom:`1px solid ${W.rule}`,
            display:'flex', alignItems:'center', justifyContent:'space-between',
          }}>
            <TabBar tabs={['Matches', 'Ground Truth', 'OCR']} active="Matches"/>
            <div style={{display:'flex', gap:4, alignItems:'center'}}>
              <span className="wf-h-label">Filter</span>
              <span className="wf-chip" style={{background:W.fuzzy+'20', color:W.fuzzy, borderColor:W.fuzzy+'88'}}>Unvalidated 7</span>
              <span className="wf-chip" style={{background:W.mismatch+'20', color:W.mismatch, borderColor:W.mismatch+'88'}}>Mismatched 5</span>
              <span className="wf-chip">All 22</span>
            </div>
          </div>

          {/* matches list */}
          <div style={{flex:1, overflow:'hidden', padding: 12, background: W.paperAlt, position:'relative'}}>
            <LineCard line={{no:4, para:4, exact:3, fuzzy:2, mismatch:0}} words={SAMPLE_WORDS_L4} highlighted/>
            <LineCard line={{no:6, para:6, exact:1, fuzzy:1, mismatch:0}} words={SAMPLE_WORDS_L6}/>
            <LineCard line={{no:7, para:7, exact:1, fuzzy:0, mismatch:4}} words={SAMPLE_WORDS_L7}/>
            <div className="wf-scrollbar"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────
// V2 — LEFT RAIL TOOLBAR
// Tools live on a left rail (modes + layers + bulk-actions popover).
// Header is slim. Canvas + matches share the rest. Toolbar matrix is
// hidden behind a "Bulk…" button revealing the grid as a popover.
// ──────────────────────────────────────────────────────────────────
function ProjectPageV2() {
  return (
    <div className="wf" style={{display:'flex'}}>
      {/* ─── LEFT RAIL ─── */}
      <div style={{
        width: 72, flex:'0 0 72px',
        background: W.paperAlt, borderRight: `1px solid ${W.rule}`,
        display:'flex', flexDirection:'column', alignItems:'center', padding: '12px 0', gap: 4,
      }}>
        <span style={{fontFamily:W.hand, fontSize:18, color:W.ink, marginBottom:8}}>ocr·</span>
        {/* modes */}
        {[
          {k:'Select', icon:'⬚', hot:'S', active:true},
          {k:'Rebox',  icon:'⤡', hot:'R'},
          {k:'Add',    icon:'＋', hot:'A'},
          {k:'Erase',  icon:'⌫', hot:'E'},
        ].map(m => (
          <div key={m.k} style={{
            width: 52, padding: '8px 0',
            background: m.active ? '#fff' : 'transparent',
            border: m.active ? `1px solid ${W.ink3}` : '1px solid transparent',
            borderRadius: 6,
            display:'flex', flexDirection:'column', alignItems:'center', gap:3,
          }}>
            <span style={{fontSize:18, lineHeight:1, color: m.active ? W.ink : W.ink2}}>{m.icon}</span>
            <span style={{fontSize:10, fontWeight:600, color: m.active ? W.ink : W.ink2}}>{m.k}</span>
            <span className="wf-key" style={{height:14, minWidth:14, fontSize:9}}>{m.hot}</span>
          </div>
        ))}
        <div style={{width:'70%', height:1, background:W.rule, margin:'12px 0'}}></div>
        {/* layers */}
        <span className="wf-h-label" style={{fontSize:8}}>LAYERS</span>
        {[
          ['Para', W.paraColor],
          ['Line', W.lineColor],
          ['Word', W.wordColor],
        ].map(([l,c]) => (
          <div key={l} style={{
            width: 52, padding: '6px 0',
            display:'flex', flexDirection:'column', alignItems:'center', gap:3,
          }}>
            <span style={{width:18, height:18, borderRadius:4, background:c+'33', border:`1.5px solid ${c}`}}></span>
            <span style={{fontSize:10, color:W.ink2}}>{l}</span>
          </div>
        ))}
        <div style={{width:'70%', height:1, background:W.rule, margin:'12px 0'}}></div>
        {/* tools */}
        {[{k:'Bulk',icon:'⌗'},{k:'Erase Px',icon:'🩹'},{k:'Hotkeys',icon:'⌘'}].map(t => (
          <div key={t.k} style={{
            width: 52, padding: '6px 0',
            display:'flex', flexDirection:'column', alignItems:'center', gap:3, color:W.ink2,
          }}>
            <span style={{fontSize:14}}>{t.icon}</span>
            <span style={{fontSize:10}}>{t.k}</span>
          </div>
        ))}
      </div>

      {/* ─── MAIN ─── */}
      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        {/* slim header */}
        <div style={{
          height: 52, borderBottom:`1px solid ${W.rule}`, background:W.panel,
          display:'flex', alignItems:'center', gap: 16, padding: '0 18px',
        }}>
          <HField label="Project" value="willa-cather-letters" w={180}/>
          <PageNav page={47} total={392}/>
          <div style={{flex:1, display:'flex', gap:14, justifyContent:'center'}}>
            <MetricChip value="22" label="words"/>
            <MetricChip value="15" label="exact" color={W.exact}/>
            <MetricChip value="7" label="fuzzy" color={W.fuzzy}/>
            <MetricChip value="0" label="mismatch" color={W.mismatch}/>
            <MetricChip value="100%" label="match"/>
            <MetricChip value="22/22" label="validated"/>
          </div>
          <span className="wf-btn">Reload OCR</span>
          <span className="wf-btn">Rematch</span>
          <span className="wf-btn primary">Save Page</span>
          <span className="wf-btn">Export ▾</span>
        </div>

        {/* split panes */}
        <div style={{flex:1, display:'flex', minHeight:0}}>
          {/* canvas */}
          <div style={{flex: '1 1 55%', borderRight: `1px solid ${W.rule}`, position:'relative', padding: 20}}>
            <PageScan/>
            {/* mode badge floating */}
            <div style={{
              position:'absolute', top: 32, left: 32,
              background: '#fff', border:`1px solid ${W.ink3}`, borderRadius:6, padding:'6px 12px',
              fontSize:11, fontWeight:600, display:'flex', alignItems:'center', gap:8,
            }}>
              <span style={{width:8, height:8, borderRadius:4, background:W.accent}}></span>
              SELECT mode · drag to box-select
            </div>
            <div className="wf-note" style={{bottom: 24, left: 32}}>
              ← rail = mode + layers; pulls<br/>~14 buttons out of header
            </div>
          </div>

          {/* matches panel */}
          <div style={{flex:'1 1 45%', display:'flex', flexDirection:'column', minWidth: 0}}>
            <div style={{padding:'0 14px', borderBottom:`1px solid ${W.rule}`, background:W.panel,
              display:'flex', alignItems:'center', justifyContent:'space-between',
            }}>
              <TabBar tabs={['Matches', 'Ground Truth', 'OCR']} active="Matches"/>
              <div style={{display:'flex', gap:6, alignItems:'center'}}>
                <input className="wf-input" placeholder="Find word…" style={{width:140, height:24, fontSize:11}}/>
                <span className="wf-btn sm">Bulk ▾</span>
              </div>
            </div>
            {/* filter row */}
            <div style={{
              display:'flex', alignItems:'center', gap:6, padding:'8px 14px',
              borderBottom:`1px solid ${W.rule}`, background:W.paperAlt,
            }}>
              <span className="wf-h-label" style={{marginRight:4}}>Show</span>
              <span className="wf-chip" style={{background:W.fuzzy+'20', color:W.fuzzy, borderColor:W.fuzzy+'88'}}>Unvalidated 7</span>
              <span className="wf-chip" style={{background:W.mismatch+'20', color:W.mismatch, borderColor:W.mismatch+'88'}}>Mismatched 5</span>
              <span className="wf-chip">All 22</span>
              <div style={{flex:1}}></div>
              <span className="wf-h-label">Sort</span>
              <span className="wf-chip">Reading order ▾</span>
            </div>
            {/* list */}
            <div style={{flex:1, overflow:'hidden', padding: 12, background: W.paperAlt, position:'relative'}}>
              <LineCard line={{no:4, para:4, exact:3, fuzzy:2, mismatch:0}} words={SAMPLE_WORDS_L4} highlighted compact/>
              <LineCard line={{no:6, para:6, exact:1, fuzzy:1, mismatch:0}} words={SAMPLE_WORDS_L6} compact/>
              <LineCard line={{no:7, para:7, exact:1, fuzzy:0, mismatch:4}} words={SAMPLE_WORDS_L7} compact/>
              <div className="wf-scrollbar"></div>
              {/* bulk popover preview */}
              <div style={{
                position:'absolute', top: 24, right: 36,
                width: 380, background:'#fff', border:`1px solid ${W.ink3}`, borderRadius:8,
                padding: 12, boxShadow:'0 8px 28px rgba(0,0,0,0.18)',
              }}>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6}}>
                  <span style={{fontSize:11, fontWeight:700, letterSpacing:'0.05em'}}>BULK ACTIONS</span>
                  <span className="wf-key">B</span>
                </div>
                <ActionMatrix density="sm"/>
                <div style={{fontSize:10, color:W.ink3, marginTop:6}}>Applies to current selection</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────
// V3 — COMMAND SURFACE
// Minimal chrome. Big canvas. Bulk actions, file ops, navigation all
// flow through a ⌘K command palette. Mode + layer toggles float
// over the canvas. Right panel is purely the editor list.
// ──────────────────────────────────────────────────────────────────
function ProjectPageV3() {
  return (
    <div className="wf">
      {/* TINY HEADER */}
      <div style={{
        height: 44, borderBottom:`1px solid ${W.rule}`, background:W.panel,
        display:'flex', alignItems:'center', gap: 14, padding:'0 16px',
      }}>
        <span style={{fontFamily:W.hand, fontSize:20, color:W.ink}}>ocr·labeler</span>
        <span style={{color:W.ink4}}>/</span>
        <span style={{fontSize:13, fontWeight:600}}>willa-cather-letters</span>
        <span style={{color:W.ink4}}>/</span>
        <span style={{fontSize:13, color:W.ink2}}>page 47</span>
        <div style={{flex:1}}></div>
        <PageNav page={47} total={392} compact/>
        <div style={{
          height:30, padding:'0 12px', display:'flex', alignItems:'center', gap:8,
          background:W.paperAlt, border:`1px solid ${W.ink4}`, borderRadius:6,
          color:W.ink3, fontSize:12, minWidth:240,
        }}>
          <span style={{color:W.ink3}}>⌕</span>
          <span style={{flex:1}}>Search actions, pages, words…</span>
          <span className="wf-key">⌘</span><span className="wf-key">K</span>
        </div>
        <span className="wf-btn primary">Save</span>
      </div>

      {/* BODY */}
      <div style={{display:'flex', height:'calc(100% - 44px)'}}>
        {/* canvas */}
        <div style={{flex:'1 1 62%', borderRight:`1px solid ${W.rule}`, position:'relative', padding: 24, background:W.paperAlt}}>
          <PageScan/>
          {/* floating layer card */}
          <div style={{
            position:'absolute', top: 40, left: 40, padding: 10,
            background:'#fff', border:`1px solid ${W.ink3}`, borderRadius: 8,
            boxShadow:'0 4px 12px rgba(0,0,0,0.06)',
            display:'flex', flexDirection:'column', gap:8, minWidth: 160,
          }}>
            <span className="wf-h-label">Layers</span>
            {['Paragraphs','Lines','Words'].map((l,i) => (
              <div key={l} style={{display:'flex', alignItems:'center', gap:8}}>
                <span style={{width:14, height:14, borderRadius:3, background:[W.paraColor,W.lineColor,W.wordColor][i]+'33', border:`1.5px solid ${[W.paraColor,W.lineColor,W.wordColor][i]}`}}></span>
                <span style={{fontSize:11, flex:1}}>{l}</span>
                <span style={{fontSize:11, color:W.ink3}}>✓</span>
              </div>
            ))}
          </div>
          {/* floating mode card */}
          <div style={{
            position:'absolute', bottom: 40, left: '50%', transform:'translateX(-50%)',
          }}>
            <ModeSwitcher active="Select" big/>
          </div>
          {/* command palette preview */}
          <div style={{
            position:'absolute', top: 90, right: 60,
            width: 340, background: '#fff', border:`1px solid ${W.ink3}`, borderRadius: 10,
            boxShadow:'0 16px 50px rgba(0,0,0,0.18)', padding: 8,
          }}>
            <div style={{
              padding: 8, fontSize: 13, color:W.ink2,
              borderBottom: `1px solid ${W.rule}`, marginBottom: 4,
            }}>refine<span style={{borderRight:`1px solid ${W.ink}`, marginLeft:1, animation:'none'}}></span></div>
            {[
              ['Refine Bboxes', 'page',  'R B'],
              ['Refine + Expand', 'line', 'R E'],
              ['Refine selected words', 'word', '⇧R'],
              ['Reload OCR', 'page', '⌘R'],
              ['Rematch Ground Truth', 'page', '⌘M'],
            ].map(([n,scope,key], i) => (
              <div key={n} style={{
                display:'flex', alignItems:'center', gap:8,
                padding:'7px 8px', borderRadius:5,
                background: i===0 ? W.paperAlt : 'transparent',
                fontSize: 12,
              }}>
                <span style={{flex:1}}>{n}</span>
                <span className="wf-chip" style={{fontSize:9, height:14}}>{scope}</span>
                <span style={{display:'flex', gap:3}}>
                  {key.split(' ').map(k => <span key={k} className="wf-key" style={{height:14, fontSize:9}}>{k}</span>)}
                </span>
              </div>
            ))}
            <div style={{padding:'6px 8px 4px', fontSize:10, color:W.ink3, borderTop:`1px solid ${W.rule}`, marginTop:4}}>
              ↑↓ navigate · ↵ run · esc close
            </div>
          </div>
          <div className="wf-note" style={{top: 24, right: 24}}>
            <span>⌘K palette replaces<br/>~14-button header</span>
          </div>
        </div>

        {/* matches panel */}
        <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
          <div style={{padding:'0 14px', borderBottom:`1px solid ${W.rule}`, background:W.panel,
            display:'flex', alignItems:'center', justifyContent:'space-between',
          }}>
            <TabBar tabs={['Matches', 'Ground Truth', 'OCR']} active="Matches"/>
            <div style={{display:'flex', gap:6, alignItems:'center', fontSize:11, color:W.ink3}}>
              <MetricChip value="15" label="✓" color={W.exact}/>
              <MetricChip value="7"  label="~" color={W.fuzzy}/>
              <MetricChip value="0"  label="✗" color={W.mismatch}/>
            </div>
          </div>
          <div style={{padding:'8px 14px', borderBottom:`1px solid ${W.rule}`, background:W.paperAlt,
            display:'flex', alignItems:'center', gap:6,
          }}>
            <span className="wf-chip" style={{background:W.fuzzy+'20', color:W.fuzzy, borderColor:W.fuzzy+'88'}}>Unvalidated 7</span>
            <span className="wf-chip" style={{background:W.mismatch+'20', color:W.mismatch, borderColor:W.mismatch+'88'}}>Mismatched 5</span>
            <span className="wf-chip">All 22</span>
            <div style={{flex:1}}></div>
            <span style={{fontSize:10, color:W.ink3, display:'flex', alignItems:'center', gap:4}}>
              <span className="wf-key">↹</span> next word · <span className="wf-key">v</span> validate · <span className="wf-key">⏎</span> commit
            </span>
          </div>
          <div style={{flex:1, padding:12, background:W.paperAlt, position:'relative', overflow:'hidden'}}>
            <LineCard line={{no:4, para:4, exact:3, fuzzy:2, mismatch:0}} words={SAMPLE_WORDS_L4} highlighted/>
            <LineCard line={{no:6, para:6, exact:1, fuzzy:1, mismatch:0}} words={SAMPLE_WORDS_L6}/>
            <LineCard line={{no:7, para:7, exact:1, fuzzy:0, mismatch:4}} words={SAMPLE_WORDS_L7}/>
            <div className="wf-scrollbar"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────
// V4 — INSPECTOR RIGHT
// 3-column: slim left rail · canvas · right column = matches list (top
// half) + selected-word inspector (bottom half). NO scope×action matrix —
// actions are contextual to the current selection in the inspector.
// ──────────────────────────────────────────────────────────────────
function ProjectPageV4() {
  return (
    <div className="wf" style={{display:'flex'}}>
      {/* rail */}
      <div style={{
        width: 56, flex:'0 0 56px', background:W.paperAlt, borderRight:`1px solid ${W.rule}`,
        display:'flex', flexDirection:'column', alignItems:'center', padding:'12px 0', gap:10,
      }}>
        <span style={{fontFamily:W.hand, fontSize:17}}>ol.</span>
        {[
          ['⬚','Select',true],['⤡','Rebox'],['＋','Add'],['⌫','Erase'],
        ].map(([i,n,a],idx) => (
          <div key={idx} style={{
            width: 40, height: 40, borderRadius:6,
            background: a ? '#fff' : 'transparent',
            border: a ? `1px solid ${W.ink3}` : '1px solid transparent',
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:16,
            color: a ? W.ink : W.ink2,
          }}>{i}</div>
        ))}
        <div style={{width:'60%', height:1, background:W.rule}}></div>
        {[W.paraColor,W.lineColor,W.wordColor].map((c,i) => (
          <div key={i} style={{width:24,height:24,borderRadius:5,background:c+'33',border:`1.5px solid ${c}`}}></div>
        ))}
      </div>

      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        {/* slim header */}
        <div style={{
          height:48, borderBottom:`1px solid ${W.rule}`, background:W.panel,
          display:'flex', alignItems:'center', gap:14, padding:'0 18px',
        }}>
          <HField label="Project" value="willa-cather-letters" w={180}/>
          <PageNav page={47} total={392}/>
          <div style={{flex:1, display:'flex', gap:12, justifyContent:'center'}}>
            <MetricChip value="15" label="✓ exact" color={W.exact}/>
            <MetricChip value="7" label="~ fuzzy" color={W.fuzzy}/>
            <MetricChip value="0" label="✗" color={W.mismatch}/>
            <MetricChip value="22/22" label="validated"/>
          </div>
          <span className="wf-btn">File ▾</span>
          <span className="wf-btn">OCR ▾</span>
          <span className="wf-btn primary">Save Page</span>
        </div>

        {/* main */}
        <div style={{flex:1, display:'flex', minHeight:0}}>
          {/* canvas */}
          <div style={{flex:'1 1 55%', borderRight:`1px solid ${W.rule}`, padding:18, position:'relative', background:W.paperAlt}}>
            <PageScan/>
          </div>

          {/* right column */}
          <div style={{flex:'0 0 540px', display:'flex', flexDirection:'column', minWidth:0}}>
            {/* matches (top half) */}
            <div style={{flex:'1 1 50%', display:'flex', flexDirection:'column', borderBottom:`2px solid ${W.ink3}`, minHeight:0}}>
              <div style={{padding:'0 14px', borderBottom:`1px solid ${W.rule}`, background:W.panel,
                display:'flex', alignItems:'center', justifyContent:'space-between',
              }}>
                <TabBar tabs={['Matches', 'GT', 'OCR']} active="Matches"/>
                <span style={{fontSize:10, color:W.ink3}}>3 lines · 22 words</span>
              </div>
              <div style={{padding:'8px 12px', background:W.paperAlt, borderBottom:`1px solid ${W.rule}`,
                display:'flex', gap:6,
              }}>
                <span className="wf-chip" style={{background:W.fuzzy+'20', color:W.fuzzy, borderColor:W.fuzzy+'88'}}>Unvalidated 7</span>
                <span className="wf-chip" style={{background:W.mismatch+'20', color:W.mismatch, borderColor:W.mismatch+'88'}}>Mismatched 5</span>
                <span className="wf-chip">All</span>
              </div>
              <div style={{flex:1, padding:10, background:W.paperAlt, overflow:'hidden', position:'relative'}}>
                <LineCard line={{no:4, para:4, exact:3, fuzzy:2, mismatch:0}} words={SAMPLE_WORDS_L4} highlighted compact/>
                <LineCard line={{no:6, para:6, exact:1, fuzzy:1, mismatch:0}} words={SAMPLE_WORDS_L6} compact/>
                <LineCard line={{no:7, para:7, exact:1, fuzzy:0, mismatch:4}} words={SAMPLE_WORDS_L7} compact/>
                <div className="wf-scrollbar"></div>
              </div>
            </div>

            {/* inspector (bottom half) */}
            <div style={{flex:'1 1 50%', display:'flex', flexDirection:'column', background:W.panel, minHeight:0}}>
              <div style={{padding:'10px 14px', display:'flex', alignItems:'center', gap:8, borderBottom:`1px solid ${W.rule}`}}>
                <span className="wf-h-label">Inspector</span>
                <span style={{fontSize:12, fontWeight:600}}>Line 4 · Word 3 of 5</span>
                <StatusPip kind="fuzzy" label="fuzzy 83%"/>
                <div style={{flex:1}}></div>
                <span className="wf-btn sm">◀ Prev</span>
                <span className="wf-btn sm">Next ▶</span>
              </div>
              <div style={{padding:14, display:'flex', gap:14, flex:1, minHeight:0}}>
                {/* zoom */}
                <div style={{flex:'0 0 200px', display:'flex', flexDirection:'column', gap:8}}>
                  <span className="wf-h-label">Word image</span>
                  <div style={{
                    flex:1, background:'#fff', border:`1px solid ${W.rule}`, borderRadius:4,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontFamily:'"Times New Roman", serif', fontSize: 42, fontVariant:'small-caps',
                  }}>Ph.D.,</div>
                  <div style={{display:'flex', gap:4}}>
                    {['1×','2×','5×','10×'].map(z => (
                      <span key={z} className="wf-btn sm" style={{flex:1, background: z==='2×'?W.ink:W.panel, color: z==='2×'?'#fff':W.ink, borderColor: z==='2×'?W.ink:W.ink3}}>{z}</span>
                    ))}
                  </div>
                </div>
                {/* fields */}
                <div style={{flex:1, display:'flex', flexDirection:'column', gap:10, minWidth:0}}>
                  <div>
                    <span className="wf-h-label">OCR</span>
                    <div className="wf-mono" style={{padding:6, background:W.panelSunk, borderRadius:3, marginTop:4}}>PH.D.,</div>
                  </div>
                  <div>
                    <span className="wf-h-label">Ground Truth</span>
                    <input className="wf-input lg" defaultValue="Ph.D.," style={{width:'100%', marginTop:4}}/>
                  </div>
                  <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
                    <span className="wf-chip">Sm. Caps<span className="x">×</span></span>
                    <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ style</span>
                    <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ component</span>
                  </div>
                  <div style={{display:'flex', gap:4, flexWrap:'wrap', marginTop:'auto'}}>
                    <span className="wf-btn sm primary">✓ Validate <span className="wf-key" style={{height:13, fontSize:9, background:'#0002', borderColor:'transparent', color:'#fff'}}>V</span></span>
                    <span className="wf-btn sm">OCR → GT</span>
                    <span className="wf-btn sm">Rebox</span>
                    <span className="wf-btn sm">Edit…</span>
                    <span className="wf-btn sm danger">🗑</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────
// V5 — WORKLIST
// A queue-driven layout. Left: filtered worklist of "what still needs
// your attention" (mismatched + fuzzy + unvalidated). Center: canvas.
// Right: a single focused word card (huge, comfortable). Power user
// keeps J/K-ing through the queue.
// ──────────────────────────────────────────────────────────────────
function ProjectPageV5() {
  const queue = [
    {line:7, word:1, ocr:'tbe',       gt:'The',       status:'mismatch', conf:'42%'},
    {line:7, word:2, ocr:'Jounding',  gt:'Founding',  status:'mismatch', conf:'38%'},
    {line:7, word:4, ocr:'tbe',       gt:'the',       status:'mismatch', conf:'44%'},
    {line:7, word:5, ocr:'Gopernment',gt:'Government',status:'mismatch', conf:'29%'},
    {line:4, word:3, ocr:'PH.D.,',    gt:'Ph.D.,',    status:'fuzzy',    conf:'83%'},
    {line:4, word:4, ocr:'LITT.D.,',  gt:'Litt.D.,',  status:'fuzzy',    conf:'62%'},
    {line:6, word:1, ocr:'VOL.',      gt:'Vol.',      status:'fuzzy',    conf:'75%'},
  ];
  return (
    <div className="wf" style={{display:'flex', flexDirection:'column'}}>
      {/* header */}
      <div style={{
        height:46, borderBottom:`1px solid ${W.rule}`, background:W.panel,
        display:'flex', alignItems:'center', gap:14, padding:'0 18px',
      }}>
        <span style={{fontFamily:W.hand, fontSize:18}}>ocr·labeler</span>
        <span style={{color:W.ink4}}>/</span>
        <span style={{fontSize:13, fontWeight:600}}>willa-cather-letters</span>
        <PageNav page={47} total={392} compact/>
        <div style={{flex:1, height:8, background:W.panelSunk, borderRadius:4, position:'relative', maxWidth:280, marginLeft:20}}>
          <div style={{position:'absolute', inset:0, width:'68%', background:W.exact, borderRadius:4}}></div>
          <div style={{position:'absolute', top:0, bottom:0, left:'68%', width:'32%', background:W.fuzzy+'88', borderRadius:4}}></div>
        </div>
        <span style={{fontSize:11, color:W.ink2}}>15/22 validated</span>
        <div style={{flex:1}}></div>
        <span className="wf-btn ghost">File ▾</span>
        <span className="wf-btn ghost">OCR ▾</span>
        <span className="wf-btn primary">Save Page</span>
      </div>

      <div style={{flex:1, display:'flex', minHeight:0}}>
        {/* WORKLIST */}
        <div style={{
          flex:'0 0 320px', borderRight:`1px solid ${W.rule}`,
          display:'flex', flexDirection:'column', background:W.panel, minWidth:0,
        }}>
          <div style={{padding:'12px 14px', borderBottom:`1px solid ${W.rule}`,
            display:'flex', flexDirection:'column', gap:8,
          }}>
            <div style={{display:'flex', alignItems:'baseline', justifyContent:'space-between'}}>
              <span style={{fontSize:14, fontWeight:700}}>Worklist</span>
              <span style={{fontSize:10, color:W.ink3}}>7 of 22</span>
            </div>
            <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
              <span className="wf-chip" style={{background:W.mismatch+'20', color:W.mismatch, borderColor:W.mismatch+'88'}}>✗ mismatch 4</span>
              <span className="wf-chip" style={{background:W.fuzzy+'20', color:W.fuzzy, borderColor:W.fuzzy+'88'}}>~ fuzzy 3</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ unmatched</span>
            </div>
            <div style={{display:'flex', gap:4, alignItems:'center'}}>
              <span className="wf-h-label">Sort</span>
              <span className="wf-chip">Confidence ↑</span>
              <div style={{flex:1}}></div>
              <span style={{fontSize:10, color:W.ink3}}><span className="wf-key">J</span>/<span className="wf-key">K</span> nav</span>
            </div>
          </div>
          {/* queue items */}
          <div style={{flex:1, overflow:'hidden', padding: 4, position:'relative'}}>
            {queue.map((q, i) => {
              const focused = i === 0;
              const c = q.status === 'mismatch' ? W.mismatch : W.fuzzy;
              return (
                <div key={i} style={{
                  padding: 10, margin: '4px 4px', borderRadius: 5,
                  background: focused ? W.hi : 'transparent',
                  border: focused ? `1.5px solid ${W.accent}` : `1px solid transparent`,
                  display:'flex', gap:8, alignItems:'center',
                }}>
                  <span style={{width:6, height:36, borderRadius:3, background:c}}></span>
                  <div style={{flex:1, minWidth:0}}>
                    <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:3}}>
                      <span style={{fontSize:10, color:W.ink3, fontWeight:600}}>L{q.line}·W{q.word}</span>
                      <StatusPip kind={q.status}/>
                      <span style={{fontSize:10, color:W.ink3, marginLeft:'auto'}}>{q.conf}</span>
                    </div>
                    <div style={{fontFamily: W.mono, fontSize: 11, color:W.ink3, whiteSpace:'nowrap', overflow:'hidden'}}>
                      <span style={{color: W.ink3}}>{q.ocr}</span>
                      <span style={{margin:'0 6px', color:W.ink4}}>→</span>
                      <span style={{color: W.ink}}>{q.gt}</span>
                    </div>
                  </div>
                </div>
              );
            })}
            <div className="wf-scrollbar"></div>
          </div>
          {/* footer with global bulk */}
          <div style={{
            padding:'10px 14px', borderTop:`1px solid ${W.rule}`,
            display:'flex', flexDirection:'column', gap:6,
          }}>
            <span className="wf-h-label">Bulk on filtered</span>
            <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
              <span className="wf-btn sm">Refine all</span>
              <span className="wf-btn sm">OCR → GT</span>
              <span className="wf-btn sm">Validate</span>
              <span className="wf-btn sm">Open grid…</span>
            </div>
          </div>
        </div>

        {/* CANVAS */}
        <div style={{flex:'1 1 0', borderRight:`1px solid ${W.rule}`, padding:18, position:'relative', background:W.paperAlt, minWidth:0}}>
          <div style={{
            position:'absolute', top:12, left:18, right:18,
            display:'flex', alignItems:'center', gap:10, padding:'6px 10px',
            background:W.panel, border:`1px solid ${W.rule}`, borderRadius:6,
          }}>
            <LayerLegend/>
            <div style={{flex:1}}></div>
            <ModeSwitcher active="Select"/>
            <span className="wf-btn sm danger">Erase Px</span>
          </div>
          <div style={{position:'absolute', inset:'56px 18px 18px 18px'}}>
            <PageScan/>
          </div>
          <div className="wf-note" style={{bottom: 30, right: 30, textAlign:'right'}}>
            <span>canvas auto-scrolls to<br/>focused word in queue</span>
          </div>
        </div>

        {/* FOCUSED WORD CARD */}
        <div style={{
          flex:'0 0 460px', display:'flex', flexDirection:'column',
          background:W.panel, minWidth:0,
        }}>
          <div style={{padding:'12px 16px', borderBottom:`1px solid ${W.rule}`,
            display:'flex', alignItems:'center', gap:10}}>
            <span className="wf-h-label">Editing</span>
            <span style={{fontSize:13, fontWeight:700}}>Line 7 · Word 1</span>
            <StatusPip kind="mismatch"/>
            <div style={{flex:1}}></div>
            <span style={{fontSize:10, color:W.ink3}}>1 of 7</span>
          </div>

          <div style={{padding:18, display:'flex', flexDirection:'column', gap:14, flex:1, minHeight:0}}>
            {/* word zoom */}
            <div style={{
              background:'#fff', border:`1px solid ${W.rule}`, borderRadius:6,
              padding:'30px 20px',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'serif', fontSize: 64, color:W.ink,
            }}>The</div>

            {/* compare grid */}
            <div style={{display:'grid', gridTemplateColumns:'auto 1fr auto', rowGap:10, columnGap:10, alignItems:'center'}}>
              <span className="wf-h-label">OCR</span>
              <div className="wf-mono" style={{padding:'8px 10px', background:W.panelSunk, borderRadius:4, fontSize:14}}>tbe</div>
              <span className="wf-btn sm">→ GT</span>
              <span className="wf-h-label">GT</span>
              <input className="wf-input lg" defaultValue="The" style={{width:'100%', fontSize:14}}/>
              <span></span>
            </div>

            {/* style chips */}
            <div>
              <span className="wf-h-label">Style</span>
              <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
                <span className="wf-chip">Blackletter<span className="x">×</span></span>
                <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ italic</span>
                <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ small-caps</span>
              </div>
            </div>

            {/* actions */}
            <div style={{
              marginTop:'auto', display:'flex', flexDirection:'column', gap:8,
            }}>
              <div style={{display:'flex', gap:6}}>
                <span className="wf-btn primary lg" style={{flex:1}}>
                  ✓ Validate &amp; Next <span className="wf-key" style={{height:16, background:'#0003', color:'#fff', borderColor:'transparent', marginLeft:6}}>⏎</span>
                </span>
                <span className="wf-btn lg ghost">Skip</span>
              </div>
              <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
                <span className="wf-btn sm">Rebox <span className="wf-key">R</span></span>
                <span className="wf-btn sm">Refine <span className="wf-key">F</span></span>
                <span className="wf-btn sm">Merge prev</span>
                <span className="wf-btn sm">Merge next</span>
                <span className="wf-btn sm">Split</span>
                <span className="wf-btn sm danger">Delete</span>
                <span className="wf-btn sm">Open dialog…</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  ProjectPageV1, ProjectPageV2, ProjectPageV3, ProjectPageV4, ProjectPageV5,
  LineCard, HField, MetricChip, TabBar, PageNav,
});
