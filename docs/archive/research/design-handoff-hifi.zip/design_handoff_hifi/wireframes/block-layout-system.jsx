// Nested block layout system
//
// Model:
//   • The page is a tree of BLOCKS. Blocks can contain blocks OR lines.
//   • A block whose children are LINES is — emergently — a "paragraph".
//     A block whose children are BLOCKS is a structural container.
//   • Every block has a layout type (chapter-heading, column, footnote…).
//   • Same type can appear at any depth — a blockquote may be a leaf
//     (one logical paragraph) OR contain 2 paragraphs.
//   • Auto-detection runs on segmentation; user reviews + corrects.
//
// Selection rail target: B / L / W  (Block / Line / Word).

// =====================================================================
// Block type catalogue (split into Structural vs Content)
// =====================================================================
const BLOCK_TYPES_ALL = [
  // Structural — typically contain other blocks
  { g:'Structural', k:'body',          l:'body (main)',         shape:'body',     tier:1 },
  { g:'Structural', k:'column',        l:'column',              shape:'column-glyph', tier:1 },
  { g:'Structural', k:'sidebar',       l:'sidebar',             shape:'sidebar-glyph', tier:2 },
  { g:'Structural', k:'header_band',   l:'header band',         shape:'rhead',    tier:2 },
  { g:'Structural', k:'footer_band',   l:'footer band',         shape:'rfoot',    tier:2 },
  { g:'Structural', k:'footnote_band', l:'footnote band',       shape:'footnote', tier:2 },
  { g:'Structural', k:'marginalia',    l:'marginalia region',   shape:'marginalia-glyph', tier:3 },
  { g:'Structural', k:'figure_region', l:'figure region',       shape:'figure-glyph', tier:3 },
  { g:'Structural', k:'table_region',  l:'table region',        shape:'table',    tier:3 },
  // Content — typically leaves (contain lines = "paragraph")
  { g:'Content',    k:'body_text',     l:'body text',           shape:'body',     tier:1, defaultType:true },
  { g:'Content',    k:'chap_head',     l:'chapter heading',     shape:'h1',       tier:1 },
  { g:'Content',    k:'sec_head',      l:'section heading',     shape:'h2',       tier:1 },
  { g:'Content',    k:'sub_head',      l:'subsection heading',  shape:'h3',       tier:2 },
  { g:'Content',    k:'title',         l:'title',               shape:'title',    tier:2 },
  { g:'Content',    k:'subtitle',      l:'subtitle',            shape:'subtitle', tier:3 },
  { g:'Content',    k:'byline',        l:'byline / author',     shape:'byline',   tier:3 },
  { g:'Content',    k:'block_quote',   l:'block quote',         shape:'quote',    tier:2 },
  { g:'Content',    k:'epigraph',      l:'epigraph',            shape:'epigraph', tier:3 },
  { g:'Content',    k:'list',          l:'list',                shape:'list',     tier:2 },
  { g:'Content',    k:'list_item',     l:'list item',           shape:'list',     tier:3 },
  { g:'Content',    k:'verse',         l:'verse / poem',        shape:'verse',    tier:3 },
  { g:'Content',    k:'caption',       l:'figure caption',      shape:'caption',  tier:2 },
  { g:'Content',    k:'footnote',      l:'footnote entry',      shape:'footnote', tier:2 },
  { g:'Content',    k:'header_text',   l:'running header text', shape:'rhead',    tier:2 },
  { g:'Content',    k:'footer_text',   l:'page number',         shape:'rfoot',    tier:2 },
];

// Block color — distinct from paragraph (green) / line (pink) / word (blue).
const BLOCK_COLOR = '#7a6c5a';   // warm taupe

// =====================================================================
// Extended LayoutTypeShape — adds a few new structural glyphs
// =====================================================================
function BlockGlyph({ kind, active, size=36 }) {
  const c = active ? W.ink : W.ink3;
  const W2 = 38, H2 = 36;
  // Structural-specific glyphs
  if (kind === 'column-glyph') {
    return (
      <svg viewBox={`0 0 ${W2} ${H2}`} width={size} height={size}>
        <rect x={1} y={1} width={W2-2} height={H2-2} rx={2} ry={2}
          fill={active?'#fff':W.paperAlt} stroke={active?c:W.ruleSoft} strokeWidth={0.8}/>
        <rect x={4}  y={5}  width={12} height={26} fill="none" stroke={c} strokeWidth={1.2} rx={1}/>
        <line x1={6} y1={9}  x2={14} y2={9}  stroke={c} strokeWidth={0.8}/>
        <line x1={6} y1={13} x2={14} y2={13} stroke={c} strokeWidth={0.8}/>
        <line x1={6} y1={17} x2={14} y2={17} stroke={c} strokeWidth={0.8}/>
        <line x1={6} y1={21} x2={14} y2={21} stroke={c} strokeWidth={0.8}/>
        <line x1={6} y1={25} x2={12} y2={25} stroke={c} strokeWidth={0.8}/>
        <rect x={22} y={5}  width={12} height={26} fill="none" stroke={c} strokeWidth={1.2} rx={1}
          opacity={0.45}/>
      </svg>
    );
  }
  if (kind === 'sidebar-glyph') {
    return (
      <svg viewBox={`0 0 ${W2} ${H2}`} width={size} height={size}>
        <rect x={1} y={1} width={W2-2} height={H2-2} rx={2} ry={2}
          fill={active?'#fff':W.paperAlt} stroke={active?c:W.ruleSoft} strokeWidth={0.8}/>
        <rect x={4}  y={4} width={20} height={28} fill="none" stroke={c+'88'} strokeWidth={0.7} rx={1}/>
        {[8,14,20,26].map((y, i) => (
          <line key={i} x1={6} y1={y} x2={22} y2={y} stroke={c+'88'} strokeWidth={0.7}/>
        ))}
        <rect x={27} y={4} width={8} height={28} fill={c+'1f'} stroke={c} strokeWidth={1.2} rx={1}/>
        {[8,14,20,26].map((y, i) => (
          <line key={i} x1={29} y1={y} x2={33} y2={y} stroke={c} strokeWidth={0.8}/>
        ))}
      </svg>
    );
  }
  if (kind === 'marginalia-glyph') {
    return (
      <svg viewBox={`0 0 ${W2} ${H2}`} width={size} height={size}>
        <rect x={1} y={1} width={W2-2} height={H2-2} rx={2} ry={2}
          fill={active?'#fff':W.paperAlt} stroke={active?c:W.ruleSoft} strokeWidth={0.8}/>
        {[8,14,20,26].map((y, i) => (
          <line key={i} x1={12} y1={y} x2={32} y2={y} stroke={c+'aa'} strokeWidth={0.8}/>
        ))}
        {/* margin notes */}
        <line x1={4}  y1={10} x2={9}  y2={10} stroke={c} strokeWidth={1.4}/>
        <line x1={4}  y1={14} x2={10} y2={14} stroke={c} strokeWidth={1.4}/>
        <line x1={4}  y1={22} x2={8}  y2={22} stroke={c} strokeWidth={1.4}/>
      </svg>
    );
  }
  if (kind === 'figure-glyph') {
    return (
      <svg viewBox={`0 0 ${W2} ${H2}`} width={size} height={size}>
        <rect x={1} y={1} width={W2-2} height={H2-2} rx={2} ry={2}
          fill={active?'#fff':W.paperAlt} stroke={active?c:W.ruleSoft} strokeWidth={0.8}/>
        <rect x={6}  y={4} width={26} height={18} fill="none" stroke={c} strokeWidth={1.2} rx={1}/>
        {/* mountain icon */}
        <polyline points="8,20 14,12 20,16 26,8 30,20" fill="none" stroke={c} strokeWidth={1}/>
        <circle cx={24} cy={9} r={1.5} fill={c}/>
        <line x1={8}  y1={26} x2={30} y2={26} stroke={c+'aa'} strokeWidth={0.8}/>
        <line x1={8}  y1={29} x2={26} y2={29} stroke={c+'aa'} strokeWidth={0.8}/>
      </svg>
    );
  }
  // fall through to original layout-type shape
  return <LayoutTypeShape kind={kind} active={active} size={size}/>;
}

// LayoutTypeCard wrapper to use BlockGlyph instead.
function BlockTypeCard({ label, kind, active, hint }) {
  return (
    <div style={{
      display:'flex', flexDirection:'column', alignItems:'flex-start', gap: 6,
      padding: 10, borderRadius: 6,
      background: active ? W.ink + '08' : W.panel,
      border: active ? `1.5px solid ${W.ink}` : `1px solid ${W.rule}`,
      position:'relative', minWidth: 0,
    }}>
      <BlockGlyph kind={kind} active={active}/>
      <div style={{display:'flex', flexDirection:'column', gap: 1, minWidth:0, width:'100%'}}>
        <span style={{
          fontSize: 11, fontWeight: 600,
          color: active ? W.ink : W.ink2,
          whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
          width:'100%',
        }}>{label}</span>
        {hint && <span style={{fontSize: 9, color: W.ink3}}>{hint}</span>}
      </div>
      {active && (
        <span style={{
          position:'absolute', top: 6, right: 6,
          width: 14, height: 14, borderRadius: 7, background: W.ink, color: '#fff',
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 9, fontWeight: 700,
        }}>✓</span>
      )}
    </div>
  );
}

// =====================================================================
// Sample page tree (used in tree view + canvas overlay)
// =====================================================================
const PAGE_TREE = {
  id: 'page', type: null, label: 'Page 47',
  children: [
    { id:'B1', type:'header_band', label:'Header band', children:[
      { id:'B1.1', type:'header_text', label:'"WOODROW WILSON" — running head', lines:1, words:2 },
    ]},
    { id:'B2', type:'body', label:'Body', children:[
      { id:'B2.1', type:'column', label:'Column 1', children:[
        { id:'B2.1.1', type:'chap_head',  label:'"III · The Founding of the Government"', lines:2, words:7 },
        { id:'B2.1.2', type:'byline',     label:'byline', lines:1, words:3 },
        { id:'B2.1.3', type:'body_text',  label:'body paragraph', lines:12, words:84 },
        { id:'B2.1.4', type:'body_text',  label:'body paragraph', lines:8,  words:56 },
      ]},
      { id:'B2.2', type:'column', label:'Column 2', children:[
        { id:'B2.2.1', type:'body_text',  label:'body paragraph', lines:14, words:102 },
        { id:'B2.2.2', type:'block_quote',label:'extended quotation', children:[
          { id:'B2.2.2.1', type:'body_text', label:'quote paragraph', lines:4, words:22 },
          { id:'B2.2.2.2', type:'body_text', label:'quote paragraph', lines:3, words:18 },
        ]},
        { id:'B2.2.3', type:'body_text',  label:'body paragraph', lines:6, words:41 },
        { id:'B2.2.4', type:'figure_region', label:'figure with caption', children:[
          { id:'B2.2.4.1', type:'caption', label:'caption text', lines:2, words:14 },
        ]},
        { id:'B2.2.5', type:'body_text',  label:'body paragraph', lines:3, words:18 },
      ]},
    ]},
    { id:'B3', type:'footnote_band', label:'Footnote band', children:[
      { id:'B3.1', type:'footnote', label:'footnote 1', lines:2, words:18 },
      { id:'B3.2', type:'footnote', label:'footnote 2', lines:1, words:7 },
    ]},
    { id:'B4', type:'footer_band', label:'Footer band', children:[
      { id:'B4.1', type:'footer_text', label:'page number "47"', lines:1, words:1 },
    ]},
  ],
};

const TYPE_LOOKUP = Object.fromEntries(BLOCK_TYPES_ALL.map(t => [t.k, t]));

function isParagraph(node) {
  // a block whose children are LINES (no .children block array) and has a content type
  return !node.children && typeof node.lines === 'number';
}

// =====================================================================
// PAGE HIERARCHY TREE — visualizes the nesting
// =====================================================================
function TreeRow({ node, depth, selectedId, onSelect, isLast, path = [] }) {
  const meta = node.type ? TYPE_LOOKUP[node.type] : null;
  const isLeaf = !node.children;
  const isPara = isParagraph(node);
  const isStructural = meta && meta.g === 'Structural';
  const selected = node.id === selectedId;
  return (
    <>
      <div style={{
        display:'flex', alignItems:'center', gap: 8,
        padding: '6px 8px',
        background: selected ? W.accent + '0e' : 'transparent',
        border: selected ? `1.5px solid ${W.accent}` : `1px solid transparent`,
        borderRadius: 4,
      }}>
        <span style={{display:'inline-flex', alignItems:'center', minWidth: depth * 18, justifyContent:'flex-end'}}>
          {/* indent guides */}
          {depth > 0 && (
            <span style={{
              width: 12, color: W.ink4, fontFamily: W.mono, fontSize: 12, fontWeight: 400,
            }}>{isLast ? '└─' : '├─'}</span>
          )}
        </span>
        {!isLeaf ? (
          <span style={{
            width: 14, height: 14, borderRadius: 2,
            background: W.panel, border: `1px solid ${W.ink4}`,
            display:'inline-flex', alignItems:'center', justifyContent:'center',
            fontSize: 9, color: W.ink2, transform:'rotate(90deg)',
          }}>▶</span>
        ) : (
          <span style={{width: 14}}></span>
        )}
        {/* kind chip */}
        {node.type ? (
          <span style={{
            display:'inline-flex', alignItems:'center', gap: 5,
            padding:'1px 7px', borderRadius: 9,
            fontSize: 10, fontWeight: 600,
            background: isStructural ? BLOCK_COLOR + '18' : W.paraColor + '20',
            color: isStructural ? BLOCK_COLOR : W.paraColor,
            border: `1px solid ${isStructural ? BLOCK_COLOR + '66' : W.paraColor + '66'}`,
          }}>
            <span style={{width: 8, height: 8, borderRadius: 2, background: isStructural ? BLOCK_COLOR : W.paraColor}}></span>
            {meta?.l ?? node.type}
          </span>
        ) : (
          <span style={{
            display:'inline-flex', padding:'1px 7px', borderRadius: 9,
            fontSize: 10, fontWeight: 700, letterSpacing:'0.06em',
            color: W.ink2, background: W.panelSunk,
          }}>PAGE</span>
        )}
        <span style={{fontFamily: W.mono, fontSize: 10, color: W.ink3}}>{node.id}</span>
        <span style={{fontSize: 11, color: W.ink2, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', flex:1, minWidth:0}}>
          {node.label}
        </span>
        <div style={{display:'flex', gap: 6, fontSize: 10, color: W.ink3}}>
          {node.children && <span>{node.children.length} child{node.children.length===1?'':'ren'}</span>}
          {node.lines != null && (
            <span style={{
              padding: '1px 6px', borderRadius: 8,
              background: W.exact + '15', color: W.exact,
              fontWeight: 600, fontSize: 9, letterSpacing:'0.04em',
            }}>¶ {node.lines}L · {node.words}W</span>
          )}
        </div>
      </div>
      {node.children?.map((c, i) => (
        <TreeRow key={c.id} node={c} depth={depth+1}
          selectedId={selectedId}
          isLast={i === node.children.length - 1}
          path={[...path, node.id]}/>
      ))}
    </>
  );
}

function PageHierarchyTree() {
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Page hierarchy</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Tree of blocks. A block whose children are <b>lines</b> is a paragraph
          (¶ badge). Otherwise it's a structural container. Click any row to
          select; the right-panel breadcrumb walks up the path.
        </div>
      </header>

      <div style={{
        background: W.panel, border:`1px solid ${W.rule}`, borderRadius: 6,
        padding: 14,
        display:'flex', flexDirection:'column', gap: 2,
        fontFamily: W.ui,
      }}>
        <TreeRow node={PAGE_TREE} depth={0} selectedId="B2.2.2"/>
      </div>

      <div style={{marginTop: 14, display:'flex', gap: 8, alignItems:'center', flexWrap:'wrap'}}>
        <span style={{
          padding:'2px 8px', borderRadius: 9,
          background: BLOCK_COLOR + '18', color: BLOCK_COLOR,
          border: `1px solid ${BLOCK_COLOR}66`,
          fontSize:11, fontWeight:600,
        }}>● structural block (contains other blocks)</span>
        <span style={{
          padding:'2px 8px', borderRadius: 9,
          background: W.paraColor + '20', color: W.paraColor,
          border: `1px solid ${W.paraColor}66`,
          fontSize:11, fontWeight:600,
        }}>● paragraph (contains lines)</span>
        <div style={{flex:1}}></div>
        <span className="wf-btn sm">＋ Auto-detect blocks</span>
        <span className="wf-btn sm">Draw block on canvas…</span>
        <span className="wf-btn sm">Expand all</span>
      </div>
    </div>
  );
}

// =====================================================================
// BLOCK BREADCRUMB — updated, walks the path with overflow handling
// =====================================================================
function BlockBreadcrumb({ path, terminal='word' }) {
  // path is array of {label, sublabel, type, kind} pairs.
  // terminal indicates the active level: 'block' | 'line' | 'word'
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 2,
      padding: '0 10px', borderBottom:`1px solid ${W.rule}`, background: W.panel,
      overflow:'hidden',
    }}>
      <span style={{padding:'8px 10px', fontSize:12, color:W.ink3, fontWeight:600}}>Matches</span>
      <span style={{color:W.ink4, padding:'0 2px'}}>›</span>
      {path.map((node, i) => {
        const isLast = i === path.length - 1;
        const isStruct = node.kind === 'structural';
        const isPara = node.kind === 'paragraph';
        const isLine = node.kind === 'line';
        const isWord = node.kind === 'word';
        const c = isStruct ? BLOCK_COLOR : (isPara ? W.paraColor : (isLine ? W.lineColor : W.wordColor));
        return (
          <React.Fragment key={i}>
            <span style={{
              display:'inline-flex', alignItems:'center', gap: 4,
              padding: '4px 9px', borderRadius: 4,
              background: isLast ? c + '12' : 'transparent',
              border: isLast ? `1px solid ${c}66` : '1px solid transparent',
              fontSize: 11, fontWeight: 600,
              color: isLast ? c : W.ink3,
              whiteSpace:'nowrap',
            }}>
              <span style={{width: 6, height: 6, borderRadius: 1.5, background: c}}></span>
              {node.label}
              {node.sublabel && (
                <span style={{
                  fontSize: 9, fontFamily: W.mono, opacity: 0.7, fontWeight: 500,
                  marginLeft: 2,
                }}>{node.sublabel}</span>
              )}
              {!isLast && node.children > 1 && (
                <span style={{
                  fontSize: 9, color: W.ink3, marginLeft: 2,
                  borderLeft:`1px solid ${W.ink4}`, paddingLeft: 4,
                }}>▾</span>
              )}
            </span>
            {!isLast && <span style={{color:W.ink4, padding:'0 2px'}}>›</span>}
          </React.Fragment>
        );
      })}
      <div style={{flex:1}}></div>
      <span style={{fontSize:10, color:W.ink3, padding:'0 8px', whiteSpace:'nowrap'}}>
        <span className="wf-key">⌥↑</span> jump to parent block
      </span>
    </div>
  );
}

function BreadcrumbDemo() {
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Breadcrumb · nested blocks</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Right-panel header walks the full block path. Structural segments in
          taupe, paragraph in green, line/word in pink/blue. Each segment is a
          dropdown — switch siblings without leaving keyboard focus.
        </div>
      </header>

      <div style={{display:'flex', flexDirection:'column', gap: 14}}>
        {[
          { caption:'Selection: a word inside a block-quote inside a column inside the body',
            path:[
              { label:'Body',        kind:'structural', children:2 },
              { label:'Column',      sublabel:'2 of 2', kind:'structural', children:2 },
              { label:'Block quote', kind:'structural', children:2 },
              { label:'¶',           sublabel:'#2',     kind:'paragraph', children:2 },
              { label:'Line',        sublabel:'3',      kind:'line', children:4 },
              { label:'Word',        sublabel:'2 "ipsum"', kind:'word', children:7 },
            ]
          },
          { caption:'Selection: a paragraph in the footnote band',
            path:[
              { label:'Footnote band', kind:'structural', children:3 },
              { label:'¶ Footnote',    sublabel:'#1',     kind:'paragraph' },
            ]
          },
          { caption:'Selection: a structural block (column) — no line/word context',
            path:[
              { label:'Body',     kind:'structural', children:2 },
              { label:'Column',   sublabel:'1 of 2', kind:'structural' },
            ]
          },
          { caption:'Deep nesting — overflow collapses middle nodes',
            path:[
              { label:'Body',         kind:'structural', children:2 },
              { label:'…',            kind:'structural' },
              { label:'Figure',       kind:'structural', children:1 },
              { label:'¶ Caption',    sublabel:'#1', kind:'paragraph' },
              { label:'Line',         sublabel:'2', kind:'line' },
              { label:'Word',         sublabel:'4 "fig."', kind:'word' },
            ]
          },
        ].map((d, i) => (
          <div key={i} style={{
            background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 6, overflow:'hidden',
          }}>
            <div style={{padding:'6px 12px', fontSize: 10, color: W.ink3, background: W.paperAlt,
              borderBottom:`1px solid ${W.rule}`,
            }}>{d.caption}</div>
            <BlockBreadcrumb path={d.path}/>
            <div style={{padding: 8, fontSize: 10, color: W.ink3, fontFamily: W.mono, background: W.panel}}>
              path: {d.path.map(p => p.label + (p.sublabel?` ${p.sublabel}`:'')).join(' › ')}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// =====================================================================
// BLOCK LAYOUT-TYPE PICKER — single block
// =====================================================================
function BlockLayoutTypePicker() {
  const groups = {};
  BLOCK_TYPES_ALL.forEach(t => { (groups[t.g] ||= []).push(t); });

  return (
    <div className="wf" style={{padding: 0, background: W.panel, display:'flex', flexDirection:'column', overflow:'hidden'}}>
      {/* Breadcrumb showing the selected block in context */}
      <BlockBreadcrumb path={[
        { label:'Body',        kind:'structural', children:2 },
        { label:'Column',      sublabel:'2 of 2', kind:'structural', children:2 },
        { label:'Block quote', kind:'structural', children:2 },
      ]}/>

      <div style={{padding: 16, flex: 1, overflow:'auto', display:'flex', flexDirection:'column', gap: 14}}>
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Block · layout type</span>
          <span style={{
            display:'inline-flex', alignItems:'center', gap: 5,
            padding:'2px 8px', borderRadius: 9, fontSize: 10, fontWeight: 600,
            background: BLOCK_COLOR + '15', color: BLOCK_COLOR, border: `1px solid ${BLOCK_COLOR}66`,
          }}>
            <span style={{width: 6, height: 6, borderRadius: 2, background: BLOCK_COLOR}}></span>
            structural · contains 2 child blocks
          </span>
        </div>

        {/* Block geometry preview */}
        <div style={{
          background: '#fff', border: `1.5px solid ${BLOCK_COLOR}`, borderRadius: 6,
          padding: 14, position:'relative',
          display:'flex', flexDirection:'column', gap: 6,
        }}>
          <span style={{
            position:'absolute', top:-9, left: 10,
            padding: '0 6px', background: '#fff',
            fontSize: 10, fontWeight: 700, color: BLOCK_COLOR, letterSpacing:'0.05em',
          }}>BLOCK B2.2.2</span>
          {/* fake quote content */}
          <div style={{
            fontFamily:'serif', fontSize: 14, fontStyle:'italic', color: W.ink2,
            paddingLeft: 16, borderLeft: `2px solid ${W.ruleSoft}`,
            lineHeight: 1.5,
          }}>
            <div style={{padding:'4px 0', borderBottom:`1px dashed ${W.ruleSoft}`}}>
              "I have no purpose but to serve the present age, my calling to fulfill;
              O may it all my powers engage to do my Master's will."
            </div>
            <div style={{padding:'4px 0'}}>
              — the writer continues for two paragraphs of extended verse, each of
              which is itself a child block of this block-quote.
            </div>
          </div>
        </div>

        {/* model suggestion */}
        <div style={{
          display:'flex', alignItems:'center', gap: 10,
          padding: '10px 12px',
          background: W.fuzzy + '12', borderRadius: 5,
          border: `1px solid ${W.fuzzy}55`,
        }}>
          <span style={{
            display:'inline-flex', alignItems:'center', justifyContent:'center',
            width: 24, height: 24, borderRadius: 12,
            background: W.fuzzy, color:'#fff',
            fontSize: 13, fontWeight: 700,
          }}>?</span>
          <div style={{display:'flex', flexDirection:'column', gap: 2}}>
            <span style={{fontSize: 12, fontWeight: 600, color: W.ink}}>
              Model suggests <span style={{textDecoration: 'underline', textUnderlineOffset: 2}}>block quote</span> · 71% confidence
            </span>
            <span style={{fontSize: 10, color: W.ink2}}>
              Indented region, italic style throughout, no heading detected.
            </span>
          </div>
          <div style={{flex:1}}></div>
          <span className="wf-btn sm primary">Accept ⏎</span>
          <span className="wf-btn sm">Reject</span>
        </div>

        {/* Type picker — grouped */}
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 12, fontWeight: 600}}>Layout type</span>
          <span style={{fontSize: 10, color: W.ink3}}>same enum at every depth · pick whatever fits</span>
          <div style={{flex:1}}></div>
          <input className="wf-input" placeholder="Search types…" style={{width: 160, height:24, fontSize: 11}}/>
        </div>
        {Object.entries(groups).map(([g, items]) => (
          <div key={g}>
            <div style={{
              fontSize: 9, fontWeight: 700, letterSpacing: '0.12em',
              color: W.ink3, marginBottom: 6,
              display:'flex', alignItems:'center', gap: 8,
            }}>
              {g.toUpperCase()}
              <span style={{flex:1, height: 1, background: W.ruleSoft}}></span>
              <span style={{fontWeight: 500, color: W.ink4, letterSpacing: 0}}>
                {g === 'Structural'
                  ? 'typically contains other blocks'
                  : 'typically a leaf (contains lines) — i.e. a paragraph'}
              </span>
            </div>
            <div style={{
              display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(150px, 1fr))', gap: 8,
            }}>
              {items.map(t => (
                <BlockTypeCard key={t.k}
                  label={t.l} kind={t.shape}
                  hint={t.defaultType ? 'default for paragraphs' : null}
                  active={t.k === 'block_quote'}/>
              ))}
            </div>
          </div>
        ))}

        {/* custom */}
        <div style={{
          padding: 10, borderRadius: 6, border: `1px dashed ${W.ink4}`,
          background: W.paperAlt, display:'flex', alignItems:'center', gap: 10,
        }}>
          <span style={{fontSize: 11, fontWeight: 600, color: W.ink2}}>Custom type</span>
          <input className="wf-input" placeholder="e.g. printer's mark, ornament…" style={{flex:1, height:26, fontSize: 11}}/>
          <span className="wf-btn sm">Add to enum</span>
        </div>

        <div style={{marginTop: 'auto', display:'flex', gap: 8, paddingTop: 6}}>
          <span className="wf-btn primary lg" style={{flex:1}}>
            ✓ Save layout type
          </span>
          <span className="wf-btn lg ghost">Skip</span>
        </div>
      </div>
    </div>
  );
}

// =====================================================================
// BULK BLOCK LAYOUT-TYPE PICKER
// =====================================================================
function BulkBlockLayoutTypePicker() {
  const groups = {};
  BLOCK_TYPES_ALL.forEach(t => { (groups[t.g] ||= []).push(t); });
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Bulk · block layout type</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Apply one type to multiple selected blocks. Same enum, regardless of
          block depth. Existing types shown in the summary.
        </div>
      </header>

      {/* selection summary */}
      <div style={{
        display:'flex', alignItems:'center', gap: 12, padding: '10px 14px',
        background: W.panel, border: `1px solid ${W.rule}`,
        borderRadius: 5, marginBottom: 14,
      }}>
        <span style={{
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          width: 26, height: 26, borderRadius: 6,
          background: BLOCK_COLOR + '22', color: BLOCK_COLOR,
          border: `1px solid ${BLOCK_COLOR}66`,
          fontSize: 13, fontWeight: 700,
        }}>6</span>
        <div style={{display:'flex', flexDirection:'column', gap: 1, minWidth: 0}}>
          <span style={{fontSize: 11, color: W.ink3, fontWeight: 600, letterSpacing: '0.05em'}}>SELECTION · blocks across the page</span>
          <span style={{fontSize: 12, color: W.ink, fontFamily: W.mono}}>B2.1.3, B2.1.4, B2.2.1, B2.2.3, B2.2.5, B3.1</span>
        </div>
        <div style={{flex:1}}></div>
        <div style={{display:'flex', gap: 8, fontSize: 11, color: W.ink2}}>
          <span><b style={{color:W.ink}}>5</b> body text</span>
          <span><b style={{color:W.ink}}>1</b> footnote</span>
          <span style={{color:W.ink3}}>2 leaf (paragraphs) · 4 structural</span>
        </div>
        <span className="wf-btn sm ghost">Clear</span>
      </div>

      <div style={{
        background: W.panel, border: `1px solid ${W.rule}`, borderRadius: 6, padding: 14,
        display:'flex', flexDirection:'column', gap: 14,
      }}>
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 12, fontWeight: 700}}>Set layout type for all 6</span>
          <span style={{fontSize: 10, color: W.ink3}}>overwrites existing values</span>
          <div style={{flex:1}}></div>
          <input className="wf-input" placeholder="Search…" style={{width:160, height:24, fontSize:11}}/>
        </div>
        {Object.entries(groups).map(([g, items]) => (
          <div key={g}>
            <div style={{
              fontSize: 9, fontWeight: 700, letterSpacing: '0.12em',
              color: W.ink3, marginBottom: 6,
              display:'flex', alignItems:'center', gap: 8,
            }}>
              {g.toUpperCase()}
              <span style={{flex:1, height: 1, background: W.ruleSoft}}></span>
            </div>
            <div style={{
              display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(140px, 1fr))', gap: 8,
            }}>
              {items.map(t => (
                <BlockTypeCard key={t.k}
                  label={t.l} kind={t.shape}
                  active={t.k === 'body_text'}
                  hint={t.k === 'body_text' ? '5 of 6 already' : null}/>
              ))}
            </div>
          </div>
        ))}
        <div style={{marginTop: 4, display:'flex', gap: 8}}>
          <span className="wf-btn primary" style={{flex: 1}}>Apply to 6 blocks</span>
          <span className="wf-btn ghost">Cancel</span>
        </div>
      </div>
    </div>
  );
}

// =====================================================================
// CANVAS WITH BLOCK OVERLAYS — how blocks render on the page scan
// =====================================================================
function CanvasWithBlockOverlays() {
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Canvas · block overlays</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          Structural blocks in <span style={{color:BLOCK_COLOR, fontWeight:600}}>taupe</span>,
          paragraph blocks in <span style={{color:W.paraColor, fontWeight:600}}>green</span>,
          lines in <span style={{color:W.lineColor, fontWeight:600}}>pink</span>,
          words in <span style={{color:W.wordColor, fontWeight:600}}>blue</span>.
          Nesting shown by stroke thickness (deeper = thinner).
        </div>
      </header>

      {/* legend */}
      <div style={{display:'flex', gap: 8, marginBottom: 14, flexWrap:'wrap', alignItems:'center'}}>
        <span className="wf-h-label">Layers</span>
        {[
          ['Blocks',     BLOCK_COLOR],
          ['Paragraphs', W.paraColor],
          ['Lines',      W.lineColor],
          ['Words',      W.wordColor],
        ].map(([n, c]) => (
          <span key={n} className="wf-chip" style={{
            background: c + '18', borderColor: c + '88', color: c,
            height: 22, padding: '0 8px', fontSize: 11,
          }}>
            <span style={{width: 8, height: 8, borderRadius: 2, background: c}}></span>
            {n}
          </span>
        ))}
        <div style={{flex:1}}></div>
        <span style={{fontSize: 10, color: W.ink3}}>multiply-blend so the scan stays readable underneath</span>
      </div>

      {/* canvas mock */}
      <div style={{
        position:'relative', background:'#fcfaf4',
        border:`1px solid ${W.rule}`, borderRadius: 6,
        height: 720, padding: 18,
      }}>
        {/* faux page texture lines */}
        <div style={{
          position:'absolute', inset: 30,
          backgroundImage: `linear-gradient(${W.ruleSoft} 1px, transparent 1px)`,
          backgroundSize: `100% 16px`,
          opacity: 0.35,
        }}></div>

        {/* HEADER BAND — outermost block */}
        <Overlay area={[5,4,90,5]} color={BLOCK_COLOR} stroke={2.5} label="Header band">
          <Overlay area={[5,4,90,5]} color={W.paraColor} stroke={1.5}/>
        </Overlay>

        {/* BODY — outer */}
        <Overlay area={[5,12,90,68]} color={BLOCK_COLOR} stroke={2.5} label="Body">
          {/* Column 1 */}
          <Overlay area={[1,1,46,98]} color={BLOCK_COLOR} stroke={1.8} label="Column 1" labelInside>
            <Overlay area={[5,3,90,12]} color={W.paraColor} stroke={1.2} label="¶ chap heading"/>
            <Overlay area={[5,18,90,4]}  color={W.paraColor} stroke={1.2} label="¶ byline"/>
            <Overlay area={[5,24,90,38]} color={W.paraColor} stroke={1.2} label="¶ body"/>
            <Overlay area={[5,64,90,32]} color={W.paraColor} stroke={1.2} label="¶ body"/>
          </Overlay>
          {/* Column 2 */}
          <Overlay area={[51,1,46,98]} color={BLOCK_COLOR} stroke={1.8} label="Column 2" labelInside>
            <Overlay area={[5,3,90,30]} color={W.paraColor} stroke={1.2} label="¶ body"/>
            {/* block quote — nested with 2 inner paragraphs */}
            <Overlay area={[10,35,85,18]} color={BLOCK_COLOR} stroke={1.4} dashed label="Block quote">
              <Overlay area={[5,8,90,40]} color={W.paraColor} stroke={1} label="¶ quote pt1"/>
              <Overlay area={[5,52,90,38]} color={W.paraColor} stroke={1} label="¶ quote pt2"/>
            </Overlay>
            <Overlay area={[5,55,90,14]} color={W.paraColor} stroke={1.2} label="¶ body"/>
            {/* figure region — nested */}
            <Overlay area={[5,71,90,12]} color={BLOCK_COLOR} stroke={1.4} dashed label="Figure region">
              <Overlay area={[5,55,90,40]} color={W.paraColor} stroke={1} label="¶ caption"/>
            </Overlay>
            <Overlay area={[5,85,90,12]} color={W.paraColor} stroke={1.2} label="¶ body"/>
          </Overlay>
        </Overlay>

        {/* FOOTNOTE BAND */}
        <Overlay area={[5,82,90,12]} color={BLOCK_COLOR} stroke={2.5} dashed label="Footnote band">
          <Overlay area={[5,15,90,40]} color={W.paraColor} stroke={1.2} label="¶ fn 1"/>
          <Overlay area={[5,60,90,35]} color={W.paraColor} stroke={1.2} label="¶ fn 2"/>
        </Overlay>

        {/* FOOTER BAND */}
        <Overlay area={[40,96,20,3]} color={BLOCK_COLOR} stroke={2.5} label="Footer band">
          <Overlay area={[10,5,80,90]} color={W.paraColor} stroke={1.2}/>
        </Overlay>
      </div>

      <div style={{
        marginTop: 14,
        display:'flex', gap: 14, fontSize: 11, color: W.ink2,
      }}>
        <span><b style={{color:W.ink}}>Stroke weight</b> tracks nesting depth.</span>
        <span><b style={{color:W.ink}}>Dashed</b> = block whose children are themselves blocks (i.e. NOT a paragraph).</span>
        <span><b style={{color:W.ink}}>Solid</b> = leaf paragraph (contains lines).</span>
      </div>
    </div>
  );
}

// Helper: positioned overlay with optional label
function Overlay({ area, color, stroke=1, dashed, label, labelInside, children }) {
  const [left, top, w, h] = area;
  return (
    <div style={{
      position:'absolute',
      left: left + '%', top: top + '%', width: w + '%', height: h + '%',
      border: `${stroke}px ${dashed ? 'dashed' : 'solid'} ${color}`,
      background: color + '0c',
      mixBlendMode: 'multiply',
      borderRadius: 1,
    }}>
      {label && (
        <span style={{
          position:'absolute', top: labelInside ? 2 : -7, left: labelInside ? 4 : 4,
          padding: '1px 6px',
          fontSize: 8.5, fontWeight: 700, letterSpacing:'0.05em',
          color: color, fontFamily: W.mono,
          background: '#fcfaf4',
          border: `0.5px solid ${color}55`,
          borderRadius: 2,
        }}>{label}</span>
      )}
      {/* nested children get a fresh coordinate system */}
      <div style={{position:'absolute', inset:0}}>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  BLOCK_TYPES_ALL, BLOCK_COLOR,
  BlockGlyph, BlockTypeCard,
  PageHierarchyTree, BlockBreadcrumb, BreadcrumbDemo,
  BlockLayoutTypePicker, BulkBlockLayoutTypePicker,
  CanvasWithBlockOverlays,
});

// =====================================================================
// LEVEL-SWITCHING FLOW — how the user jumps between block / line / word
// =====================================================================
//
// Shows the 4 mechanisms simultaneously:
//   • Rail TARGET picker      → scope of drag-select on canvas
//   • Breadcrumb click        → swap right panel to that level
//   • Keyboard ⌥↑/⌥↓          → walk the tree
//   • ⌥-click on canvas       → pick parent

function MiniRail({ activeTarget='Word' }) {
  const targets = [['B', BLOCK_COLOR, 'Block'],['L', W.lineColor, 'Line'],['W', W.wordColor, 'Word']];
  return (
    <div style={{
      width: 60, padding:'10px 6px',
      background: W.paperAlt, borderRight:`1px solid ${W.rule}`,
      display:'flex', flexDirection:'column', alignItems:'center', gap: 8,
    }}>
      <span style={{fontFamily:W.hand, fontSize:14, color:W.ink}}>ol.</span>
      <span className="wf-h-label" style={{fontSize:7}}>TARGET</span>
      <div style={{
        display:'flex', flexDirection:'column', gap: 2, padding: 3,
        background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 5,
      }}>
        {targets.map(([k, c, full]) => {
          const a = full === activeTarget;
          return (
            <div key={k} style={{
              width: 24, height: 24, borderRadius: 3,
              background: a ? '#fff' : 'transparent',
              border: a ? `1.5px solid ${c}` : '1px solid transparent',
              color: a ? c : W.ink3,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize: 12, fontWeight: 700,
              position:'relative',
            }}>
              {k}
              {/* hotkey badge */}
              <span style={{
                position:'absolute', bottom:-2, right:-3,
                fontSize: 7, fontFamily: W.mono, color: W.ink3,
                background: W.paperAlt, padding:'0 2px', borderRadius: 1,
                fontWeight: 500,
              }}>{k==='B'?1:k==='L'?2:3}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FlowFrame({ stepNo, caption, activeTarget, breadcrumbActive, rightPanelKind, highlightSegment }) {
  // breadcrumb path
  const pathParts = [
    { label:'Body',        kind:'structural', children:2 },
    { label:'Column',      sublabel:'2 of 2', kind:'structural', children:2 },
    { label:'Block quote', kind:'structural' },
    { label:'¶',           sublabel:'#2', kind:'paragraph' },
    { label:'Line',        sublabel:'3', kind:'line' },
    { label:'Word',        sublabel:'2 "ipsum"', kind:'word' },
  ];

  return (
    <div style={{
      background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 6,
      overflow:'hidden', display:'flex', flexDirection:'column',
    }}>
      {/* step header */}
      <div style={{
        display:'flex', alignItems:'center', gap:8,
        padding:'8px 12px', background: W.panel,
        borderBottom:`1px solid ${W.rule}`,
      }}>
        <span style={{
          width: 22, height: 22, borderRadius: 11, background: W.accent, color: '#fff',
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 11, fontWeight: 700,
        }}>{stepNo}</span>
        <span style={{fontSize: 12, fontWeight: 600}}>{caption}</span>
      </div>
      <div style={{display:'flex', minHeight: 220}}>
        <MiniRail activeTarget={activeTarget}/>
        {/* right pane */}
        <div style={{flex:1, display:'flex', flexDirection:'column', minWidth: 0}}>
          {/* breadcrumb with hover/click annotation */}
          <div style={{
            display:'flex', alignItems:'center', gap: 2,
            padding: '0 8px', borderBottom:`1px solid ${W.rule}`, background: W.panel,
            position:'relative',
          }}>
            <span style={{padding:'6px 8px', fontSize:11, color:W.ink3, fontWeight:600}}>Matches</span>
            <span style={{color:W.ink4}}>›</span>
            {pathParts.map((p, i) => {
              const isActive = i === breadcrumbActive;
              const isHi = i === highlightSegment;
              const c = p.kind==='structural' ? BLOCK_COLOR :
                p.kind==='paragraph' ? W.paraColor :
                p.kind==='line' ? W.lineColor : W.wordColor;
              return (
                <React.Fragment key={i}>
                  <span style={{
                    display:'inline-flex', alignItems:'center', gap: 3,
                    padding: '3px 7px', borderRadius: 3,
                    background: isActive ? c + '12' : (isHi ? c + '20' : 'transparent'),
                    border: isActive ? `1px solid ${c}66` : (isHi ? `1.5px dashed ${c}` : '1px solid transparent'),
                    fontSize: 10, fontWeight: 600,
                    color: isActive ? c : (isHi ? c : W.ink3),
                    position:'relative',
                  }}>
                    <span style={{width: 5, height: 5, borderRadius: 1.5, background: c}}></span>
                    {p.label}
                    {p.sublabel && <span style={{fontSize: 8, fontFamily: W.mono, opacity:0.7}}>{p.sublabel}</span>}
                    {isHi && (
                      <span style={{
                        position:'absolute', top: -22, left: '50%', transform:'translateX(-50%)',
                        fontSize: 9, color: W.accent, fontWeight: 700, fontFamily: W.mono,
                        background:'#fff', padding:'2px 6px', borderRadius: 3,
                        border:`1px solid ${W.accent}`,
                        whiteSpace:'nowrap',
                      }}>↑ click here</span>
                    )}
                  </span>
                  {i < pathParts.length - 1 && <span style={{color:W.ink4}}>›</span>}
                </React.Fragment>
              );
            })}
          </div>
          {/* right panel content placeholder */}
          <div style={{flex:1, padding: 14, background: W.paperAlt,
            display:'flex', flexDirection:'column', gap: 10, minHeight: 0,
          }}>
            {rightPanelKind === 'word' && (
              <>
                <div style={{display:'flex', alignItems:'center', gap:8}}>
                  <span style={{fontSize: 11, fontWeight: 700, color: W.ink}}>Word editor</span>
                  <StatusPip kind="exact" label="exact"/>
                  <span style={{fontSize: 10, color: W.ink3}}>"ipsum"</span>
                </div>
                <div style={{
                  background:'#fff', border:`1.5px solid ${W.wordColor}`, borderRadius: 5,
                  padding: '12px 0', display:'flex', alignItems:'center', justifyContent:'center',
                  fontFamily:'serif', fontSize: 32, color: W.ink,
                }}>ipsum</div>
                <div style={{display:'grid', gridTemplateColumns:'60px 1fr', gap:'4px 8px', alignItems:'center', fontSize:11}}>
                  <span className="wf-h-label" style={{fontSize:9}}>OCR</span>
                  <div className="wf-mono" style={{padding:'4px 8px', background:W.panelSunk, borderRadius:3, fontSize:11}}>ipsum</div>
                  <span className="wf-h-label" style={{fontSize:9}}>GT</span>
                  <div className="wf-mono" style={{padding:'4px 8px', background:'#fff', border:`1px solid ${W.ink3}`, borderRadius:3, fontSize:11}}>ipsum</div>
                </div>
              </>
            )}
            {rightPanelKind === 'block' && (
              <>
                <div style={{display:'flex', alignItems:'center', gap:8}}>
                  <span style={{fontSize: 11, fontWeight: 700, color: W.ink}}>Block · layout type</span>
                  <span style={{
                    padding:'1px 6px', borderRadius: 8, fontSize: 9, fontWeight: 600,
                    background: BLOCK_COLOR + '15', color: BLOCK_COLOR,
                    border:`1px solid ${BLOCK_COLOR}66`,
                  }}>structural</span>
                </div>
                <div style={{
                  background:'#fff', border:`1.5px solid ${BLOCK_COLOR}`, borderRadius: 5,
                  padding: '10px 14px',
                  fontFamily:'serif', fontSize: 11, fontStyle:'italic', color: W.ink2,
                  paddingLeft: 18, borderLeft: `3px solid ${W.ruleSoft}`,
                  lineHeight: 1.4,
                }}>"I have no purpose but to serve the present age…" — two paragraphs of extended verse.</div>
                <div style={{display:'flex', gap: 4, flexWrap:'wrap'}}>
                  <BlockTypeCardMini label="body text" active={false}/>
                  <BlockTypeCardMini label="block quote" active={true}/>
                  <BlockTypeCardMini label="epigraph" active={false}/>
                  <BlockTypeCardMini label="verse" active={false}/>
                </div>
              </>
            )}
            {rightPanelKind === 'line' && (
              <>
                <div style={{display:'flex', alignItems:'center', gap:8}}>
                  <span style={{fontSize: 11, fontWeight: 700, color: W.ink}}>Line editor</span>
                  <span style={{fontSize: 10, color: W.ink3}}>Line 3 · 7 words</span>
                </div>
                <div style={{
                  background:'#fff', border:`1.5px solid ${W.lineColor}`, borderRadius: 5,
                  padding: '8px 12px', display:'flex', alignItems:'center', gap: 12,
                  fontFamily:'serif', fontSize: 22, color: W.ink, justifyContent:'center',
                }}>
                  <span>my</span><span>calling</span>
                  <span style={{outline:`2px solid ${W.accent}`, padding:'0 2px'}}>ipsum</span>
                  <span>to</span><span>fulfill;</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function BlockTypeCardMini({ label, active }) {
  return (
    <span style={{
      padding:'4px 8px', borderRadius: 4,
      background: active ? W.ink + '08' : '#fff',
      border: active ? `1.5px solid ${W.ink}` : `1px solid ${W.rule}`,
      fontSize: 10, fontWeight: 600, color: active ? W.ink : W.ink2,
      display:'inline-flex', alignItems:'center', gap: 4,
    }}>
      {active && <span style={{
        width: 12, height: 12, borderRadius: 6, background: W.ink, color: '#fff',
        display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize: 8,
      }}>✓</span>}
      {label}
    </span>
  );
}

function LevelSwitchFlow() {
  return (
    <div className="wf" style={{padding: 18, background: W.paperAlt, overflow:'auto'}}>
      <header style={{marginBottom: 14}}>
        <div style={{fontFamily: W.hand, fontSize: 22, marginBottom: 2}}>Switching levels · breadcrumb-click flow</div>
        <div style={{fontSize: 11, color: W.ink3}}>
          A word is selected. User wants to jump up to the surrounding block
          to fix its layout type. Click any breadcrumb segment → right panel
          swaps to that level's editor. Rail TARGET catches up automatically.
        </div>
      </header>

      <div style={{display:'flex', flexDirection:'column', gap: 16}}>
        <FlowFrame stepNo={1}
          caption='Start · Word "ipsum" selected → Word editor on right'
          activeTarget="Word"
          breadcrumbActive={5}
          rightPanelKind="word"/>

        <FlowFrame stepNo={2}
          caption='User clicks the "Block quote" segment in the breadcrumb'
          activeTarget="Word"
          breadcrumbActive={5}
          rightPanelKind="word"
          highlightSegment={2}/>

        <FlowFrame stepNo={3}
          caption='Right panel swaps · TARGET picker jumps to Block · breadcrumb terminal moves'
          activeTarget="Block"
          breadcrumbActive={2}
          rightPanelKind="block"/>
      </div>

      <div style={{
        marginTop: 16, padding: 12,
        background:'#fff', border:`1px solid ${W.rule}`, borderRadius: 6,
        display:'flex', flexDirection:'column', gap: 8, fontSize: 11, color: W.ink2,
      }}>
        <div style={{fontSize: 11, fontWeight: 700, letterSpacing:'0.05em', color: W.ink}}>WHAT CHANGES BETWEEN STEPS</div>
        <div style={{display:'grid', gridTemplateColumns:'auto 1fr', gap:'4px 12px'}}>
          <span style={{fontWeight:600}}>Right panel</span><span>swaps to the picked level's editor (Word → Block)</span>
          <span style={{fontWeight:600}}>Rail TARGET</span><span>catches up so subsequent canvas drag-selects pick blocks too</span>
          <span style={{fontWeight:600}}>Canvas highlight</span><span>changes from word-outline to block-outline + nested-paragraph hints</span>
          <span style={{fontWeight:600}}>Breadcrumb terminal</span><span>moves left; segments to the right go dim but stay clickable to re-enter</span>
        </div>
      </div>
    </div>
  );
}

// =====================================================================
// LEVEL SWITCH CHEATSHEET — anchored callout near the rail
// =====================================================================
function LevelSwitchCheatsheet() {
  const rows = [
    {
      title: 'Rail TARGET picker',
      hot: ['1','2','3'],
      desc: 'Sets the scope of drag-select on the canvas. B = Block, L = Line, W = Word.',
      kind: 'target',
    },
    {
      title: 'Click a breadcrumb segment',
      desc: 'Swaps the right panel to that level. The deepest segment is the current focus.',
      kind: 'breadcrumb',
    },
    {
      title: 'Walk the tree',
      hot: ['⌥↑','⌥↓'],
      desc: '↑ parent · ↓ first child · ⌥← / ⌥→ jump to prev / next sibling at the same level.',
      kind: 'kbd',
    },
    {
      title: 'Click on canvas',
      hot: ['click','⌥click'],
      desc: 'A plain click picks whatever matches TARGET. Hold ⌥ to grab the parent instead.',
      kind: 'canvas',
    },
  ];
  return (
    <div className="wf" style={{padding: 0, background: W.panel, display:'flex', flexDirection:'column', overflow:'hidden'}}>
      {/* mock anchor on the rail */}
      <div style={{display:'flex', flex:1, minHeight:0}}>
        <div style={{
          width: 68, flex:'0 0 68px',
          background: W.paperAlt, borderRight: `1px solid ${W.rule}`,
          display:'flex', flexDirection:'column', alignItems:'center', padding:'10px 0', gap: 4,
        }}>
          <span style={{fontFamily:W.hand, fontSize:17, color:W.ink, marginBottom:4}}>ol.</span>
          <span className="wf-h-label" style={{fontSize:7}}>MODE</span>
          <div style={{width: 52, height: 30, background:'#fff', border:`1px solid ${W.ink3}`, borderRadius: 6,
            display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
          }}>
            <span style={{fontSize:14}}>⬚</span>
            <span style={{fontSize:9, fontWeight:600}}>Select</span>
          </div>
          <span className="wf-h-label" style={{fontSize:7, marginTop: 6}}>TARGET</span>
          <div style={{
            display:'flex', flexDirection:'column', gap: 2, padding: 3,
            background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 5,
            position:'relative',
          }}>
            {[['B', BLOCK_COLOR, true],['L', W.lineColor, false],['W', W.wordColor, false]].map(([k, c, a], i) => (
              <div key={k} style={{
                width: 24, height: 24, borderRadius: 3,
                background: a ? '#fff' : 'transparent',
                border: a ? `1.5px solid ${c}` : '1px solid transparent',
                color: a ? c : W.ink3,
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize: 12, fontWeight: 700,
              }}>{k}</div>
            ))}
            {/* connector arrow */}
            <span style={{
              position:'absolute', right: -12, top: '50%', transform:'translateY(-50%)',
              fontSize: 18, color: W.accent, fontWeight: 700, lineHeight: 1,
            }}>›</span>
          </div>
        </div>

        {/* the callout */}
        <div style={{
          flex: 1, padding: 24, minWidth: 0,
          display:'flex', flexDirection:'column', gap: 14,
          background: '#fff',
        }}>
          <div style={{display:'flex', alignItems:'baseline', gap: 12}}>
            <span style={{fontSize: 16, fontWeight: 700}}>Switching levels</span>
            <span style={{fontSize: 11, color: W.ink3}}>four ways to move between block · line · word</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm ghost">Don't show again</span>
          </div>

          <div style={{
            display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12,
          }}>
            {rows.map((r, i) => (
              <div key={i} style={{
                background: W.paperAlt, border:`1px solid ${W.ruleSoft}`, borderRadius: 6,
                padding: 12, display:'flex', flexDirection:'column', gap: 8,
              }}>
                <div style={{display:'flex', alignItems:'center', gap: 8}}>
                  <span style={{
                    width: 22, height: 22, borderRadius: 4,
                    background: W.accent + '15', color: W.accent,
                    display:'inline-flex', alignItems:'center', justifyContent:'center',
                    fontSize: 11, fontWeight: 700,
                  }}>{i+1}</span>
                  <span style={{fontSize: 12, fontWeight: 700}}>{r.title}</span>
                  <div style={{flex:1}}></div>
                  {r.hot && (
                    <div style={{display:'flex', gap: 3}}>
                      {r.hot.map(h => (
                        <span key={h} className="wf-key" style={{height: 16, fontSize: 9, minWidth: 18}}>{h}</span>
                      ))}
                    </div>
                  )}
                </div>
                <span style={{fontSize: 11, color: W.ink2, lineHeight: 1.4}}>{r.desc}</span>
                {/* visual demo */}
                <div style={{
                  marginTop: 4, padding: 8, background: '#fff',
                  border: `1px dashed ${W.ink4}`, borderRadius: 4,
                  display:'flex', alignItems:'center', justifyContent:'center', gap: 6, minHeight: 38,
                }}>
                  {r.kind === 'target' && (
                    <div style={{display:'flex', gap: 3, padding: 3,
                      background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 4,
                    }}>
                      {[['B', BLOCK_COLOR],['L', W.lineColor],['W', W.wordColor]].map(([k, c], j) => (
                        <span key={k} style={{
                          width: 22, height: 22, borderRadius: 3,
                          background: j===0 ? '#fff' : 'transparent',
                          border: j===0 ? `1.5px solid ${c}` : '1px solid transparent',
                          color: j===0 ? c : W.ink3,
                          display:'flex', alignItems:'center', justifyContent:'center',
                          fontSize: 11, fontWeight: 700,
                        }}>{k}</span>
                      ))}
                    </div>
                  )}
                  {r.kind === 'breadcrumb' && (
                    <div style={{display:'flex', alignItems:'center', gap: 2, fontSize: 9, fontWeight: 600}}>
                      <span style={{padding:'2px 5px', borderRadius: 2, color: BLOCK_COLOR, border:`1px solid ${BLOCK_COLOR}66`}}>Body</span>
                      <span style={{color:W.ink4}}>›</span>
                      <span style={{padding:'2px 5px', borderRadius: 2, color: BLOCK_COLOR, background: BLOCK_COLOR+'12', border:`1.5px dashed ${BLOCK_COLOR}`}}>Block-quote</span>
                      <span style={{color:W.ink4}}>›</span>
                      <span style={{padding:'2px 5px', borderRadius: 2, color: W.paraColor, opacity:0.5}}>¶ #2</span>
                      <span style={{color:W.ink4}}>›</span>
                      <span style={{padding:'2px 5px', borderRadius: 2, color: W.wordColor, opacity:0.5}}>Word</span>
                    </div>
                  )}
                  {r.kind === 'kbd' && (
                    <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap: 4, fontSize: 9, color: W.ink3}}>
                      <div style={{display:'flex', gap:4}}>
                        <span className="wf-key" style={{height:14, fontSize: 9, minWidth: 18}}>⌥↑</span>
                        <span>=</span>
                        <span style={{color:W.ocrOnly, fontWeight: 600}}>parent</span>
                      </div>
                      <div style={{display:'flex', gap:4}}>
                        <span className="wf-key" style={{height:14, fontSize: 9, minWidth: 18}}>⌥↓</span>
                        <span>=</span>
                        <span style={{color:W.exact, fontWeight: 600}}>first child</span>
                      </div>
                    </div>
                  )}
                  {r.kind === 'canvas' && (
                    <div style={{position:'relative', width: 100, height: 36}}>
                      <div style={{
                        position:'absolute', inset: 0,
                        border:`1.5px solid ${BLOCK_COLOR}`, borderRadius: 2,
                        background: BLOCK_COLOR + '0a',
                      }}>
                        <span style={{
                          position:'absolute', top:-7, left: 4, padding:'0 4px',
                          fontSize: 8, fontFamily: W.mono, color: BLOCK_COLOR, background:'#fff',
                          fontWeight: 700,
                        }}>BLOCK</span>
                      </div>
                      <div style={{
                        position:'absolute', left: 42, top: 12, width: 28, height: 12,
                        border:`1.5px solid ${W.wordColor}`, background: W.wordColor + '15',
                        borderRadius: 1,
                      }}></div>
                      <span style={{
                        position:'absolute', right: -6, top: 14, fontSize: 14, color: W.ink,
                      }}>↗</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { LevelSwitchFlow, LevelSwitchCheatsheet });
