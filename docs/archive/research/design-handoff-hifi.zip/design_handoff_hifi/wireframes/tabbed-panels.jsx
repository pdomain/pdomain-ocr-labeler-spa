// Tabbed right-panel editors — round 3.
//
// Model:
//   • WORD level: one panel, the detail word editor (no tabs)
//   • LINE level: two tabs
//       1. "Line"  — line detail editor (image, structure, neighbours, etc.)
//       2. "Words" — checkbox list of all words in the line for bulk actions
//   • BLOCK level: two tabs
//       1. "Layout"  — layout-type picker (current BlockLayoutTypePicker)
//       2. "Items"   — checkbox list of CHILD elements
//          - leaf paragraph block → lines, with a nested "words" toggle
//          - structural block → child blocks
//          Mass actions: validate, OCR→GT, refine, apply style/component…

// =====================================================================
// SHARED — small bits
// =====================================================================

function PanelTabBar({ tabs, active }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 0,
      padding: '0 12px', borderBottom: `1px solid ${W.rule}`,
      background: W.panel,
    }}>
      {tabs.map(t => {
        const on = t.k === active;
        return (
          <div key={t.k} style={{
            padding: '8px 14px',
            display:'inline-flex', alignItems:'center', gap: 6,
            color: on ? W.ink : W.ink3,
            fontWeight: 600, fontSize: 12,
            borderBottom: on ? `2px solid ${W.ink}` : '2px solid transparent',
            marginBottom: -1,
          }}>
            <span style={{opacity: 0.75}}>{t.icon}</span>
            {t.label}
            {t.count != null && (
              <span style={{
                padding: '0 6px', borderRadius: 8, fontSize: 10,
                background: on ? W.ink + '15' : W.panelSunk,
                color: on ? W.ink : W.ink3,
                fontWeight: 600,
              }}>{t.count}</span>
            )}
          </div>
        );
      })}
      <div style={{flex:1}}></div>
      <span style={{fontSize: 10, color: W.ink3, padding: '0 4px'}}>
        <span className="wf-key" style={{height:14, fontSize:9}}>⇥</span> swap tabs
      </span>
    </div>
  );
}

// Bulk-action toolbar above checkbox lists
function BulkBar({ selectedCount, totalCount, extra }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 8,
      padding: '8px 14px',
      background: W.paperAlt, borderBottom: `1px solid ${W.rule}`,
    }}>
      <label style={{display:'inline-flex', alignItems:'center', gap: 6, fontSize:11, color: W.ink2}}>
        <span style={{
          width: 14, height: 14, borderRadius: 3, background:'#fff',
          border: `1.5px solid ${W.ink3}`,
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 10, color: W.ink,
          backgroundImage: selectedCount > 0 && selectedCount < totalCount
            ? `linear-gradient(${W.ink}, ${W.ink})` : 'none',
          backgroundSize: '8px 2px',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center',
        }}>
          {selectedCount === totalCount && totalCount > 0 ? '✓' : ''}
        </span>
        <span style={{fontWeight: 600, color: W.ink}}>{selectedCount}</span>
        <span style={{color: W.ink3}}>of {totalCount} selected</span>
      </label>
      <div style={{flex:1}}></div>
      <span className="wf-btn sm">✓ Validate</span>
      <span className="wf-btn sm">OCR → GT</span>
      <span className="wf-btn sm">Refine</span>
      <span className="wf-btn sm">Apply style…</span>
      <span className="wf-btn sm">Apply component…</span>
      {extra}
      <span className="wf-btn sm danger">🗑</span>
    </div>
  );
}

// =====================================================================
// LINE PANEL · 2 tabs (Line | Words)
// =====================================================================

function LineDetailTab() {
  return (
    <div style={{padding: 16, display:'flex', flexDirection:'column', gap: 14}}>
      {/* line id row */}
      <div style={{display:'flex', alignItems:'center', gap: 10}}>
        <span style={{fontSize: 13, fontWeight: 700}}>Line 4</span>
        <span style={{fontSize: 11, color: W.ink3}}>5 words · in Paragraph 4 / Column 1 / Body</span>
        <div style={{flex:1}}></div>
        <span className="wf-btn sm">◀ Prev line</span>
        <span className="wf-btn sm">Next line ▶</span>
      </div>

      {/* line image strip */}
      <div style={{
        background:'#fff', border:`1.5px solid ${W.lineColor}`, borderRadius: 6,
        padding: '14px 18px',
        display:'flex', alignItems:'center', justifyContent:'center', gap: 20,
        fontFamily:'serif',
      }}>
        <span style={{fontSize: 36}}>WOODROW</span>
        <span style={{fontSize: 36}}>WILSON,</span>
        <span style={{fontSize: 28, fontVariant:'small-caps'}}>Ph.D.,</span>
        <span style={{fontSize: 28, fontVariant:'small-caps'}}>Litt.D.,</span>
        <span style={{fontSize: 36}}>LL.D.</span>
      </div>

      {/* status summary */}
      <div style={{display:'flex', gap: 8, fontSize: 11, alignItems:'center'}}>
        <span className="wf-h-label">Word match</span>
        <span style={{color:W.exact}}>✓ 3 exact</span>
        <span style={{color:W.fuzzy}}>~ 2 fuzzy</span>
        <span style={{color:W.mismatch}}>✗ 0 mismatch</span>
        <div style={{flex:1}}></div>
        <span style={{fontSize: 10, color: W.ink3}}>jump to next unvalidated word with <span className="wf-key" style={{height:14, fontSize:9}}>J</span></span>
      </div>

      {/* Line-level bbox / structure */}
      <div style={{
        background: W.paperAlt, border: `1px solid ${W.ruleSoft}`, borderRadius: 5,
        padding: 12, display:'flex', flexDirection:'column', gap: 10,
      }}>
        <span className="wf-h-label">Bounding box</span>
        <div style={{display:'flex', gap: 6, flexWrap:'wrap'}}>
          <span className="wf-btn sm">Refine all words</span>
          <span className="wf-btn sm">Expand + Refine</span>
          <span className="wf-btn sm">Rebox line…</span>
          <div style={{flex:1}}></div>
          <span style={{fontSize: 10, color: W.ink3, fontFamily: W.mono}}>y:412 · h:54 · 5 words</span>
        </div>
      </div>

      <div style={{
        background: W.paperAlt, border: `1px solid ${W.ruleSoft}`, borderRadius: 5,
        padding: 12, display:'flex', flexDirection:'column', gap: 10,
      }}>
        <span className="wf-h-label">Structure</span>
        <div style={{display:'flex', gap: 6, flexWrap:'wrap'}}>
          <span className="wf-btn sm">⟵ Merge prev line</span>
          <span className="wf-btn sm">Merge next line ⟶</span>
          <span className="wf-btn sm">Split line…</span>
          <span className="wf-btn sm">Promote to own paragraph</span>
          <div style={{flex:1}}></div>
          <span className="wf-btn sm danger">Delete line</span>
        </div>
      </div>

      {/* consolidated GT */}
      <div>
        <span className="wf-h-label">Line ground truth (consolidated)</span>
        <div className="wf-mono" style={{
          padding:'10px 12px', background: W.panelSunk, borderRadius: 4,
          fontSize: 13, marginTop: 6, color: W.ink,
        }}>WOODROW WILSON, Ph.D., Litt.D., LL.D.</div>
      </div>

      {/* commit */}
      <div style={{marginTop:'auto', display:'flex', gap: 8}}>
        <span className="wf-btn primary lg" style={{flex:1}}>✓ Validate all words in line</span>
        <span className="wf-btn lg ghost">Unvalidate</span>
      </div>
    </div>
  );
}

function LineWordsTab() {
  const words = [
    { idx:1, gt:'WOODROW',  ocr:'WOODROW',  status:'exact',    selected:true,  chips:['All Caps'] },
    { idx:2, gt:'WILSON,',  ocr:'WILSON,',  status:'exact',    selected:true,  chips:['All Caps'] },
    { idx:3, gt:'Ph.D.,',   ocr:'PH.D.,',   status:'fuzzy',    selected:true,  chips:['Sm. Caps'] },
    { idx:4, gt:'Litt.D.,', ocr:'LITT.D.,', status:'fuzzy',    selected:false, chips:['Sm. Caps'] },
    { idx:5, gt:'LL.D.',    ocr:'LL.D.',    status:'exact',    selected:false, chips:['All Caps'] },
  ];
  const sel = words.filter(w => w.selected).length;
  return (
    <div style={{display:'flex', flexDirection:'column', flex:1, minHeight: 0}}>
      <BulkBar selectedCount={sel} totalCount={words.length}/>
      <div style={{flex:1, padding: 10, background: W.paperAlt, overflow:'auto'}}>
        <div style={{display:'flex', flexDirection:'column', gap: 4}}>
          {words.map(w => (
            <div key={w.idx} style={{
              display:'flex', alignItems:'center', gap: 10,
              padding: '8px 10px', borderRadius: 5,
              background: w.selected ? W.accent + '0c' : '#fff',
              border: w.selected ? `1.5px solid ${W.accent}66` : `1px solid ${W.ruleSoft}`,
            }}>
              <span style={{
                width: 14, height: 14, borderRadius: 3,
                background: w.selected ? W.ink : '#fff',
                border: `1.5px solid ${w.selected ? W.ink : W.ink3}`,
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                fontSize: 10, color: '#fff', fontWeight: 700,
              }}>{w.selected ? '✓' : ''}</span>
              <span style={{fontSize: 10, color: W.ink3, fontWeight: 600, fontFamily: W.mono, minWidth: 26}}>#{w.idx}</span>
              {/* word image / glyph */}
              <span style={{
                fontFamily:'serif', fontSize: 18, color: W.ink, minWidth: 100,
                fontVariant: w.chips.includes('Sm. Caps') ? 'small-caps' : 'normal',
              }}>{w.gt}</span>
              {/* OCR → GT */}
              <span className="wf-mono" style={{
                fontSize: 11, color: W.ink3,
                padding: '2px 6px', background: W.panelSunk, borderRadius: 2,
              }}>{w.ocr}</span>
              <span style={{color: W.ink4, fontSize: 10}}>→</span>
              <span className="wf-mono" style={{
                fontSize: 11, color: W.ink,
                padding: '2px 6px', background: '#fff', border:`1px solid ${W.ink4}`, borderRadius: 2,
              }}>{w.gt}</span>
              <StatusPip kind={w.status}/>
              <div style={{display:'flex', gap: 3}}>
                {w.chips.map(c => (
                  <span key={c} className="wf-chip" style={{fontSize:9, height: 16, padding:'0 6px'}}>{c}</span>
                ))}
              </div>
              <div style={{flex:1}}></div>
              <span className="wf-btn sm ghost" style={{height: 22, fontSize: 10, padding:'0 8px'}}>Open ▸</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TabbedLinePanel() {
  return (
    <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
      {/* breadcrumb */}
      <BlockBreadcrumb path={[
        { label:'Body',    kind:'structural', children:2 },
        { label:'Column',  sublabel:'1 of 2', kind:'structural', children:4 },
        { label:'¶',       sublabel:'#4', kind:'paragraph', children:5 },
        { label:'Line',    sublabel:'4', kind:'line', children:5 },
      ]}/>
      <PanelTabBar
        tabs={[
          { k:'detail', label:'Line',  icon:'▦', count:null },
          { k:'words',  label:'Words', icon:'☷', count:5 },
        ]}
        active="detail"/>
      <LineDetailTab/>
    </div>
  );
}

function TabbedLinePanelWords() {
  return (
    <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
      <BlockBreadcrumb path={[
        { label:'Body',    kind:'structural', children:2 },
        { label:'Column',  sublabel:'1 of 2', kind:'structural', children:4 },
        { label:'¶',       sublabel:'#4', kind:'paragraph', children:5 },
        { label:'Line',    sublabel:'4', kind:'line', children:5 },
      ]}/>
      <PanelTabBar
        tabs={[
          { k:'detail', label:'Line',  icon:'▦' },
          { k:'words',  label:'Words', icon:'☷', count:5 },
        ]}
        active="words"/>
      <LineWordsTab/>
    </div>
  );
}

// =====================================================================
// BLOCK PANEL · 2 tabs (Layout | Items)
// =====================================================================

function BlockLayoutTab({ structural }) {
  // mini version of BlockLayoutTypePicker without the breadcrumb (panel owns it)
  const groups = {};
  BLOCK_TYPES_ALL.forEach(t => { (groups[t.g] ||= []).push(t); });
  return (
    <div style={{padding: 14, display:'flex', flexDirection:'column', gap: 12, flex:1, minHeight:0, overflow:'auto'}}>
      <div style={{display:'flex', alignItems:'center', gap: 10}}>
        <span style={{fontSize: 13, fontWeight: 700}}>{structural ? 'Block quote' : 'Paragraph 4'} · layout type</span>
        <span style={{
          padding:'2px 8px', borderRadius: 9, fontSize: 10, fontWeight: 600,
          background: structural ? BLOCK_COLOR+'15' : W.paraColor+'18',
          color: structural ? BLOCK_COLOR : W.paraColor,
          border: `1px solid ${structural ? BLOCK_COLOR+'66' : W.paraColor+'66'}`,
        }}>{structural ? 'structural · 2 children' : '¶ leaf · 5 lines'}</span>
        <div style={{flex:1}}></div>
        <input className="wf-input" placeholder="Search…" style={{width:140, height: 24, fontSize:11}}/>
      </div>

      {/* preview */}
      <div style={{
        background:'#fff',
        border:`1.5px solid ${structural ? BLOCK_COLOR : W.paraColor}`, borderRadius: 6,
        padding: 14, position:'relative',
        fontFamily:'serif', fontSize: 14, color: W.ink2, lineHeight: 1.5,
      }}>
        <span style={{
          position:'absolute', top:-9, left:10, padding:'0 6px', background:'#fff',
          fontSize: 9, fontWeight: 700, letterSpacing:'0.05em',
          color: structural ? BLOCK_COLOR : W.paraColor,
        }}>{structural ? 'BLOCK · structural' : 'BLOCK · paragraph (leaf)'}</span>
        {structural
          ? <span style={{fontStyle:'italic', paddingLeft: 16, borderLeft: `2px solid ${W.ruleSoft}`}}>"I have no purpose but to serve the present age…" — two paragraphs of extended verse.</span>
          : <span>WOODROW WILSON, <span style={{fontVariant:'small-caps'}}>Ph.D., Litt.D.,</span> LL.D. <span style={{color:W.ink3}}>+ 4 more lines of body text.</span></span>
        }
      </div>

      {/* model suggestion */}
      <div style={{
        display:'flex', alignItems:'center', gap: 10,
        padding: '8px 10px', background: W.fuzzy+'12',
        border: `1px solid ${W.fuzzy}55`, borderRadius: 5,
      }}>
        <span style={{
          width: 22, height: 22, borderRadius: 11, background: W.fuzzy, color:'#fff',
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontSize: 12, fontWeight: 700,
        }}>?</span>
        <span style={{fontSize: 11, color: W.ink2}}>
          Model suggests <b style={{color: W.ink}}>{structural ? 'block quote' : 'body text'}</b> · {structural ? '71%' : '92%'} conf
        </span>
        <div style={{flex:1}}></div>
        <span className="wf-btn sm primary">Accept ⏎</span>
        <span className="wf-btn sm">Reject</span>
      </div>

      {/* condensed type grid — primary tier */}
      {Object.entries(groups).map(([g, items]) => (
        <div key={g}>
          <div style={{
            fontSize: 9, fontWeight: 700, letterSpacing:'0.12em', color: W.ink3,
            marginBottom: 6, display:'flex', alignItems:'center', gap: 8,
          }}>
            {g.toUpperCase()}
            <span style={{flex:1, height:1, background: W.ruleSoft}}></span>
          </div>
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(130px, 1fr))', gap: 6}}>
            {items.filter(t => t.tier <= 2).map(t => (
              <BlockTypeCard key={t.k} label={t.l} kind={t.shape}
                active={structural ? t.k === 'block_quote' : t.k === 'body_text'}/>
            ))}
          </div>
        </div>
      ))}

      <div style={{marginTop:'auto', display:'flex', gap: 8, paddingTop: 6}}>
        <span className="wf-btn primary lg" style={{flex:1}}>✓ Save layout type</span>
        <span className="wf-btn lg ghost">Skip</span>
      </div>
    </div>
  );
}

function BlockItemsTab({ structural }) {
  if (structural) {
    // children are blocks
    const children = [
      { id:'B2.2.2.1', type:'body_text', label:'¶ #1 · "I have no purpose…"', lines:4, words:22, selected:true,  status:'review' },
      { id:'B2.2.2.2', type:'body_text', label:'¶ #2 · "the writer continues…"', lines:3, words:18, selected:true,  status:'review' },
    ];
    return (
      <div style={{display:'flex', flexDirection:'column', flex:1, minHeight: 0}}>
        <BulkBar selectedCount={children.length} totalCount={children.length}
          extra={
            <>
              <span className="wf-btn sm">Apply type to all…</span>
              <span style={{width:1, height:18, background:W.rule}}></span>
            </>
          }/>
        <div style={{flex:1, padding: 10, background: W.paperAlt, overflow:'auto'}}>
          <div style={{display:'flex', flexDirection:'column', gap: 4}}>
            {children.map(c => (
              <div key={c.id} style={{
                display:'flex', alignItems:'center', gap: 10,
                padding: '8px 12px', borderRadius: 5,
                background: c.selected ? W.accent + '0c' : '#fff',
                border: c.selected ? `1.5px solid ${W.accent}66` : `1px solid ${W.ruleSoft}`,
              }}>
                <span style={{
                  width: 14, height: 14, borderRadius: 3,
                  background: c.selected ? W.ink : '#fff',
                  border: `1.5px solid ${c.selected ? W.ink : W.ink3}`,
                  display:'inline-flex', alignItems:'center', justifyContent:'center',
                  fontSize: 10, color: '#fff',
                }}>{c.selected ? '✓' : ''}</span>
                <span style={{fontFamily: W.mono, fontSize: 10, color: W.ink3}}>{c.id}</span>
                <span style={{
                  padding:'1px 7px', borderRadius: 8, fontSize: 10, fontWeight: 600,
                  background: W.paraColor+'18', color: W.paraColor, border: `1px solid ${W.paraColor}66`,
                }}>¶ body text</span>
                <span style={{fontSize: 12, color: W.ink}}>{c.label}</span>
                <span style={{fontSize: 10, color: W.ink3, fontFamily: W.mono}}>{c.lines}L · {c.words}W</span>
                <div style={{flex:1}}></div>
                <span className="wf-btn sm ghost" style={{height:22, fontSize:10, padding:'0 8px'}}>Open ▸</span>
              </div>
            ))}
          </div>
          <div style={{
            marginTop: 8, fontSize: 10, color: W.ink3, fontStyle:'italic', textAlign:'center',
          }}>
            structural block — child rows are blocks. Drill in to act on lines / words.
          </div>
        </div>
      </div>
    );
  }
  // leaf paragraph: children are LINES, with a toggle to flatten to WORDS
  const lines = [
    { idx:1, preview:'A HISTORY OF', words:3, exact:3, fuzzy:0, miss:0, selected:false },
    { idx:2, preview:'THE AMERICAN PEOPLE', words:3, exact:3, fuzzy:0, miss:0, selected:false },
    { idx:3, preview:'BY', words:1, exact:1, fuzzy:0, miss:0, selected:false },
    { idx:4, preview:'WOODROW WILSON, Ph.D., Litt.D., LL.D.', words:5, exact:3, fuzzy:2, miss:0, selected:true },
    { idx:5, preview:'IN FIVE VOLUMES', words:3, exact:3, fuzzy:0, miss:0, selected:false },
  ];
  return (
    <div style={{display:'flex', flexDirection:'column', flex:1, minHeight: 0}}>
      <BulkBar selectedCount={1} totalCount={5}
        extra={
          <>
            <div style={{display:'flex', alignItems:'center', gap: 4, fontSize:10, color: W.ink3}}>
              <span>View</span>
              <div style={{display:'flex', background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 4, padding:1}}>
                <span style={{padding:'2px 8px', borderRadius: 3, background:'#fff', fontSize:10, fontWeight:600, color: W.ink}}>Lines</span>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Words</span>
              </div>
            </div>
            <span style={{width:1, height:18, background:W.rule}}></span>
          </>
        }/>
      <div style={{flex:1, padding: 10, background: W.paperAlt, overflow:'auto'}}>
        <div style={{display:'flex', flexDirection:'column', gap: 4}}>
          {lines.map(l => (
            <div key={l.idx} style={{
              display:'flex', alignItems:'center', gap: 10,
              padding: '8px 12px', borderRadius: 5,
              background: l.selected ? W.accent + '0c' : '#fff',
              border: l.selected ? `1.5px solid ${W.accent}66` : `1px solid ${W.ruleSoft}`,
            }}>
              <span style={{
                width: 14, height: 14, borderRadius: 3,
                background: l.selected ? W.ink : '#fff',
                border: `1.5px solid ${l.selected ? W.ink : W.ink3}`,
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                fontSize: 10, color: '#fff',
              }}>{l.selected ? '✓' : ''}</span>
              <span style={{fontFamily: W.mono, fontSize: 10, color: W.ink3, minWidth: 30}}>L{l.idx}</span>
              <span style={{
                padding:'1px 7px', borderRadius: 8, fontSize: 10, fontWeight: 600,
                background: W.lineColor+'18', color: W.lineColor, border:`1px solid ${W.lineColor}66`,
              }}>line</span>
              <span style={{fontFamily:'serif', fontSize: 14, color: W.ink, flex:1, minWidth: 0,
                whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
              }}>{l.preview}</span>
              <span style={{display:'flex', gap: 6, fontSize: 10}}>
                <span style={{color:W.exact}}>✓{l.exact}</span>
                {l.fuzzy > 0 && <span style={{color:W.fuzzy}}>~{l.fuzzy}</span>}
                {l.miss > 0 && <span style={{color:W.mismatch}}>✗{l.miss}</span>}
              </span>
              <span style={{fontSize: 10, color: W.ink3, fontFamily: W.mono}}>{l.words}W</span>
              <span className="wf-btn sm ghost" style={{height:22, fontSize:10, padding:'0 8px'}}>Open ▸</span>
            </div>
          ))}
        </div>
        <div style={{
          marginTop: 8, fontSize: 10, color: W.ink3, fontStyle:'italic', textAlign:'center',
        }}>
          leaf paragraph — child rows are lines. Switch view to "Words" to checkbox individual words across this whole paragraph.
        </div>
      </div>
    </div>
  );
}

function TabbedBlockPanel({ structural = true, activeTab = 'layout' }) {
  const path = structural ? [
    { label:'Body',         kind:'structural', children:2 },
    { label:'Column',       sublabel:'2 of 2', kind:'structural', children:5 },
    { label:'Block quote',  kind:'structural', children:2 },
  ] : [
    { label:'Body',         kind:'structural', children:2 },
    { label:'Column',       sublabel:'1 of 2', kind:'structural', children:4 },
    { label:'¶',            sublabel:'#4 · body', kind:'paragraph', children:5 },
  ];
  return (
    <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
      <BlockBreadcrumb path={path}/>
      <PanelTabBar
        tabs={[
          { k:'layout', label:'Layout', icon:'⊞', count:null },
          { k:'items',  label:'Items',  icon:'☷',
            count: structural ? 2 : 5 },
        ]}
        active={activeTab}/>
      {activeTab === 'layout'
        ? <BlockLayoutTab structural={structural}/>
        : <BlockItemsTab structural={structural}/>}
    </div>
  );
}

// =====================================================================
// SHARED — word card with checkbox (the "grouped cards" pattern)
// =====================================================================
function WordCardCheckable({ word, selected }) {
  const focused = selected;
  return (
    <div style={{
      width: 140, flex:'0 0 auto',
      display:'flex', flexDirection:'column', gap: 4,
      padding: 6, borderRadius: 4,
      border: focused ? `1.5px solid ${W.accent}` : `1px solid ${W.ruleSoft}`,
      background: focused ? '#fff' : W.panel,
      position:'relative',
    }}>
      <div style={{display:'flex', alignItems:'center', gap:6, justifyContent:'space-between'}}>
        <div style={{display:'flex', alignItems:'center', gap:4}}>
          <span style={{
            width: 14, height: 14, borderRadius: 3,
            background: selected ? W.ink : '#fff',
            border: `1.5px solid ${selected ? W.ink : W.ink3}`,
            display:'inline-flex', alignItems:'center', justifyContent:'center',
            fontSize: 10, color: '#fff',
          }}>{selected ? '✓' : ''}</span>
          <span style={{fontSize: 9, color: W.ink3, fontFamily: W.mono}}>L{word.l}·W{word.idx}</span>
        </div>
        <StatusPip kind={word.status} label={({exact:'✓', fuzzy:'~', mismatch:'✗'})[word.status]}/>
      </div>
      <div style={{
        height: 38,
        background: `repeating-linear-gradient(90deg, ${W.panelSunk} 0 4px, ${W.paper} 4px 8px)`,
        border: `1px dashed ${W.ink4}`, borderRadius: 3,
        display:'flex', alignItems:'center', justifyContent:'center',
        fontFamily: 'serif',
        fontSize: word.sc ? 14 : 16,
        fontVariant: word.sc ? 'small-caps' : 'normal',
        color: W.ink,
      }}>{word.img}</div>
      <div className="wf-mono" style={{
        fontSize: 11, color: W.ink3,
        padding: '2px 5px', background: W.panelSunk, borderRadius: 2,
        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
      }}>{word.ocr}</div>
      <div style={{
        fontFamily: W.mono, fontSize: 11, color: W.ink,
        padding: '3px 5px', background: '#fff',
        border:`1px solid ${focused ? W.accent : W.ink3}`,
        borderRadius: 2,
        whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
      }}>{word.gt}</div>
      {word.chips && word.chips.length > 0 && (
        <div style={{display:'flex', flexWrap:'wrap', gap: 3}}>
          {word.chips.map((c, i) => (
            <span key={i} className="wf-chip" style={{fontSize:9, height:15, padding:'0 5px'}}>{c}</span>
          ))}
        </div>
      )}
    </div>
  );
}

function LineGroupHeader({ line, exact, fuzzy, miss, selectedCount, totalCount, paraLabel }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 10,
      padding: '6px 10px',
      background: W.paperAlt, border: `1px solid ${W.rule}`,
      borderRadius: '5px 5px 0 0', borderBottom: 'none',
    }}>
      {/* group-level checkbox tristate */}
      <span style={{
        width: 14, height: 14, borderRadius: 3,
        background: selectedCount === totalCount ? W.ink : '#fff',
        border: `1.5px solid ${selectedCount > 0 ? W.ink : W.ink3}`,
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontSize: 10, color: '#fff',
      }}>
        {selectedCount === totalCount ? '✓' : (selectedCount > 0 ? '−' : '')}
      </span>
      <span style={{
        padding:'1px 7px', borderRadius: 8, fontSize: 10, fontWeight: 600,
        background: W.lineColor+'18', color: W.lineColor, border:`1px solid ${W.lineColor}66`,
      }}>line {line}</span>
      {paraLabel && (
        <span style={{fontSize: 10, color: W.ink3}}>{paraLabel}</span>
      )}
      <span style={{fontSize: 10, color: W.ink3}}>{totalCount} words</span>
      <span style={{display:'flex', gap: 6, fontSize: 10}}>
        <span style={{color:W.exact}}>✓{exact}</span>
        {fuzzy > 0 && <span style={{color:W.fuzzy}}>~{fuzzy}</span>}
        {miss > 0 && <span style={{color:W.mismatch}}>✗{miss}</span>}
      </span>
      <div style={{flex:1}}></div>
      <span style={{fontSize:10, color:W.ink3}}>{selectedCount} selected</span>
      <span className="wf-btn sm ghost" style={{height: 20, fontSize: 9, padding:'0 6px'}}>Select line</span>
    </div>
  );
}

function WordCardGroup({ line, paraLabel, words, exact, fuzzy, miss }) {
  const sel = words.filter(w => w.selected).length;
  return (
    <div style={{
      background: '#fff',
      border:`1px solid ${W.rule}`,
      borderTopWidth: 0,
      borderRadius: '0 0 5px 5px',
      marginBottom: 10,
    }}>
      <LineGroupHeader line={line} paraLabel={paraLabel}
        exact={exact} fuzzy={fuzzy} miss={miss}
        selectedCount={sel} totalCount={words.length}/>
      <div style={{
        display:'flex', gap: 8, padding: 10, overflowX:'auto',
        background: W.paper,
      }}>
        {words.map((w, i) => <WordCardCheckable key={i} word={w} selected={w.selected}/>)}
      </div>
    </div>
  );
}

// =====================================================================
// Restored: word cards grouped by line — used in line/paragraph "Words" view
// =====================================================================

function LineWordsTabCards() {
  const words = [
    { l:4, idx:1, img:'WOODROW',  ocr:'WOODROW',  gt:'WOODROW',  status:'exact',    selected:true,  chips:['All Caps'] },
    { l:4, idx:2, img:'WILSON,',  ocr:'WILSON,',  gt:'WILSON,',  status:'exact',    selected:true,  chips:['All Caps'] },
    { l:4, idx:3, img:'Ph.D.,',   ocr:'PH.D.,',   gt:'Ph.D.,',   status:'fuzzy',    selected:true,  chips:['Sm. Caps'], sc:true },
    { l:4, idx:4, img:'Litt.D.,', ocr:'LITT.D.,', gt:'Litt.D.,', status:'fuzzy',    selected:false, chips:['Sm. Caps'], sc:true },
    { l:4, idx:5, img:'LL.D.',    ocr:'LL.D.',    gt:'LL.D.',    status:'exact',    selected:false, chips:['All Caps'] },
  ];
  const sel = words.filter(w => w.selected).length;
  return (
    <div style={{display:'flex', flexDirection:'column', flex: 1, minHeight: 0}}>
      <BulkBar selectedCount={sel} totalCount={words.length}/>
      <div style={{flex: 1, padding: 12, background: W.paperAlt, overflow:'auto'}}>
        <WordCardGroup line={4} words={words} exact={3} fuzzy={2} miss={0}/>
      </div>
    </div>
  );
}

function ParagraphWordsTabCards() {
  // 5 lines × 1-5 words = 15 words across the whole leaf paragraph
  const lines = [
    { line:1, paraLabel:'¶ #4 / Column 1', exact:3, fuzzy:0, miss:0, words:[
      { l:1, idx:1, img:'A',        ocr:'A',        gt:'A',        status:'exact', selected:false, chips:['All Caps'] },
      { l:1, idx:2, img:'HISTORY',  ocr:'HISTORY',  gt:'HISTORY',  status:'exact', selected:false, chips:['All Caps'] },
      { l:1, idx:3, img:'OF',       ocr:'OF',       gt:'OF',       status:'exact', selected:false, chips:['All Caps'] },
    ]},
    { line:2, paraLabel:null, exact:3, fuzzy:0, miss:0, words:[
      { l:2, idx:1, img:'THE',      ocr:'THE',      gt:'THE',      status:'exact', selected:false, chips:['All Caps'] },
      { l:2, idx:2, img:'AMERICAN', ocr:'AMERICAN', gt:'AMERICAN', status:'exact', selected:false, chips:['All Caps'] },
      { l:2, idx:3, img:'PEOPLE',   ocr:'PEOPLE',   gt:'PEOPLE',   status:'exact', selected:false, chips:['All Caps'] },
    ]},
    { line:3, paraLabel:null, exact:1, fuzzy:0, miss:0, words:[
      { l:3, idx:1, img:'BY',       ocr:'BY',       gt:'BY',       status:'exact', selected:false, chips:['All Caps'] },
    ]},
    { line:4, paraLabel:null, exact:3, fuzzy:2, miss:0, words:[
      { l:4, idx:1, img:'WOODROW',  ocr:'WOODROW',  gt:'WOODROW',  status:'exact', selected:false, chips:['All Caps'] },
      { l:4, idx:2, img:'WILSON,',  ocr:'WILSON,',  gt:'WILSON,',  status:'exact', selected:false, chips:['All Caps'] },
      { l:4, idx:3, img:'Ph.D.,',   ocr:'PH.D.,',   gt:'Ph.D.,',   status:'fuzzy', selected:true,  chips:['Sm. Caps'], sc:true },
      { l:4, idx:4, img:'Litt.D.,', ocr:'LITT.D.,', gt:'Litt.D.,', status:'fuzzy', selected:true,  chips:['Sm. Caps'], sc:true },
      { l:4, idx:5, img:'LL.D.',    ocr:'LL.D.',    gt:'LL.D.',    status:'exact', selected:false, chips:['All Caps'] },
    ]},
    { line:5, paraLabel:null, exact:3, fuzzy:0, miss:0, words:[
      { l:5, idx:1, img:'IN',       ocr:'IN',       gt:'IN',       status:'exact', selected:false, chips:['All Caps'] },
      { l:5, idx:2, img:'FIVE',     ocr:'FIVE',     gt:'FIVE',     status:'exact', selected:false, chips:['All Caps'] },
      { l:5, idx:3, img:'VOLUMES',  ocr:'VOLUMES',  gt:'VOLUMES',  status:'exact', selected:false, chips:['All Caps'] },
    ]},
  ];
  const totalWords = lines.reduce((n, ln) => n + ln.words.length, 0);
  const totalSel   = lines.reduce((n, ln) => n + ln.words.filter(w => w.selected).length, 0);
  return (
    <div style={{display:'flex', flexDirection:'column', flex: 1, minHeight: 0}}>
      <BulkBar selectedCount={totalSel} totalCount={totalWords}
        extra={
          <>
            <div style={{display:'flex', alignItems:'center', gap: 4, fontSize:10, color: W.ink3}}>
              <span>View</span>
              <div style={{display:'flex', background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 4, padding:1}}>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Lines</span>
                <span style={{padding:'2px 8px', borderRadius: 3, background:'#fff', fontSize:10, fontWeight:600, color: W.ink}}>Words</span>
              </div>
            </div>
            <span style={{width:1, height:18, background:W.rule}}></span>
            <div style={{display:'flex', alignItems:'center', gap: 4, fontSize:10, color: W.ink3}}>
              <span>Filter</span>
              <span className="wf-chip" style={{height: 18, padding:'0 6px', fontSize: 10,
                background: W.fuzzy+'20', color: W.fuzzy, borderColor: W.fuzzy+'88',
              }}>~ 2</span>
              <span className="wf-chip" style={{height: 18, padding:'0 6px', fontSize: 10}}>All</span>
            </div>
            <span style={{width:1, height:18, background:W.rule}}></span>
          </>
        }/>
      <div style={{flex: 1, padding: 12, background: W.paperAlt, overflow:'auto'}}>
        {lines.map((ln, i) => (
          <WordCardGroup key={i}
            line={ln.line} paraLabel={i === 0 ? ln.paraLabel : null}
            words={ln.words}
            exact={ln.exact} fuzzy={ln.fuzzy} miss={ln.miss}/>
        ))}
      </div>
    </div>
  );
}

// =====================================================================
// Replace the simple list versions with the card grids
// =====================================================================
function TabbedLinePanelWordsCards() {
  return (
    <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
      <BlockBreadcrumb path={[
        { label:'Body',    kind:'structural', children:2 },
        { label:'Column',  sublabel:'1 of 2', kind:'structural', children:4 },
        { label:'¶',       sublabel:'#4', kind:'paragraph', children:5 },
        { label:'Line',    sublabel:'4', kind:'line', children:5 },
      ]}/>
      <PanelTabBar
        tabs={[
          { k:'detail', label:'Line',  icon:'▦' },
          { k:'words',  label:'Words', icon:'☷', count:5 },
        ]}
        active="words"/>
      <LineWordsTabCards/>
    </div>
  );
}

function TabbedParaPanelItemsCards() {
  return (
    <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
      <BlockBreadcrumb path={[
        { label:'Body',    kind:'structural', children:2 },
        { label:'Column',  sublabel:'1 of 2', kind:'structural', children:4 },
        { label:'¶',       sublabel:'#4 · body', kind:'paragraph', children:5 },
      ]}/>
      <PanelTabBar
        tabs={[
          { k:'layout', label:'Layout', icon:'⊞' },
          { k:'items',  label:'Items',  icon:'☷', count: 5 },
        ]}
        active="items"/>
      <ParagraphWordsTabCards/>
    </div>
  );
}

// =====================================================================
// UNIFIED · density-toggled word bulk view (works at ANY block level)
// =====================================================================

// Row-density variant of a word — single line, sparse
function WordRowCheckable({ word, selected }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 10,
      padding: '6px 10px', borderRadius: 4,
      background: selected ? W.accent + '0c' : '#fff',
      border: selected ? `1.5px solid ${W.accent}66` : `1px solid ${W.ruleSoft}`,
    }}>
      <span style={{
        width: 14, height: 14, borderRadius: 3,
        background: selected ? W.ink : '#fff',
        border: `1.5px solid ${selected ? W.ink : W.ink3}`,
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontSize: 10, color: '#fff',
      }}>{selected ? '✓' : ''}</span>
      <span style={{fontSize: 9, color: W.ink3, fontFamily: W.mono, minWidth: 40}}>L{word.l}·W{word.idx}</span>
      <span style={{
        fontFamily:'serif', fontSize: 14, color: W.ink, minWidth: 100,
        fontVariant: word.sc ? 'small-caps' : 'normal',
      }}>{word.img}</span>
      <span className="wf-mono" style={{
        fontSize: 11, color: W.ink3,
        padding: '2px 5px', background: W.panelSunk, borderRadius: 2,
        minWidth: 90,
      }}>{word.ocr}</span>
      <span style={{color: W.ink4, fontSize: 10}}>→</span>
      <span className="wf-mono" style={{
        fontSize: 11, color: W.ink,
        padding: '2px 5px', background: '#fff', border:`1px solid ${W.ink4}`, borderRadius: 2,
        minWidth: 90,
      }}>{word.gt}</span>
      <StatusPip kind={word.status} label={({exact:'✓', fuzzy:'~', mismatch:'✗'})[word.status]}/>
      <div style={{display:'flex', gap: 3}}>
        {(word.chips||[]).map(c => (
          <span key={c} className="wf-chip" style={{fontSize:9, height: 15, padding:'0 5px'}}>{c}</span>
        ))}
      </div>
      <div style={{flex:1}}></div>
      <span className="wf-btn sm ghost" style={{height: 20, fontSize:10, padding:'0 7px'}}>Open ▸</span>
    </div>
  );
}

// Group wrapper for the row variant
function WordRowGroup({ line, paraLabel, words, exact, fuzzy, miss }) {
  const sel = words.filter(w => w.selected).length;
  return (
    <div style={{marginBottom: 10}}>
      <LineGroupHeader line={line} paraLabel={paraLabel}
        exact={exact} fuzzy={fuzzy} miss={miss}
        selectedCount={sel} totalCount={words.length}/>
      <div style={{
        padding: 6, background: '#fff',
        border:`1px solid ${W.rule}`, borderTopWidth: 0,
        borderRadius: '0 0 5px 5px',
        display:'flex', flexDirection:'column', gap: 3,
      }}>
        {words.map((w, i) => <WordRowCheckable key={i} word={w} selected={w.selected}/>)}
      </div>
    </div>
  );
}

// Density toggle slot for BulkBar.extra
function DensityToggle({ density='cards' }) {
  return (
    <div style={{display:'flex', alignItems:'center', gap: 4, fontSize:10, color: W.ink3}}>
      <span>Density</span>
      <div style={{display:'flex', background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 4, padding:1}}>
        <span style={{
          padding:'2px 8px', borderRadius: 3, fontSize:10, fontWeight: density==='cards'?600:500,
          background: density==='cards' ? '#fff' : 'transparent',
          color: density==='cards' ? W.ink : W.ink3,
        }}>Cards</span>
        <span style={{
          padding:'2px 8px', borderRadius: 3, fontSize:10, fontWeight: density==='rows'?600:500,
          background: density==='rows' ? '#fff' : 'transparent',
          color: density==='rows' ? W.ink : W.ink3,
        }}>Rows</span>
      </div>
    </div>
  );
}

// Universal Words bulk view — drives both Line/Para/Column/Body "Items · Words"
function WordsBulkView({ groups, density='cards', scopeLabel, extraToolbar }) {
  const totalWords = groups.reduce((n, g) => n + g.words.length, 0);
  const totalSel   = groups.reduce((n, g) => n + g.words.filter(w => w.selected).length, 0);
  const Group = density === 'cards' ? WordCardGroup : WordRowGroup;
  return (
    <div style={{display:'flex', flexDirection:'column', flex:1, minHeight:0}}>
      <BulkBar selectedCount={totalSel} totalCount={totalWords}
        extra={
          <>
            {extraToolbar}
            <span style={{width:1, height:18, background:W.rule}}></span>
            <DensityToggle density={density}/>
            <span style={{width:1, height:18, background:W.rule}}></span>
          </>
        }/>
      {scopeLabel && (
        <div style={{
          padding:'4px 14px', fontSize: 10, color: W.ink3,
          background: W.paperAlt, borderBottom: `1px solid ${W.rule}`,
          display:'flex', alignItems:'center', gap: 6,
        }}>
          <span className="wf-h-label" style={{fontSize: 8}}>SCOPE</span>
          <span style={{color: W.ink2, fontWeight: 600}}>{scopeLabel}</span>
          <span style={{color: W.ink3}}>· grouped by line</span>
        </div>
      )}
      <div style={{flex:1, padding: 12, background: W.paperAlt, overflow:'auto'}}>
        {groups.map((g, i) => (
          <Group key={i}
            line={g.line}
            paraLabel={g.paraLabel}
            words={g.words}
            exact={g.exact} fuzzy={g.fuzzy} miss={g.miss}/>
        ))}
      </div>
    </div>
  );
}

// =====================================================================
// Sample data + bigger-scope demos (column, body)
// =====================================================================

// helper: build N body-text words for sample data
function bw(l, idx, w) {
  return { l, idx, img: w, ocr: w, gt: w, status:'exact', selected:false };
}

// Paragraph 4 (5 lines, used in earlier mock — keep as one source of truth)
const PARA4_GROUPS = [
  { line:1, paraLabel:'¶ #4 · body text', exact:3, fuzzy:0, miss:0, words:[
    { l:1, idx:1, img:'A',        ocr:'A',        gt:'A',        status:'exact', selected:false, chips:['All Caps'] },
    { l:1, idx:2, img:'HISTORY',  ocr:'HISTORY',  gt:'HISTORY',  status:'exact', selected:false, chips:['All Caps'] },
    { l:1, idx:3, img:'OF',       ocr:'OF',       gt:'OF',       status:'exact', selected:false, chips:['All Caps'] },
  ]},
  { line:2, exact:3, fuzzy:0, miss:0, words:[
    { l:2, idx:1, img:'THE',      ocr:'THE',      gt:'THE',      status:'exact', selected:false, chips:['All Caps'] },
    { l:2, idx:2, img:'AMERICAN', ocr:'AMERICAN', gt:'AMERICAN', status:'exact', selected:false, chips:['All Caps'] },
    { l:2, idx:3, img:'PEOPLE',   ocr:'PEOPLE',   gt:'PEOPLE',   status:'exact', selected:false, chips:['All Caps'] },
  ]},
  { line:3, exact:1, fuzzy:0, miss:0, words:[
    { l:3, idx:1, img:'BY',       ocr:'BY',       gt:'BY',       status:'exact', selected:false, chips:['All Caps'] },
  ]},
  { line:4, exact:3, fuzzy:2, miss:0, words:[
    { l:4, idx:1, img:'WOODROW',  ocr:'WOODROW',  gt:'WOODROW',  status:'exact', selected:false, chips:['All Caps'] },
    { l:4, idx:2, img:'WILSON,',  ocr:'WILSON,',  gt:'WILSON,',  status:'exact', selected:false, chips:['All Caps'] },
    { l:4, idx:3, img:'Ph.D.,',   ocr:'PH.D.,',   gt:'Ph.D.,',   status:'fuzzy', selected:true,  chips:['Sm. Caps'], sc:true },
    { l:4, idx:4, img:'Litt.D.,', ocr:'LITT.D.,', gt:'Litt.D.,', status:'fuzzy', selected:true,  chips:['Sm. Caps'], sc:true },
    { l:4, idx:5, img:'LL.D.',    ocr:'LL.D.',    gt:'LL.D.',    status:'exact', selected:false, chips:['All Caps'] },
  ]},
  { line:5, exact:3, fuzzy:0, miss:0, words:[
    { l:5, idx:1, img:'IN',       ocr:'IN',       gt:'IN',       status:'exact', selected:false, chips:['All Caps'] },
    { l:5, idx:2, img:'FIVE',     ocr:'FIVE',     gt:'FIVE',     status:'exact', selected:false, chips:['All Caps'] },
    { l:5, idx:3, img:'VOLUMES',  ocr:'VOLUMES',  gt:'VOLUMES',  status:'exact', selected:false, chips:['All Caps'] },
  ]},
];

// Column 1 — a chapter heading paragraph (¶ #1), byline (¶ #2),
//   then ¶ #4 (which is the same one above). For brevity show 3 of these.
const COLUMN1_GROUPS = [
  // ¶ #1 — chap heading "III · The Founding of the Government"
  { line:1, paraLabel:'¶ #1 · chapter heading', exact:2, fuzzy:0, miss:0, words:[
    { l:1, idx:1, img:'III.',    ocr:'III.',    gt:'III.',    status:'exact', selected:false, chips:['All Caps'] },
    { l:1, idx:2, img:'THE',     ocr:'THE',     gt:'THE',     status:'exact', selected:false, chips:['All Caps'] },
  ]},
  { line:2, exact:3, fuzzy:1, miss:0, words:[
    { l:2, idx:1, img:'Founding',ocr:'Jounding',gt:'Founding',status:'mismatch', selected:true,  chips:['Blackletter'] },
    { l:2, idx:2, img:'of',      ocr:'of',      gt:'of',      status:'exact',    selected:false, chips:['Blackletter'] },
    { l:2, idx:3, img:'the',     ocr:'tbe',     gt:'the',     status:'mismatch', selected:true,  chips:['Blackletter'] },
    { l:2, idx:4, img:'Government', ocr:'Gopernment', gt:'Government', status:'mismatch', selected:true, chips:['Blackletter'] },
  ]},
  // ¶ #2 — byline
  { line:3, paraLabel:'¶ #2 · byline', exact:3, fuzzy:0, miss:0, words:[
    { l:3, idx:1, img:'BY',     ocr:'BY',     gt:'BY',     status:'exact', selected:false },
    { l:3, idx:2, img:'WOODROW',ocr:'WOODROW',gt:'WOODROW',status:'exact', selected:false, chips:['All Caps'] },
    { l:3, idx:3, img:'WILSON',  ocr:'WILSON', gt:'WILSON', status:'exact', selected:false, chips:['All Caps'] },
  ]},
  // ¶ #3 — body opening
  { line:4, paraLabel:'¶ #3 · body text', exact:4, fuzzy:0, miss:0, words:[
    { l:4, idx:1, img:'The',     ocr:'The',     gt:'The',     status:'exact', selected:false },
    { l:4, idx:2, img:'years',   ocr:'years',   gt:'years',   status:'exact', selected:false },
    { l:4, idx:3, img:'that',    ocr:'that',    gt:'that',    status:'exact', selected:false },
    { l:4, idx:4, img:'followed',ocr:'followed',gt:'followed',status:'exact', selected:false },
  ]},
  { line:5, exact:5, fuzzy:0, miss:0, words:[
    bw(5,1,'were'), bw(5,2,'the'), bw(5,3,'years'),
    bw(5,4,'of'), bw(5,5,'making.'),
  ]},
  // ¶ #4 (same as above)
  { line:6, paraLabel:'¶ #4 · body text', exact:3, fuzzy:2, miss:0, words:[
    { l:6, idx:1, img:'WOODROW',  ocr:'WOODROW',  gt:'WOODROW',  status:'exact', selected:false, chips:['All Caps'] },
    { l:6, idx:2, img:'WILSON,',  ocr:'WILSON,',  gt:'WILSON,',  status:'exact', selected:false, chips:['All Caps'] },
    { l:6, idx:3, img:'Ph.D.,',   ocr:'PH.D.,',   gt:'Ph.D.,',   status:'fuzzy', selected:true,  chips:['Sm. Caps'], sc:true },
    { l:6, idx:4, img:'Litt.D.,', ocr:'LITT.D.,', gt:'Litt.D.,', status:'fuzzy', selected:true,  chips:['Sm. Caps'], sc:true },
    { l:6, idx:5, img:'LL.D.',    ocr:'LL.D.',    gt:'LL.D.',    status:'exact', selected:false, chips:['All Caps'] },
  ]},
];

// Tabbed wrappers using the unified view
function MakeLineWordsView(density) {
  return function() {
    const groups = [PARA4_GROUPS[3]];   // the line 4 group alone
    return (
      <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
        <BlockBreadcrumb path={[
          { label:'Body',    kind:'structural', children:2 },
          { label:'Column',  sublabel:'1 of 2', kind:'structural', children:4 },
          { label:'¶',       sublabel:'#4', kind:'paragraph', children:5 },
          { label:'Line',    sublabel:'4', kind:'line', children:5 },
        ]}/>
        <PanelTabBar
          tabs={[
            { k:'detail', label:'Line',  icon:'▦' },
            { k:'words',  label:'Words', icon:'☷', count:5 },
          ]}
          active="words"/>
        <WordsBulkView groups={groups} density={density}
          scopeLabel="Line 4 (5 words)"/>
      </div>
    );
  };
}

function MakeParaItemsView(density) {
  return function() {
    return (
      <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
        <BlockBreadcrumb path={[
          { label:'Body',    kind:'structural', children:2 },
          { label:'Column',  sublabel:'1 of 2', kind:'structural', children:4 },
          { label:'¶',       sublabel:'#4 · body', kind:'paragraph', children:5 },
        ]}/>
        <PanelTabBar
          tabs={[
            { k:'layout', label:'Layout', icon:'⊞' },
            { k:'items',  label:'Items',  icon:'☷', count: 15 },
          ]}
          active="items"/>
        <WordsBulkView groups={PARA4_GROUPS} density={density}
          scopeLabel="Paragraph #4 (5 lines · 15 words)"
          extraToolbar={
            <div style={{display:'flex', alignItems:'center', gap: 4, fontSize:10, color: W.ink3}}>
              <span>View</span>
              <div style={{display:'flex', background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 4, padding:1}}>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Lines</span>
                <span style={{padding:'2px 8px', borderRadius: 3, background:'#fff', fontSize:10, fontWeight:600, color: W.ink}}>Words</span>
              </div>
            </div>
          }/>
      </div>
    );
  };
}

function MakeColumnItemsView(density) {
  return function() {
    return (
      <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
        <BlockBreadcrumb path={[
          { label:'Body',    kind:'structural', children:2 },
          { label:'Column',  sublabel:'1 of 2', kind:'structural', children:4 },
        ]}/>
        <PanelTabBar
          tabs={[
            { k:'layout', label:'Layout', icon:'⊞' },
            { k:'items',  label:'Items',  icon:'☷', count: 4 },
          ]}
          active="items"/>
        <WordsBulkView groups={COLUMN1_GROUPS} density={density}
          scopeLabel="Column 1 (4 paragraphs · 6 lines · 20 words shown)"
          extraToolbar={
            <div style={{display:'flex', alignItems:'center', gap: 4, fontSize:10, color: W.ink3}}>
              <span>View</span>
              <div style={{display:'flex', background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 4, padding:1}}>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Paragraphs</span>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Lines</span>
                <span style={{padding:'2px 8px', borderRadius: 3, background:'#fff', fontSize:10, fontWeight:600, color: W.ink}}>Words</span>
              </div>
            </div>
          }/>
      </div>
    );
  };
}

const LineWords_Cards   = MakeLineWordsView('cards');
const LineWords_Rows    = MakeLineWordsView('rows');
const ParaItems_Cards   = MakeParaItemsView('cards');
const ParaItems_Rows    = MakeParaItemsView('rows');
const ColumnItems_Cards = MakeColumnItemsView('cards');
const ColumnItems_Rows  = MakeColumnItemsView('rows');

// Block-quote example for the structural-block Items · Words view.
// Two child paragraphs, each with a few lines.
const BLOCK_QUOTE_GROUPS = [
  // ¶ #1 — "I have no purpose…"
  { line:1, paraLabel:'¶ #1 · body text (within block quote)', exact:5, fuzzy:0, miss:0, words:[
    { l:1, idx:1, img:'"I',     ocr:'"I',     gt:'"I',     status:'exact',    selected:false },
    { l:1, idx:2, img:'have',   ocr:'have',   gt:'have',   status:'exact',    selected:false },
    { l:1, idx:3, img:'no',     ocr:'no',     gt:'no',     status:'exact',    selected:false },
    { l:1, idx:4, img:'purpose',ocr:'purpose',gt:'purpose',status:'exact',    selected:false },
    { l:1, idx:5, img:'but',    ocr:'but',    gt:'but',    status:'exact',    selected:false },
  ]},
  { line:2, exact:5, fuzzy:0, miss:0, words:[
    { l:2, idx:1, img:'to',      ocr:'to',      gt:'to',     status:'exact', selected:false },
    { l:2, idx:2, img:'serve',   ocr:'serve',   gt:'serve',  status:'exact', selected:false },
    { l:2, idx:3, img:'the',     ocr:'the',     gt:'the',    status:'exact', selected:false },
    { l:2, idx:4, img:'present', ocr:'pre$ent', gt:'present',status:'fuzzy', selected:true,  chips:['Italic'] },
    { l:2, idx:5, img:'age,',    ocr:'age,',    gt:'age,',   status:'exact', selected:false },
  ]},
  { line:3, exact:4, fuzzy:0, miss:0, words:[
    { l:3, idx:1, img:'my',      ocr:'my',      gt:'my',      status:'exact', selected:false },
    { l:3, idx:2, img:'calling', ocr:'calling', gt:'calling', status:'exact', selected:false },
    { l:3, idx:3, img:'to',      ocr:'to',      gt:'to',      status:'exact', selected:false },
    { l:3, idx:4, img:'fulfill;',ocr:'fulfill;',gt:'fulfill;',status:'exact', selected:false },
  ]},
  // ¶ #2 — "the writer continues for two paragraphs…"
  { line:4, paraLabel:'¶ #2 · body text (within block quote)', exact:5, fuzzy:1, miss:0, words:[
    { l:4, idx:1, img:'O',       ocr:'O',       gt:'O',       status:'exact', selected:false },
    { l:4, idx:2, img:'may',     ocr:'may',     gt:'may',     status:'exact', selected:false },
    { l:4, idx:3, img:'it',      ocr:'it',      gt:'it',      status:'exact', selected:false },
    { l:4, idx:4, img:'all',     ocr:'all',     gt:'all',     status:'exact', selected:false },
    { l:4, idx:5, img:'my',      ocr:'mv',      gt:'my',      status:'fuzzy', selected:true },
    { l:4, idx:6, img:'powers',  ocr:'powers',  gt:'powers',  status:'exact', selected:false },
  ]},
  { line:5, exact:4, fuzzy:0, miss:0, words:[
    { l:5, idx:1, img:'engage',  ocr:'engage',  gt:'engage',  status:'exact', selected:false },
    { l:5, idx:2, img:'to',      ocr:'to',      gt:'to',      status:'exact', selected:false },
    { l:5, idx:3, img:'do',      ocr:'do',      gt:'do',      status:'exact', selected:false },
    { l:5, idx:4, img:'my',      ocr:'my',      gt:'my',      status:'exact', selected:false },
  ]},
  { line:6, exact:4, fuzzy:0, miss:0, words:[
    { l:6, idx:1, img:'Master\'s', ocr:'Master\'s', gt:'Master\'s', status:'exact', selected:false },
    { l:6, idx:2, img:'will."',    ocr:'will."',    gt:'will."',    status:'exact', selected:false },
  ]},
];

function MakeBlockItemsWordsView(density) {
  return function() {
    return (
      <div className="wf" style={{padding: 0, display:'flex', flexDirection:'column', background: W.panel, overflow:'hidden'}}>
        <BlockBreadcrumb path={[
          { label:'Body',        kind:'structural', children:2 },
          { label:'Column',      sublabel:'2 of 2', kind:'structural', children:5 },
          { label:'Block quote', kind:'structural', children:2 },
        ]}/>
        <PanelTabBar
          tabs={[
            { k:'layout', label:'Layout', icon:'⊞' },
            { k:'items',  label:'Items',  icon:'☷', count: 40 },
          ]}
          active="items"/>
        <WordsBulkView groups={BLOCK_QUOTE_GROUPS} density={density}
          scopeLabel="Block quote (2 paragraphs · 6 lines · 26 words)"
          extraToolbar={
            <div style={{display:'flex', alignItems:'center', gap: 4, fontSize:10, color: W.ink3}}>
              <span>View</span>
              <div style={{display:'flex', background: W.panelSunk, border:`1px solid ${W.rule}`, borderRadius: 4, padding:1}}>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Blocks</span>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Paragraphs</span>
                <span style={{padding:'2px 8px', fontSize:10, color: W.ink3}}>Lines</span>
                <span style={{padding:'2px 8px', borderRadius: 3, background:'#fff', fontSize:10, fontWeight:600, color: W.ink}}>Words</span>
              </div>
            </div>
          }/>
      </div>
    );
  };
}

const BlockItems_Words_Cards = MakeBlockItemsWordsView('cards');
const BlockItems_Words_Rows  = MakeBlockItemsWordsView('rows');

// Artboard helpers
function TabbedLinePanel_Detail() { return <TabbedLinePanel/>; }
function TabbedBlock_Para_Layout()   { return <TabbedBlockPanel structural={false} activeTab="layout"/>; }
function TabbedBlock_Struct_Layout() { return <TabbedBlockPanel structural={true}  activeTab="layout"/>; }
function TabbedBlock_Struct_Items()  { return <TabbedBlockPanel structural={true}  activeTab="items"/>; }

Object.assign(window, {
  TabbedLinePanel_Detail,
  TabbedBlock_Para_Layout, TabbedBlock_Struct_Layout, TabbedBlock_Struct_Items,
  BlockItems_Words_Cards, BlockItems_Words_Rows,
  WordRowCheckable, WordRowGroup, WordsBulkView, DensityToggle,
  LineWords_Cards, LineWords_Rows,
  ParaItems_Cards, ParaItems_Rows,
  ColumnItems_Cards, ColumnItems_Rows,
});
