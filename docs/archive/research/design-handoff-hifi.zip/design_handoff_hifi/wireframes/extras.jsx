// Extras: style tile, RootPage, hotkey overlay, toast stack.

// ─── STYLE TILE ─────────────────────────────────────────────────
function StyleTile() {
  return (
    <div className="wf" style={{padding: 28, overflow:'auto'}}>
      <div style={{display:'flex', flexDirection:'column', gap: 20}}>
        <header>
          <div style={{fontFamily:W.hand, fontSize: 28, color: W.ink}}>style tile</div>
          <div style={{fontSize:12, color:W.ink3, marginTop: 4}}>
            Tokens for the labeler — neutral chrome, color reserved for status &amp; layers.
          </div>
        </header>

        {/* Match status badges */}
        <section>
          <div className="wf-h-label" style={{marginBottom: 8}}>Match status</div>
          <div style={{display:'grid', gridTemplateColumns:'auto auto 1fr', gap: 10, alignItems:'center', maxWidth: 540}}>
            {[
              ['exact',    W.exact,    '✓', 'OCR == GT'],
              ['fuzzy',    W.fuzzy,    '~', 'OCR ≈ GT (above threshold)'],
              ['mismatch', W.mismatch, '✗', 'OCR ≠ GT'],
              ['ocr',      W.ocrOnly,  '○', 'OCR word with no GT match'],
              ['gt',       W.gtOnly,   '○', 'GT word with no OCR match'],
            ].map(([k, c, glyph, desc]) => (
              <React.Fragment key={k}>
                <span className="wf-pip" style={{background: c + '1a', color: c, border: `1px solid ${c}66`}}>
                  <span className="dot" style={{background: c}}></span>
                  {k}
                </span>
                <span className="wf-mono" style={{fontSize: 12, color: W.ink2, padding:'2px 8px', background:'#fff', borderRadius:3, border:`1px solid ${W.rule}`}}>{c}</span>
                <span style={{fontSize: 12, color: W.ink2}}>{desc}</span>
              </React.Fragment>
            ))}
          </div>
        </section>

        {/* Layer colors */}
        <section>
          <div className="wf-h-label" style={{marginBottom: 8}}>Canvas overlay layers</div>
          <div style={{display:'flex', gap: 12}}>
            {[
              ['Paragraphs', W.paraColor, 'soft fill + dark border'],
              ['Lines',      W.lineColor, 'soft fill + dark border'],
              ['Words',      W.wordColor, 'soft fill + dark border'],
            ].map(([n, c, hint]) => (
              <div key={n} style={{
                flex:1, padding: 12, borderRadius: 6, background: W.panel, border: `1px solid ${W.rule}`,
                display:'flex', flexDirection:'column', gap:8,
              }}>
                <div style={{
                  height: 60, borderRadius: 4,
                  background: c + '26',
                  border: `1.5px solid ${c}`,
                  position:'relative',
                  mixBlendMode:'multiply',
                }}>
                  <div style={{
                    position:'absolute', left:'15%', right:'15%', top:'25%', bottom:'25%',
                    border: `1px solid ${c}`, background: c+'40',
                  }}></div>
                </div>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline'}}>
                  <span style={{fontWeight:600, fontSize:13}}>{n}</span>
                  <span className="wf-mono" style={{fontSize:11, color:W.ink2}}>{c}</span>
                </div>
                <span style={{fontSize:11, color:W.ink3}}>{hint}</span>
              </div>
            ))}
          </div>
          <div style={{fontSize:11, color:W.ink3, marginTop:8, fontStyle:'italic'}}>
            Canvas uses <code>mix-blend-mode: multiply</code> so overlays don&apos;t wash out the scan.
          </div>
        </section>

        {/* Buttons */}
        <section>
          <div className="wf-h-label" style={{marginBottom: 8}}>Buttons</div>
          <div style={{display:'flex', gap: 10, flexWrap:'wrap', alignItems:'center'}}>
            <span className="wf-btn primary">Primary</span>
            <span className="wf-btn">Secondary</span>
            <span className="wf-btn ghost">Ghost</span>
            <span className="wf-btn danger">Destructive</span>
            <span className="wf-btn accent">Accent</span>
            <span className="wf-btn icon">⚙</span>
          </div>
          <div style={{display:'flex', gap:8, marginTop:10, alignItems:'center'}}>
            <span className="wf-btn sm primary">Small</span>
            <span className="wf-btn sm">Small</span>
            <span className="wf-btn">Medium</span>
            <span className="wf-btn lg primary">Large</span>
            <span className="wf-btn lg">Large</span>
          </div>
        </section>

        {/* Mode chips */}
        <section>
          <div className="wf-h-label" style={{marginBottom: 8}}>Mode segmented switcher</div>
          <ModeSwitcher active="Select"/>
          <div style={{display:'flex', gap:20, marginTop:14, fontSize:11, color:W.ink2}}>
            <span><b>Select</b> drag = box-select; ⇧ remove, ⌃ toggle</span>
            <span><b>Rebox</b> draw new bbox for an existing word</span>
            <span><b>Add</b> draw new word bboxes (multi)</span>
            <span><b>Erase</b> drag red rect, releases an erase op</span>
          </div>
        </section>

        {/* Word cell sample */}
        <section>
          <div className="wf-h-label" style={{marginBottom: 8}}>LineCard · word cell</div>
          <div style={{display:'flex', gap: 10}}>
            <WordCell img="WILSON," ocr="WILSON," gt="Wilson," status="fuzzy" chips={['Sm. Caps']} w={140} focused/>
            <WordCell img="tbe" ocr="tbe" gt="The" status="mismatch" chips={['Blackletter']} w={140}/>
            <WordCell img="VOL." ocr="VOL." gt="Vol." status="exact" chips={['Sm. Caps']} w={140}/>
          </div>
        </section>

        {/* Type */}
        <section>
          <div className="wf-h-label" style={{marginBottom: 8}}>Type</div>
          <div style={{display:'grid', gridTemplateColumns:'120px 1fr', gap:'10px 16px', alignItems:'baseline'}}>
            <span style={{fontSize:11, color:W.ink3}}>Inter / UI</span>
            <span style={{fontFamily:W.ui, fontSize:14}}>Aa Bb 0123 — header, labels, body</span>
            <span style={{fontSize:11, color:W.ink3}}>JetBrains Mono</span>
            <span style={{fontFamily:W.mono, fontSize:14}}>Aa Bb 0123 — OCR text &amp; GT inputs</span>
            <span style={{fontSize:11, color:W.ink3}}>Caveat (sketch)</span>
            <span style={{fontFamily:W.hand, fontSize:22}}>Aa Bb 0123 — wireframe annotations only</span>
          </div>
        </section>
      </div>
    </div>
  );
}

// ─── ROOTPAGE / PROJECT PICKER ──────────────────────────────────
function RootPage() {
  const projects = [
    {name:'willa-cather-letters', pages:47,  pct:68, src:'~/source-pgdp-data/willa-cather-letters', updated:'2m ago'},
    {name:'wilson-american-people-v3', pages:392, pct:23, src:'~/scans/wilson-history-vol3', updated:'yesterday'},
    {name:'darwin-voyage', pages:514, pct:100, src:'~/scans/darwin-voyage', updated:'3 days ago', done:true},
    {name:'gibbon-decline-vol2', pages:704, pct:5, src:'~/scans/gibbon', updated:'last week'},
  ];
  return (
    <div className="wf" style={{display:'flex', flexDirection:'column'}}>
      <header style={{padding:'40px 64px 24px', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <div>
          <div style={{fontFamily:W.hand, fontSize: 38, color: W.ink}}>ocr labeler</div>
          <div style={{fontSize: 13, color: W.ink3, marginTop: 4}}>Local OCR ground-truth labeling. Pick a project to keep working.</div>
        </div>
        <div style={{display:'flex', gap: 8}}>
          <span className="wf-btn">Open folder…</span>
          <span className="wf-btn primary">＋ New project</span>
        </div>
      </header>
      <div style={{padding:'0 64px 24px', display:'flex', gap: 14, alignItems:'center'}}>
        <input className="wf-input lg" placeholder="Search projects…" style={{flex:1, maxWidth:320, fontSize:14}}/>
        <div style={{display:'flex', gap:4}}>
          <span className="wf-chip">All 4</span>
          <span className="wf-chip">In progress 3</span>
          <span className="wf-chip" style={{background:W.exact+'22', color:W.exact, borderColor:W.exact+'88'}}>Complete 1</span>
        </div>
        <div style={{flex:1}}></div>
        <span style={{fontSize:11, color:W.ink3}}>Source</span>
        <span className="wf-chip" style={{fontFamily:W.mono}}>~/.local/share/pd-ocr-labeler</span>
      </div>
      <div style={{padding:'0 64px 40px', display:'flex', flexDirection:'column', gap:12, flex:1, overflow:'hidden'}}>
        {projects.map(p => (
          <div key={p.name} style={{
            display:'flex', alignItems:'center', gap: 18, padding: 18,
            background: W.panel, border:`1px solid ${W.rule}`, borderRadius: 6,
          }}>
            <div style={{
              width:56, height:56, borderRadius:4, background: p.done ? W.exact+'18' : W.paperAlt,
              border:`1px solid ${p.done ? W.exact : W.rule}`,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'serif', fontSize:24, color: p.done ? W.exact : W.ink3,
            }}>{p.done ? '✓' : '📖'}</div>
            <div style={{flex:1, display:'flex', flexDirection:'column', gap:4, minWidth:0}}>
              <div style={{display:'flex', alignItems:'baseline', gap:10}}>
                <span style={{fontSize:16, fontWeight:600}}>{p.name}</span>
                <span className="wf-h-label">{p.pages} pages</span>
                <span style={{fontSize:11, color:W.ink3}}>· updated {p.updated}</span>
              </div>
              <span className="wf-mono" style={{fontSize:11, color:W.ink3}}>{p.src}</span>
              <div style={{display:'flex', alignItems:'center', gap:8, marginTop:4}}>
                <div style={{flex:1, height:6, background:W.panelSunk, borderRadius:3, position:'relative', maxWidth: 380}}>
                  <div style={{position:'absolute', inset:0, width:p.pct+'%', background: p.pct===100 ? W.exact : W.fuzzy, borderRadius:3}}></div>
                </div>
                <span style={{fontSize:11, color:W.ink2, fontWeight:600, minWidth:36}}>{p.pct}%</span>
              </div>
            </div>
            <div style={{display:'flex', gap:6, flexDirection:'column'}}>
              <span className="wf-btn primary">Open</span>
              <span className="wf-btn sm ghost">⋯</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── HOTKEY OVERLAY ─────────────────────────────────────────────
function HotkeyOverlay() {
  const groups = [
    ['Navigation', [
      ['←  →',       'previous / next word'],
      ['↑  ↓',       'previous / next line'],
      ['J  K',       'next / prev unvalidated word'],
      ['⌘ →',        'next page'],
      ['⌘ ←',        'previous page'],
      ['G',          'go to page…'],
    ]],
    ['Editing', [
      ['V',         'validate / unvalidate'],
      ['⏎',        'save &amp; advance'],
      ['O',         'copy OCR → GT'],
      ['E',         'open edit dialog'],
      ['⌫',        'delete word'],
    ]],
    ['Canvas mode', [
      ['S',         'select mode'],
      ['R',         'rebox mode'],
      ['A',         'add word mode'],
      ['X',         'erase mode'],
      ['1 / 2 / 3', 'toggle paragraphs / lines / words'],
    ]],
    ['App', [
      ['⌘ K',       'command palette'],
      ['⌘ S',       'save page'],
      ['⌘ ⇧ S',     'save project'],
      ['⌘ /',       'this cheatsheet'],
      ['?',         'this cheatsheet'],
    ]],
  ];
  return (
    <div className="wf" style={{padding:0, background:'rgba(20,16,12,0.45)'}}>
      {/* the actual sheet */}
      <div style={{
        margin: 30, height: 'calc(100% - 60px)',
        background: W.panel, borderRadius: 10, padding: 24,
        boxShadow: '0 24px 80px rgba(0,0,0,0.25)',
        display:'flex', flexDirection:'column', gap: 16,
      }}>
        <div style={{display:'flex', alignItems:'baseline', justifyContent:'space-between'}}>
          <div>
            <div style={{fontFamily:W.hand, fontSize: 26}}>keyboard shortcuts</div>
            <div style={{fontSize:11, color:W.ink3, marginTop:2}}>This is a power-user tool. Most labels can be done without leaving the keyboard.</div>
          </div>
          <span style={{fontSize:11, color:W.ink3}}>Press <span className="wf-key">esc</span> to close</span>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px 32px', overflow:'hidden'}}>
          {groups.map(([title, items]) => (
            <div key={title}>
              <div className="wf-h-label" style={{marginBottom: 10}}>{title}</div>
              <div style={{display:'flex', flexDirection:'column', gap: 8}}>
                {items.map(([keys, desc]) => (
                  <div key={keys} style={{display:'flex', alignItems:'center', gap: 10}}>
                    <div style={{display:'flex', gap:3, minWidth: 100}}>
                      {keys.split(' ').map((k,i) => (
                        k === '' ? <span key={i} style={{width:6}}></span> :
                        <span key={i} className="wf-key" style={{height:20, minWidth:20}}>{k}</span>
                      ))}
                    </div>
                    <span style={{fontSize:12, color:W.ink2}} dangerouslySetInnerHTML={{__html: desc}}></span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── TOAST STACK ────────────────────────────────────────────────
function ToastStack() {
  const toasts = [
    {kind:'progress', title:'Refining bboxes — page 47', body:'Word 12 of 22', pct: 54},
    {kind:'progress', title:'Saving project', body:'392 pages · uploading manifest', pct: 88},
    {kind:'success',  title:'Page 46 saved', body:'22 words · all validated · 100% match'},
    {kind:'warn',     title:'Rematch GT changed 3 alignments', body:'L4·W3, L7·W2, L7·W5 → review'},
    {kind:'error',    title:'OCR config failed', body:'Could not load rec model: file not found', actions:['Retry','Open config']},
    {kind:'info',     title:'Auto-saved', body:'Local snapshot · 30s ago'},
  ];
  const palette = {
    progress: ['#fff', W.ink, W.ink2],
    success:  ['#fff', W.exact, W.exact + 'aa'],
    warn:     ['#fff', W.fuzzy, W.fuzzy + 'aa'],
    error:    ['#fff', W.mismatch, W.mismatch + 'aa'],
    info:     ['#fff', W.ocrOnly, W.ocrOnly + 'aa'],
  };
  return (
    <div className="wf" style={{padding:0, background: W.paperAlt}}>
      <div className="wf-note" style={{top: 16, left: 16}}>
        toast stack · bottom-right<br/>of the viewport
      </div>
      <div style={{
        position:'absolute', right: 18, bottom: 18, width: 340,
        display:'flex', flexDirection:'column', gap: 10,
      }}>
        {toasts.map((t,i) => {
          const [bg, bar, _] = palette[t.kind];
          return (
            <div key={i} style={{
              background: bg, border: `1px solid ${W.rule}`, borderLeft: `4px solid ${bar}`,
              borderRadius: 6, padding: '10px 12px',
              boxShadow: '0 4px 16px rgba(0,0,0,0.06)',
              display:'flex', flexDirection:'column', gap: 4,
            }}>
              <div style={{display:'flex', alignItems:'baseline', gap:8}}>
                <span style={{fontSize: 12, fontWeight: 600, color: W.ink, flex:1}}>{t.title}</span>
                <span style={{fontSize: 11, color: W.ink3}}>✕</span>
              </div>
              <span style={{fontSize: 11, color: W.ink2}}>{t.body}</span>
              {t.pct != null && (
                <div style={{height: 4, background: W.panelSunk, borderRadius: 2, marginTop: 4, position:'relative'}}>
                  <div style={{position:'absolute', inset:0, width: t.pct+'%', background: bar, borderRadius: 2}}></div>
                </div>
              )}
              {t.actions && (
                <div style={{display:'flex', gap:6, marginTop:6}}>
                  {t.actions.map(a => <span key={a} className="wf-btn sm">{a}</span>)}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { StyleTile, RootPage, HotkeyOverlay, ToastStack });
