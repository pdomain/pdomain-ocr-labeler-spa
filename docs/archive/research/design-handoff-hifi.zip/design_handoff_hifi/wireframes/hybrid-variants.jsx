// Hybrid layouts v2 — based on user feedback round 2.
//
// Model:
//   • Rail (fixed): mode tools + "Select target" picker + layer visibility
//   • LEFT DRAWER: Worklist ONLY (no tabs). Clicking a row updates the right
//     panel's editor, focused row is highlighted.
//   • CANVAS: ~1/3 of viewport
//   • RIGHT PANEL: adapts to selection — Matches / Word / Line / Para.
//     A breadcrumb-tab header lets you jump levels.
//
// 4 configurations.

// ============== RAIL ==============================================
function HybridRail2({ activeMode='Select', activeTarget='Word', activeLayers=['b','p','l','w'] }) {
  const BLOCK = '#7a6c5a'; // taupe — matches BLOCK_COLOR in block-layout-system.jsx
  const modes = [
    {k:'Select', icon:'⬚', hot:'V'},
    {k:'Rebox',  icon:'⤡', hot:'R'},
    {k:'Add',    icon:'＋', hot:'A'},
    {k:'Erase',  icon:'⌫', hot:'E'},
  ];
  return (
    <div style={{
      width: 68, flex:'0 0 68px',
      background: W.paperAlt, borderRight: `1px solid ${W.rule}`,
      display:'flex', flexDirection:'column', alignItems:'center', padding:'10px 0', gap: 3,
    }}>
      <span style={{fontFamily:W.hand, fontSize:17, color:W.ink, marginBottom:4}}>ol.</span>

      <span className="wf-h-label" style={{fontSize:7, marginTop:6}}>MODE</span>
      {modes.map(m => {
        const a = m.k === activeMode;
        return (
          <div key={m.k} style={{
            width: 52, padding:'5px 0',
            background: a ? '#fff' : 'transparent',
            border: a ? `1px solid ${W.ink3}` : '1px solid transparent',
            borderRadius: 6,
            display:'flex', flexDirection:'column', alignItems:'center', gap:1,
          }}>
            <span style={{fontSize:14, lineHeight:1, color: a ? W.ink : W.ink2}}>{m.icon}</span>
            <span style={{fontSize:9, fontWeight:600, color: a ? W.ink : W.ink2}}>{m.k}</span>
          </div>
        );
      })}

      {/* Selection target — only meaningful while Select is active */}
      <span className="wf-h-label" style={{fontSize:7, marginTop:8,
        opacity: activeMode==='Select' ? 1 : 0.45,
      }}>TARGET</span>
      <div style={{
        display:'flex', gap:2, padding:2,
        background: activeMode==='Select' ? W.panelSunk : 'transparent',
        border: `1px solid ${activeMode==='Select' ? W.rule : 'transparent'}`,
        borderRadius: 5,
        opacity: activeMode==='Select' ? 1 : 0.5,
      }}>
        {[['B', BLOCK, 'Block'],['L', W.lineColor, 'Line'],['W', W.wordColor, 'Word']].map(([k, c, full]) => {
          const a = full === activeTarget;
          return (
            <div key={k} style={{
              width: 16, height: 22, borderRadius: 3,
              background: a ? '#fff' : 'transparent',
              border: a ? `1px solid ${c}` : '1px solid transparent',
              color: a ? c : W.ink3,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize: 10, fontWeight: 700,
            }}>{k}</div>
          );
        })}
      </div>

      <div style={{width:'70%', height:1, background:W.rule, margin:'10px 0 6px'}}></div>

      <span className="wf-h-label" style={{fontSize:7}}>LAYERS</span>
      {[
        ['b','Block',BLOCK],
        ['p','¶ Para',W.paraColor],
        ['l','Line',W.lineColor],
        ['w','Word',W.wordColor],
      ].map(([k,l,c]) => {
        const on = activeLayers.includes(k);
        return (
          <div key={k} style={{
            width: 52, padding:'3px 0',
            display:'flex', flexDirection:'column', alignItems:'center', gap:1,
          }}>
            <span style={{
              width:16, height:16, borderRadius:4,
              background: on ? c+'33' : 'transparent',
              border:`1.5px solid ${on ? c : W.ink4}`,
            }}></span>
            <span style={{fontSize:9, color:W.ink2}}>{l}</span>
          </div>
        );
      })}

      <div style={{width:'70%', height:1, background:W.rule, margin:'10px 0 6px'}}></div>

      {[{k:'Bulk',i:'⌗'},{k:'Erase Px',i:'🩹'},{k:'Hotkeys',i:'⌘'}].map(t => (
        <div key={t.k} style={{
          width: 52, padding:'4px 0',
          display:'flex', flexDirection:'column', alignItems:'center', gap:1, color:W.ink2,
        }}>
          <span style={{fontSize:13}}>{t.i}</span>
          <span style={{fontSize:9}}>{t.k}</span>
        </div>
      ))}
    </div>
  );
}

// ============== HEADER ==============================================
function HybridHeader2() {
  return (
    <div style={{
      height: 50, borderBottom:`1px solid ${W.rule}`, background:W.panel,
      display:'flex', alignItems:'center', gap: 14, padding: '0 16px',
    }}>
      <HField label="Project" value="willa-cather-letters" w={170}/>
      <PageNav page={47} total={392}/>
      <div style={{flex:1, display:'flex', gap:10, justifyContent:'center'}}>
        <MetricChip value="22" label="words"/>
        <MetricChip value="15" label="exact" color={W.exact}/>
        <MetricChip value="7"  label="fuzzy" color={W.fuzzy}/>
        <MetricChip value="0"  label="✗" color={W.mismatch}/>
        <MetricChip value="100%" label="match"/>
        <MetricChip value="15/22" label="validated"/>
      </div>
      <span className="wf-btn">Reload OCR</span>
      <span className="wf-btn">Rematch</span>
      <span className="wf-btn primary">Save Page</span>
      <span className="wf-btn">Export ▾</span>
    </div>
  );
}

// ============== DRAWER TAB SWITCHER =================================
function DrawerTabs({ active='worklist' }) {
  const tabs = [
    {k:'worklist',  label:'Worklist',  icon:'☰', count: 7},
    {k:'hierarchy', label:'Hierarchy', icon:'⌐', count: null},
  ];
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 2,
      padding: '0 8px', borderBottom: `1px solid ${W.rule}`,
      background: W.paperAlt,
    }}>
      {tabs.map(t => {
        const on = t.k === active;
        return (
          <span key={t.k} style={{
            padding:'8px 10px',
            display:'inline-flex', alignItems:'center', gap: 5,
            fontSize: 12, fontWeight: 600,
            color: on ? W.ink : W.ink3,
            borderBottom: on ? `2px solid ${W.ink}` : '2px solid transparent',
            marginBottom: -1,
          }}>
            <span style={{opacity: 0.75}}>{t.icon}</span>
            {t.label}
            {t.count != null && (
              <span style={{
                padding:'0 5px', borderRadius: 8, fontSize: 9, fontWeight: 600,
                background: on ? W.ink + '15' : W.panelSunk,
                color: on ? W.ink : W.ink3,
              }}>{t.count}</span>
            )}
          </span>
        );
      })}
      <div style={{flex:1}}></div>
      <span className="wf-btn sm icon" style={{width:22, height:22, fontSize:11, color:W.ink3}}>‹</span>
    </div>
  );
}

// ============== HIERARCHY VIEW (mini tree for the drawer) ===========
function DrawerHierarchyView({ selectedId='B2.2.2' }) {
  const rows = [
    {id:'B1', depth:0, type:'header_band', label:'Header band', kind:'structural'},
    {id:'B1.1', depth:1, type:'header_text', label:'¶ running head', kind:'paragraph', leaf:true},
    {id:'B2', depth:0, type:'body', label:'Body', kind:'structural'},
    {id:'B2.1', depth:1, type:'column', label:'Column 1', kind:'structural'},
    {id:'B2.1.1', depth:2, type:'chap_head', label:'¶ chapter heading', kind:'paragraph', leaf:true},
    {id:'B2.1.2', depth:2, type:'byline', label:'¶ byline', kind:'paragraph', leaf:true},
    {id:'B2.1.3', depth:2, type:'body_text', label:'¶ body text', kind:'paragraph', leaf:true},
    {id:'B2.1.4', depth:2, type:'body_text', label:'¶ body text', kind:'paragraph', leaf:true},
    {id:'B2.2', depth:1, type:'column', label:'Column 2', kind:'structural'},
    {id:'B2.2.1', depth:2, type:'body_text', label:'¶ body text', kind:'paragraph', leaf:true},
    {id:'B2.2.2', depth:2, type:'block_quote', label:'Block quote', kind:'structural'},
    {id:'B2.2.2.1', depth:3, type:'body_text', label:'¶ quote pt1', kind:'paragraph', leaf:true},
    {id:'B2.2.2.2', depth:3, type:'body_text', label:'¶ quote pt2', kind:'paragraph', leaf:true},
    {id:'B2.2.3', depth:2, type:'body_text', label:'¶ body text', kind:'paragraph', leaf:true},
    {id:'B2.2.4', depth:2, type:'figure_region', label:'Figure region', kind:'structural'},
    {id:'B2.2.4.1', depth:3, type:'caption', label:'¶ caption', kind:'paragraph', leaf:true},
    {id:'B2.2.5', depth:2, type:'body_text', label:'¶ body text', kind:'paragraph', leaf:true},
    {id:'B3', depth:0, type:'footnote_band', label:'Footnote band', kind:'structural'},
    {id:'B3.1', depth:1, type:'footnote', label:'¶ footnote 1', kind:'paragraph', leaf:true},
    {id:'B3.2', depth:1, type:'footnote', label:'¶ footnote 2', kind:'paragraph', leaf:true},
    {id:'B4', depth:0, type:'footer_band', label:'Footer band', kind:'structural'},
    {id:'B4.1', depth:1, type:'footer_text', label:'¶ page no', kind:'paragraph', leaf:true},
  ];
  const BLOCK = '#7a6c5a';
  return (
    <div style={{flex:1, overflow:'auto', padding: 6, fontFamily: W.ui}}>
      {rows.map(r => {
        const c = r.kind === 'structural' ? BLOCK : W.paraColor;
        const sel = r.id === selectedId;
        return (
          <div key={r.id} style={{
            display:'flex', alignItems:'center', gap: 5,
            padding: '4px 6px', borderRadius: 3,
            paddingLeft: 6 + r.depth * 12,
            background: sel ? W.accent + '12' : 'transparent',
            border: sel ? `1.5px solid ${W.accent}` : '1px solid transparent',
            marginBottom: 1,
          }}>
            {!r.leaf && (
              <span style={{
                width: 10, color: W.ink3, fontSize: 8, transform:'rotate(90deg)',
              }}>▶</span>
            )}
            {r.leaf && <span style={{width:10}}></span>}
            <span style={{width: 6, height: 6, borderRadius: 1.5, background: c, flex:'0 0 auto'}}></span>
            <span style={{
              fontSize: 10, color: c, fontWeight: 600,
              padding: '0 4px', background: c + '12',
              border: `1px solid ${c}55`, borderRadius: 7,
              flex: '0 0 auto',
            }}>{r.kind === 'structural' ? 'block' : '¶'}</span>
            <span style={{
              fontSize: 11, color: W.ink, flex: 1, minWidth: 0,
              whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
            }}>{r.label}</span>
            <span style={{fontFamily: W.mono, fontSize: 9, color: W.ink4}}>{r.id}</span>
          </div>
        );
      })}
    </div>
  );
}

// ============== WORKLIST DRAWER =====================================
function WorklistDrawer({ focusedKey, view='worklist' }) {
  const queue = [
    {key:'l7w1', line:7, word:1, ocr:'tbe',       gt:'The',       status:'mismatch', conf:'42%'},
    {key:'l7w2', line:7, word:2, ocr:'Jounding',  gt:'Founding',  status:'mismatch', conf:'38%'},
    {key:'l7w4', line:7, word:4, ocr:'tbe',       gt:'the',       status:'mismatch', conf:'44%'},
    {key:'l7w5', line:7, word:5, ocr:'Gopernment',gt:'Government',status:'mismatch', conf:'29%'},
    {key:'l4w3', line:4, word:3, ocr:'PH.D.,',    gt:'Ph.D.,',    status:'fuzzy',    conf:'83%'},
    {key:'l4w4', line:4, word:4, ocr:'LITT.D.,',  gt:'Litt.D.,',  status:'fuzzy',    conf:'62%'},
    {key:'l6w1', line:6, word:1, ocr:'VOL.',      gt:'Vol.',      status:'fuzzy',    conf:'75%'},
  ];
  return (
    <div style={{
      flex:'0 0 320px', width: 320,
      borderRight:`1px solid ${W.rule}`,
      background:W.panel,
      display:'flex', flexDirection:'column',
      minWidth: 0,
    }}>
      <DrawerTabs active={view}/>
      {view === 'hierarchy' ? (
        <>
          <div style={{
            padding:'8px 12px', borderBottom:`1px solid ${W.rule}`,
            display:'flex', alignItems:'center', gap:6, fontSize:10, color:W.ink3,
            background: W.paper,
          }}>
            <span className="wf-h-label">Filter</span>
            <span className="wf-chip" style={{height:18, padding:'0 6px', fontSize:10}}>All</span>
            <span className="wf-chip" style={{height:18, padding:'0 6px', fontSize:10}}>Blocks</span>
            <span className="wf-chip" style={{height:18, padding:'0 6px', fontSize:10}}>¶ only</span>
            <div style={{flex:1}}></div>
            <span style={{fontSize:9}}>22 nodes</span>
          </div>
          <DrawerHierarchyView/>
          <div style={{padding:'8px 14px', borderTop:`1px solid ${W.rule}`,
            display:'flex', gap: 4, flexWrap:'wrap',
          }}>
            <span className="wf-btn sm">＋ Auto-detect</span>
            <span className="wf-btn sm">Draw block…</span>
            <span className="wf-btn sm">Expand all</span>
          </div>
        </>
      ) : (
        <>
          <div style={{padding:'10px 14px', borderBottom:`1px solid ${W.rule}`,
            display:'flex', flexDirection:'column', gap:6,
          }}>
            <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
              <span className="wf-chip" style={{background:W.mismatch+'20', color:W.mismatch, borderColor:W.mismatch+'88'}}>✗ mismatch 4</span>
              <span className="wf-chip" style={{background:W.fuzzy+'20', color:W.fuzzy, borderColor:W.fuzzy+'88'}}>~ fuzzy 3</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ unmatched</span>
            </div>
            <div style={{display:'flex', gap:4, alignItems:'center'}}>
              <span className="wf-h-label">Sort</span>
              <span className="wf-chip">Confidence ↑</span>
              <div style={{flex:1}}></div>
              <span style={{fontSize:10, color:W.ink3}}><span className="wf-key">J</span>/<span className="wf-key">K</span></span>
            </div>
          </div>

          <div style={{flex:1, overflow:'hidden', padding: 4, position:'relative'}}>
            {queue.map((q) => {
              const focused = q.key === focusedKey;
              const c = q.status === 'mismatch' ? W.mismatch : W.fuzzy;
              return (
                <div key={q.key} style={{
                  padding: 8, margin:'3px 4px', borderRadius: 5,
                  background: focused ? W.hi : 'transparent',
                  border: focused ? `1.5px solid ${W.accent}` : `1px solid transparent`,
                  display:'flex', gap:8, alignItems:'center',
                }}>
                  <span style={{width:5, height:34, borderRadius:3, background:c}}></span>
                  <div style={{flex:1, minWidth:0}}>
                    <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:3}}>
                      <span style={{fontSize:10, color:W.ink3, fontWeight:600}}>L{q.line}·W{q.word}</span>
                      <StatusPip kind={q.status}/>
                      <span style={{fontSize:9, color:W.ink3, marginLeft:'auto'}}>{q.conf}</span>
                    </div>
                    <div style={{fontFamily: W.mono, fontSize: 11, color:W.ink3, whiteSpace:'nowrap', overflow:'hidden'}}>
                      <span>{q.ocr}</span>
                      <span style={{margin:'0 5px', color:W.ink4}}>→</span>
                      <span style={{color: W.ink}}>{q.gt}</span>
                    </div>
                  </div>
                </div>
              );
            })}
            <div className="wf-scrollbar"></div>
          </div>

          <div style={{padding:'8px 14px', borderTop:`1px solid ${W.rule}`,
            display:'flex', flexDirection:'column', gap:6,
          }}>
            <span className="wf-h-label">Bulk on filtered</span>
            <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
              <span className="wf-btn sm">Refine</span>
              <span className="wf-btn sm">OCR → GT</span>
              <span className="wf-btn sm">Validate</span>
              <span className="wf-btn sm">Grid…</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function WorklistCollapsed() {
  return (
    <div style={{
      flex:'0 0 32px', width: 32,
      borderRight:`1px solid ${W.rule}`,
      background:W.paperAlt,
      display:'flex', flexDirection:'column', alignItems:'center', padding:'10px 0', gap:10,
    }}>
      <span className="wf-btn sm icon" style={{width:22, height:22, fontSize:11}}>›</span>
      <div style={{
        writingMode:'vertical-rl', transform:'rotate(180deg)',
        fontSize:10, fontWeight:700, letterSpacing:'0.15em',
        color:W.ink3, textTransform:'uppercase', marginTop:14,
      }}>
        Worklist · 7
      </div>
      <div style={{
        width: 6, height: 6, borderRadius: 3, background: W.mismatch,
        marginTop: 14,
      }}></div>
      <div style={{
        width: 6, height: 6, borderRadius: 3, background: W.fuzzy,
        marginTop: 4,
      }}></div>
    </div>
  );
}

// ============== POWER-USER ACCORDION (scope × action) ===============
function PowerUserAccordion({ open=false }) {
  return (
    <div style={{
      background: W.panel,
      border: `1px solid ${W.rule}`,
      borderRadius: 6,
      overflow: 'hidden',
    }}>
      {/* summary bar */}
      <div style={{
        display:'flex', alignItems:'center', gap: 8, padding:'7px 10px',
        background: open ? W.paperAlt : W.panel,
        borderBottom: open ? `1px solid ${W.rule}` : 'none',
      }}>
        <span style={{
          width: 14, height: 14, display:'inline-flex',
          alignItems:'center', justifyContent:'center',
          color: W.ink2, fontSize: 11,
          transform: open ? 'rotate(90deg)' : 'rotate(0deg)',
          transition: 'transform .15s',
        }}>▶</span>
        <span style={{fontSize: 12, fontWeight: 600}}>Bulk actions</span>
        <span style={{fontSize: 10, color: W.ink3}}>scope × action — applies to current selection</span>
        <div style={{flex:1}}></div>
        {!open && (
          <span style={{fontSize: 10, color: W.ink3, display:'flex', gap:6, alignItems:'center'}}>
            recent:
            <span className="wf-btn sm">Refine</span>
            <span className="wf-btn sm">OCR → GT</span>
            <span className="wf-btn sm">Validate</span>
          </span>
        )}
        <span className="wf-key" style={{height:16, fontSize:9}}>G</span>
      </div>

      {/* expanded body */}
      {open && (
        <div style={{padding: '10px 12px 12px'}}>
          <ActionMatrix density="sm"/>
          <div style={{display:'flex', gap: 8, marginTop: 10, alignItems:'center', flexWrap:'wrap'}}>
            <span className="wf-h-label" style={{minWidth: 60}}>Apply Style</span>
            <select className="wf-input" style={{minWidth: 110, height: 22, fontSize: 11}}><option>All Caps</option></select>
            <select className="wf-input" style={{minWidth: 100, height: 22, fontSize: 11}}><option>Whole word</option></select>
            <span className="wf-btn sm">Apply</span>
            <span style={{width:1, height:18, background:W.rule}}></span>
            <span className="wf-h-label" style={{minWidth: 64}}>Component</span>
            <select className="wf-input" style={{minWidth: 110, height: 22, fontSize: 11}}><option>Drop Cap</option></select>
            <span className="wf-btn sm">Apply</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm primary">＋ Add Word</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ============== CANVAS ==============================================
function HybridCanvas2({ flexBasis = '500px', highlight, powerOpen=false }) {
  return (
    <div style={{
      flex: `1 1 ${flexBasis}`, maxWidth: flexBasis,
      borderRight:`1px solid ${W.rule}`,
      padding: 12, position:'relative', background:W.paperAlt, minWidth: 0,
      display:'flex', flexDirection:'column', gap: 8,
    }}>
      <PowerUserAccordion open={powerOpen}/>

      <div style={{
        display:'flex', alignItems:'center', gap:8, padding:'6px 10px',
        background:W.panel, border:`1px solid ${W.rule}`, borderRadius:6,
        fontSize:11,
      }}>
        <span style={{
          display:'inline-flex', alignItems:'center', gap:5, fontWeight:600,
          padding:'2px 8px', borderRadius:4,
          background: W.accent+'15', color: W.accent, border:`1px solid ${W.accent}55`,
        }}>
          <span style={{width:6, height:6, borderRadius:3, background:W.accent}}></span>
          SELECT · target {highlight || 'Word'}
        </span>
        <div style={{flex:1}}></div>
        <span className="wf-btn sm">Fit</span>
        <span className="wf-btn sm">100%</span>
        <span style={{fontSize:10, color:W.ink3, marginLeft: 4}}>scroll = zoom</span>
      </div>
      <div style={{flex:1, position:'relative', minHeight:0}}>
        <PageScan/>
        {highlight === 'Line' && (
          <div style={{
            position:'absolute', left:'12%', right:'12%',
            top: '68%', height: 28,
            border:`2px solid ${W.accent}`, background: W.accent + '15',
            borderRadius: 2, pointerEvents:'none',
          }}></div>
        )}
        {highlight === 'Para' && (
          <div style={{
            position:'absolute', left:'9%', right:'9%',
            top: '63%', bottom: '4%',
            border:`2px solid ${W.accent}`, background: W.accent + '0a',
            borderRadius: 2, pointerEvents:'none',
          }}></div>
        )}
        {highlight === 'Block' && (
          <>
            {/* outer block — block-quote spanning two paragraphs */}
            <div style={{
              position:'absolute', left:'14%', right:'14%',
              top: '40%', bottom: '12%',
              border:`2.5px solid ${W.accent}`,
              background: W.accent + '0a',
              borderRadius: 2, pointerEvents:'none',
            }}>
              <span style={{
                position:'absolute', top:-9, left: 6,
                padding:'0 6px', background:W.paperAlt,
                fontSize:9, fontWeight: 700, color: W.accent,
                fontFamily: 'monospace', letterSpacing:'0.04em',
              }}>BLOCK · block_quote</span>
            </div>
            {/* nested child paragraphs hinted by thinner outline */}
            <div style={{
              position:'absolute', left:'18%', right:'18%',
              top: '44%', height: '20%',
              border:`1px dashed ${'#7a6c5a'}`,
              pointerEvents:'none',
            }}></div>
            <div style={{
              position:'absolute', left:'18%', right:'18%',
              top: '67%', height: '20%',
              border:`1px dashed ${'#7a6c5a'}`,
              pointerEvents:'none',
            }}></div>
          </>
        )}
      </div>
    </div>
  );
}

// ============== RIGHT PANEL — common breadcrumb header ==============
function RightTabBar({ active, hasPara, hasLine, hasWord, wordLabel }) {
  // active ∈ {matches, para, line, word}
  const Tab = ({ k, label, sub, dim }) => {
    const on = k === active;
    return (
      <span style={{
        padding: '7px 12px', fontSize: 12, fontWeight: 600,
        color: dim ? W.ink4 : (on ? W.ink : W.ink3),
        borderBottom: on ? `2px solid ${W.ink}` : '2px solid transparent',
        marginBottom: -1,
        display:'flex', alignItems:'center', gap:5,
        cursor:'default',
      }}>
        {label}
        {sub && <span style={{fontSize:10, color: dim ? W.ink4 : W.ink3, fontWeight:500}}>{sub}</span>}
      </span>
    );
  };
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 2,
      padding: '0 10px', borderBottom: `1px solid ${W.rule}`, background: W.panel,
    }}>
      <Tab k="matches" label="Matches"/>
      <span style={{color:W.ink4, padding:'0 3px'}}>›</span>
      <Tab k="para"  label="Para"  sub="4" dim={!hasPara}/>
      <span style={{color:W.ink4, padding:'0 3px'}}>›</span>
      <Tab k="line"  label="Line"  sub="4" dim={!hasLine}/>
      <span style={{color:W.ink4, padding:'0 3px'}}>›</span>
      <Tab k="word"  label="Word"  sub={wordLabel} dim={!hasWord}/>
      <div style={{flex:1}}></div>
      <div style={{display:'flex', gap:6, alignItems:'center', padding:'6px 0'}}>
        <span style={{fontSize:10, color:W.ink3}}>
          <span className="wf-key">↑</span>
          <span className="wf-key">↓</span>
          <span className="wf-key">←</span>
          <span className="wf-key">→</span>
          {' '}move
        </span>
      </div>
    </div>
  );
}

// ============== RIGHT PANEL — MATCHES =================================
function RightPanelMatches() {
  return (
    <div style={{flex:'1 1 0', display:'flex', flexDirection:'column', minWidth: 0}}>
      <RightTabBar active="matches"/>
      <div style={{
        display:'flex', alignItems:'center', gap:6, padding:'8px 14px',
        borderBottom:`1px solid ${W.rule}`, background:W.paperAlt,
      }}>
        <span className="wf-h-label">Show</span>
        <span className="wf-chip" style={{background:W.fuzzy+'20', color:W.fuzzy, borderColor:W.fuzzy+'88'}}>Unvalidated 7</span>
        <span className="wf-chip" style={{background:W.mismatch+'20', color:W.mismatch, borderColor:W.mismatch+'88'}}>Mismatched 4</span>
        <span className="wf-chip">All 22</span>
        <div style={{flex:1}}></div>
        <span className="wf-h-label">View</span>
        <span className="wf-chip">Reading order ▾</span>
        <span className="wf-btn sm">Bulk ▾</span>
      </div>
      <div style={{flex:1, padding: 12, background: W.paperAlt, position:'relative', overflow:'hidden'}}>
        <LineCard line={{no:4, para:4, exact:3, fuzzy:2, mismatch:0}} words={SAMPLE_WORDS_L4}/>
        <LineCard line={{no:6, para:6, exact:1, fuzzy:1, mismatch:0}} words={SAMPLE_WORDS_L6}/>
        <LineCard line={{no:7, para:7, exact:1, fuzzy:0, mismatch:4}} words={SAMPLE_WORDS_L7}/>
        <div className="wf-scrollbar"></div>
      </div>
    </div>
  );
}

// ============== RIGHT PANEL — WORD EDITOR =============================
function RightPanelWord() {
  return (
    <div style={{flex:'1 1 0', display:'flex', flexDirection:'column', minWidth: 0, background:W.panel}}>
      <RightTabBar active="word" hasPara hasLine hasWord wordLabel="1 “The”"/>
      <div style={{padding: 18, display:'flex', flexDirection:'column', gap: 14, flex:1, minHeight:0, overflow:'hidden'}}>
        {/* word ID strip */}
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Line 7 · Word 1</span>
          <StatusPip kind="mismatch"/>
          <span style={{fontSize: 11, color: W.ink3}}>confidence 42%</span>
          <div style={{flex:1}}></div>
          <span style={{fontSize:10, color:W.ink3}}>1 of 7 in worklist</span>
          <span className="wf-btn sm">◀ Prev</span>
          <span className="wf-btn sm">Next ▶</span>
        </div>

        {/* triplet zoom (compact) */}
        <div style={{display:'flex', gap:10, alignItems:'stretch'}}>
          <div style={{flex:'0 0 90px', display:'flex', flexDirection:'column', gap:3, opacity:0.5}}>
            <span className="wf-h-label">Prev</span>
            <div style={{background:W.paperAlt, border:`1px solid ${W.ruleSoft}`, borderRadius:4,
              flex:1, minHeight:90, display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'serif', fontSize:20, fontStyle:'italic',
            }}>—</div>
          </div>
          <div style={{flex:1, display:'flex', flexDirection:'column', gap:3}}>
            <span className="wf-h-label">Current</span>
            <div style={{background:'#fff', border:`1.5px solid ${W.accent}`, borderRadius:6,
              minHeight: 130, padding: '8px 16px',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'serif', fontSize: 84,
            }}>The</div>
          </div>
          <div style={{flex:'0 0 90px', display:'flex', flexDirection:'column', gap:3, opacity:0.5}}>
            <span className="wf-h-label">Next</span>
            <div style={{background:W.paperAlt, border:`1px solid ${W.ruleSoft}`, borderRadius:4,
              flex:1, minHeight:90, display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'serif', fontSize:18,
            }}>Founding</div>
          </div>
        </div>

        {/* zoom + nudge */}
        <div style={{display:'flex', gap:8, alignItems:'center', flexWrap:'wrap'}}>
          <span className="wf-h-label">Zoom</span>
          {['1×','2×','5×','10×','Fit'].map(z => (
            <span key={z} className="wf-btn sm" style={{
              background: z==='2×'?W.ink:W.panel, color: z==='2×'?'#fff':W.ink, borderColor: z==='2×'?W.ink:W.ink3,
            }}>{z}</span>
          ))}
          <div style={{flex:1}}></div>
          <span className="wf-h-label">Nudge</span>
          {['1','5','10'].map(s => (
            <span key={s} className="wf-btn sm" style={{width:22, padding:0,
              background: s==='5'?W.ink:W.panel, color: s==='5'?'#fff':W.ink, borderColor: s==='5'?W.ink:W.ink3,
            }}>{s}</span>
          ))}
          <span style={{fontSize:10, color:W.ink3}}>px</span>
          {[['L'],['R'],['T'],['B']].map(([n]) => (
            <div key={n} style={{display:'flex', gap:2, alignItems:'center'}}>
              <span style={{fontSize:10, fontWeight:600}}>{n}</span>
              <span className="wf-btn sm" style={{width:20, padding:0}}>−</span>
              <span className="wf-btn sm" style={{width:20, padding:0}}>+</span>
            </div>
          ))}
        </div>

        {/* OCR/GT compare */}
        <div style={{display:'grid', gridTemplateColumns:'80px 1fr auto', rowGap:8, columnGap:10, alignItems:'center'}}>
          <span className="wf-h-label">OCR</span>
          <div className="wf-mono" style={{padding:'8px 10px', background:W.panelSunk, borderRadius:4, fontSize:14}}>tbe</div>
          <span className="wf-btn sm">OCR → GT</span>
          <span className="wf-h-label">GT</span>
          <input className="wf-input lg" defaultValue="The" style={{width:'100%', fontSize:14}}/>
          <span></span>
        </div>

        {/* style + component */}
        <div style={{display:'flex', gap:24}}>
          <div style={{flex:1}}>
            <span className="wf-h-label">Style</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-chip">Blackletter<span className="x">×</span></span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ italic</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ sm-caps</span>
            </div>
          </div>
          <div style={{flex:1}}>
            <span className="wf-h-label">Component</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ drop cap</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ footnote</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ catchword</span>
            </div>
          </div>
        </div>

        {/* bbox / merge */}
        <div style={{display:'flex', gap:24}}>
          <div style={{flex:1}}>
            <span className="wf-h-label">Bounding box</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-btn sm">Refine</span>
              <span className="wf-btn sm">Exp+Refine</span>
              <span className="wf-btn sm">Rebox…</span>
              <span className="wf-btn sm">Crop ▲</span>
              <span className="wf-btn sm">Crop ▼</span>
            </div>
          </div>
          <div style={{flex:1}}>
            <span className="wf-h-label">Merge / split</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-btn sm">⟵ Merge prev</span>
              <span className="wf-btn sm">Merge next ⟶</span>
              <span className="wf-btn sm">Split</span>
            </div>
          </div>
        </div>

        {/* commit */}
        <div style={{marginTop:'auto', display:'flex', gap:8, alignItems:'center'}}>
          <span className="wf-btn primary lg" style={{flex:1}}>
            ✓ Validate &amp; Next <span className="wf-key" style={{height:16, fontSize:9, background:'#0003', color:'#fff', borderColor:'transparent', marginLeft:4}}>⏎</span>
          </span>
          <span className="wf-btn lg ghost">Skip <span className="wf-key">␣</span></span>
          <span className="wf-btn lg danger">🗑</span>
        </div>
      </div>
    </div>
  );
}

// ============== RIGHT PANEL — LINE EDITOR =============================
function RightPanelLine() {
  return (
    <div style={{flex:'1 1 0', display:'flex', flexDirection:'column', minWidth: 0, background:W.panel}}>
      <RightTabBar active="line" hasPara hasLine/>
      <div style={{padding: 18, display:'flex', flexDirection:'column', gap: 14, flex:1, minHeight:0, overflow:'hidden'}}>
        {/* line ID strip */}
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Line 4 (in Paragraph 4)</span>
          <span style={{fontSize: 11, color: W.ink3}}>5 words</span>
          <span style={{display:'flex', gap:8, fontSize:11}}>
            <span style={{color:W.exact}}>✓ 3</span>
            <span style={{color:W.fuzzy}}>~ 2</span>
            <span style={{color:W.mismatch}}>✗ 0</span>
          </span>
          <div style={{flex:1}}></div>
          <span className="wf-btn sm">◀ Prev line</span>
          <span className="wf-btn sm">Next line ▶</span>
        </div>

        {/* line image strip */}
        <div style={{
          background:'#fff', border:`1.5px solid ${W.accent}`, borderRadius:6,
          padding: '20px 24px',
          display:'flex', alignItems:'center', justifyContent:'center', gap: 30,
          fontFamily:'serif',
        }}>
          <span style={{fontSize: 48}}>WOODROW</span>
          <span style={{fontSize: 48}}>WILSON,</span>
          <span style={{fontSize: 38, fontVariant:'small-caps'}}>Ph.D.,</span>
          <span style={{fontSize: 38, fontVariant:'small-caps'}}>Litt.D.,</span>
          <span style={{fontSize: 48}}>LL.D.</span>
        </div>

        {/* line-level actions */}
        <div style={{display:'flex', gap:24}}>
          <div style={{flex:1}}>
            <span className="wf-h-label">Bounding box</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-btn sm">Refine all words</span>
              <span className="wf-btn sm">Expand + Refine</span>
              <span className="wf-btn sm">Rebox line…</span>
            </div>
          </div>
          <div style={{flex:1}}>
            <span className="wf-h-label">Structure</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-btn sm">⟵ Merge prev line</span>
              <span className="wf-btn sm">Merge next line ⟶</span>
              <span className="wf-btn sm">Split here…</span>
              <span className="wf-btn sm">→ Promote to Para</span>
            </div>
          </div>
        </div>

        {/* word breakdown */}
        <div>
          <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:6}}>
            <span className="wf-h-label">Words in this line</span>
            <span style={{fontSize:10, color:W.ink3}}>click to drill in</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm">Apply style to all…</span>
            <span className="wf-btn sm">OCR → GT (all)</span>
            <span className="wf-btn sm">Validate all</span>
          </div>
          <div style={{display:'flex', gap:8, padding: 10, background:W.paperAlt, borderRadius:4, border:`1px solid ${W.rule}`, overflow:'auto'}}>
            {SAMPLE_WORDS_L4.map((w, i) => (
              <WordCell key={i} {...w} w={150} focused={i===2}/>
            ))}
          </div>
        </div>

        {/* line text (consolidated GT) */}
        <div>
          <span className="wf-h-label">Line ground truth (consolidated, editable per word above)</span>
          <div className="wf-mono" style={{
            padding:'10px 12px', background:W.panelSunk, borderRadius:4,
            fontSize:13, marginTop:6, color:W.ink,
          }}>WOODROW WILSON, Ph.D., Litt.D., LL.D.</div>
        </div>

        {/* commit */}
        <div style={{marginTop:'auto', display:'flex', gap:8}}>
          <span className="wf-btn primary lg" style={{flex:1}}>✓ Validate all words in line</span>
          <span className="wf-btn lg ghost">Unvalidate</span>
          <span className="wf-btn lg danger">Delete line</span>
        </div>
      </div>
    </div>
  );
}

// ============== RIGHT PANEL — PARA EDITOR =============================
function RightPanelPara() {
  return (
    <div style={{flex:'1 1 0', display:'flex', flexDirection:'column', minWidth: 0, background:W.panel}}>
      <RightTabBar active="para" hasPara/>
      <div style={{padding: 18, display:'flex', flexDirection:'column', gap: 14, flex:1, minHeight:0, overflow:'hidden'}}>
        <div style={{display:'flex', alignItems:'center', gap: 10}}>
          <span style={{fontSize: 14, fontWeight: 700}}>Paragraph 7</span>
          <span style={{fontSize: 11, color: W.ink3}}>1 line · 5 words</span>
          <span style={{display:'flex', gap:8, fontSize:11}}>
            <span style={{color:W.exact}}>✓ 1</span>
            <span style={{color:W.fuzzy}}>~ 0</span>
            <span style={{color:W.mismatch}}>✗ 4</span>
          </span>
          <div style={{flex:1}}></div>
          <span className="wf-btn sm">◀ Prev para</span>
          <span className="wf-btn sm">Next para ▶</span>
        </div>

        {/* para image */}
        <div style={{
          background:'#fff', border:`1.5px solid ${W.accent}`, borderRadius:6,
          padding: '16px 24px',
          display:'flex', flexDirection:'column', gap:10,
        }}>
          <div style={{display:'flex', justifyContent:'center', alignItems:'center', gap:16,
            fontFamily:'"UnifrakturCook", "Times New Roman", serif',
            fontSize: 42, color: W.ink,
          }}>
            <span>The</span><span>Founding</span><span>of</span><span>the</span><span>Government</span>
          </div>
        </div>

        {/* para-level actions */}
        <div style={{display:'flex', gap:24}}>
          <div style={{flex:1}}>
            <span className="wf-h-label">Bounding box</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-btn sm">Refine all</span>
              <span className="wf-btn sm">Expand + Refine</span>
              <span className="wf-btn sm">Rebox para…</span>
            </div>
          </div>
          <div style={{flex:1}}>
            <span className="wf-h-label">Structure</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-btn sm">⟵ Merge prev para</span>
              <span className="wf-btn sm">Merge next ⟶</span>
              <span className="wf-btn sm">Split between lines…</span>
            </div>
          </div>
        </div>

        {/* lines list */}
        <div>
          <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:6}}>
            <span className="wf-h-label">Lines in this paragraph</span>
            <div style={{flex:1}}></div>
            <span className="wf-btn sm">Apply style to all…</span>
            <span className="wf-btn sm">OCR → GT (all)</span>
          </div>
          <div style={{display:'flex', flexDirection:'column', gap: 6, flex:1, minHeight: 0, overflow:'hidden'}}>
            <LineCard line={{no:7, para:7, exact:1, fuzzy:0, mismatch:4}} words={SAMPLE_WORDS_L7} highlighted/>
          </div>
        </div>

        <div style={{marginTop:'auto', display:'flex', gap:8}}>
          <span className="wf-btn primary lg" style={{flex:1}}>✓ Validate paragraph</span>
          <span className="wf-btn lg danger">Delete paragraph</span>
        </div>
      </div>
    </div>
  );
}

// ============== COMPOSITIONS ==========================================
function HybridN1() {
  // Default: nothing focused, right shows matches list
  return (
    <div className="wf" style={{display:'flex'}}>
      <HybridRail2 activeMode="Select" activeTarget="Word"/>
      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        <HybridHeader2/>
        <div style={{flex:1, display:'flex', minHeight:0}}>
          <WorklistDrawer/>
          <HybridCanvas2 flexBasis="520px" powerOpen/>
          <RightPanelMatches/>
        </div>
      </div>
    </div>
  );
}

function HybridN2() {
  // Worklist click → right panel becomes the Word editor.
  return (
    <div className="wf" style={{display:'flex'}}>
      <HybridRail2 activeMode="Select" activeTarget="Word"/>
      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        <HybridHeader2/>
        <div style={{flex:1, display:'flex', minHeight:0}}>
          <WorklistDrawer focusedKey="l7w1"/>
          <HybridCanvas2 flexBasis="500px" highlight="Word"/>
          <RightPanelWord/>
        </div>
      </div>
    </div>
  );
}

function HybridN3() {
  return (
    <div className="wf" style={{display:'flex'}}>
      <HybridRail2 activeMode="Select" activeTarget="Line"/>
      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        <HybridHeader2/>
        <div style={{flex:1, display:'flex', minHeight:0}}>
          <WorklistDrawer/>
          <HybridCanvas2 flexBasis="500px" highlight="Line"/>
          <div style={{flex:'1 1 0', minWidth:0, display:'flex', flexDirection:'column', overflow:'hidden'}}>
            <TabbedLinePanel/>
          </div>
        </div>
      </div>
    </div>
  );
}

function HybridN4() {
  return (
    <div className="wf" style={{display:'flex'}}>
      <HybridRail2 activeMode="Select" activeTarget="Block"/>
      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        <HybridHeader2/>
        <div style={{flex:1, display:'flex', minHeight:0}}>
          <WorklistDrawer view="hierarchy"/>
          <HybridCanvas2 flexBasis="520px" highlight="Para"/>
          <div style={{flex:'1 1 0', minWidth:0, display:'flex', flexDirection:'column', overflow:'hidden'}}>
            <TabbedBlockPanel structural={false} activeTab="items"/>
          </div>
        </div>
      </div>
    </div>
  );
}

function HybridN5() {
  return (
    <div className="wf" style={{display:'flex'}}>
      <HybridRail2 activeMode="Select" activeTarget="Block"/>
      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        <HybridHeader2/>
        <div style={{flex:1, display:'flex', minHeight:0}}>
          <WorklistDrawer view="hierarchy"/>
          <HybridCanvas2 flexBasis="500px" highlight="Block"/>
          <div style={{flex:'1 1 0', minWidth:0, display:'flex', flexDirection:'column', overflow:'hidden'}}>
            <TabbedBlockPanel structural={true} activeTab="layout"/>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  HybridN1, HybridN2, HybridN3, HybridN4, HybridN5,
  HybridRail2, HybridHeader2, WorklistDrawer, WorklistCollapsed, HybridCanvas2,
  RightPanelMatches, RightPanelWord, RightPanelLine, RightPanelPara,
});
