// Word Edit Dialog — 3 variants.
// Sizes: 900×700 modal canvas.

// V1 — CONTEXT TRIPLET (closest to existing screenshot)
// Shows previous / current / next words side-by-side, fine-tune nudge controls
// inline, all bbox + merge controls grouped.
function WordDialogV1() {
  return (
    <div className="wf" style={{padding:0}}>
      {/* title bar */}
      <div style={{
        display:'flex', alignItems:'center', padding:'14px 20px',
        borderBottom:`1px solid ${W.rule}`, background:W.panel,
      }}>
        <span style={{fontSize:15, fontWeight:700}}>Edit Line 4, Word 2</span>
        <StatusPip kind="fuzzy" label="fuzzy 83%"/>
        <div style={{flex:1}}></div>
        <span className="wf-btn sm">◀ Prev word</span>
        <span className="wf-btn sm" style={{marginRight:12}}>Next word ▶</span>
        <span className="wf-btn primary sm">Done</span>
        <span style={{marginLeft:8, fontSize:18, color:W.ink3}}>✕</span>
      </div>

      {/* context triplet */}
      <div style={{display:'flex', padding:'18px 24px', gap:18, borderBottom:`1px solid ${W.rule}`}}>
        {[
          {l:'Previous', word:'WOODROW', gt:'WOODROW', dim:true},
          {l:'Current',  word:'WILSON,', gt:'WILSON,', focus:true},
          {l:'Next',     word:'Ph.D.,',  gt:'Ph.D.,',  dim:true},
        ].map((c,i) => (
          <div key={i} style={{
            flex: c.focus ? 1.6 : 1,
            display:'flex', flexDirection:'column', alignItems:'center', gap:4,
            opacity: c.dim ? 0.65 : 1,
          }}>
            <span className="wf-h-label">{c.l}</span>
            <div style={{
              width:'100%', minHeight: c.focus ? 90 : 60,
              padding: '10px 14px',
              background: c.focus ? '#fff' : W.paperAlt,
              border: c.focus ? `1.5px solid ${W.accent}` : `1px solid ${W.ruleSoft}`,
              borderRadius: 6,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'serif', fontSize: c.focus ? 48 : 26,
            }}>{c.word}</div>
            <div className="wf-mono" style={{fontSize: c.focus ? 14 : 11, color: W.ink2}}>{c.gt}</div>
            {c.focus && (
              <>
                <div style={{display:'flex', gap:4, marginTop:6}}>
                  {['1×','2×','5×','10×'].map(z => (
                    <span key={z} className="wf-btn sm" style={{
                      background: z==='2×'?W.ink:W.panel, color: z==='2×'?'#fff':W.ink,
                      borderColor: z==='2×'?W.ink:W.ink3,
                    }}>{z}</span>
                  ))}
                </div>
                <div style={{
                  width:'100%', marginTop:8, display:'flex', flexDirection:'column', gap:6,
                }}>
                  <div style={{display:'flex', alignItems:'center', gap:8}}>
                    <span className="wf-h-label" style={{minWidth:36}}>GT</span>
                    <input className="wf-input lg" defaultValue="WILSON," style={{flex:1, fontSize:14}}/>
                  </div>
                </div>
              </>
            )}
          </div>
        ))}
      </div>

      {/* Style / component row */}
      <div style={{display:'flex', gap:10, padding:'14px 24px', borderBottom:`1px solid ${W.rule}`, background:W.paperAlt, alignItems:'flex-end'}}>
        <div style={{flex:1, display:'flex', flexDirection:'column', gap:4}}>
          <span className="wf-h-label">Style</span>
          <div style={{display:'flex', gap:6}}>
            <select className="wf-input" defaultValue=""><option>All Caps</option></select>
            <select className="wf-input" defaultValue=""><option>Whole word</option></select>
            <span className="wf-btn sm">Apply</span>
          </div>
        </div>
        <div style={{flex:1, display:'flex', flexDirection:'column', gap:4}}>
          <span className="wf-h-label">Component</span>
          <div style={{display:'flex', gap:6}}>
            <select className="wf-input" defaultValue=""><option>Drop Cap</option></select>
            <span className="wf-btn sm">Apply</span>
          </div>
        </div>
        <div style={{flex:1, display:'flex', flexDirection:'column', gap:4}}>
          <span className="wf-h-label">Existing labels</span>
          <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
            <span className="wf-chip">All Caps (whole)<span className="x">×</span></span>
          </div>
        </div>
      </div>

      {/* Two columns: Merge/Split | Bounding Box */}
      <div style={{display:'flex', padding:'14px 24px', gap:20, borderBottom:`1px solid ${W.rule}`}}>
        <div style={{flex:1, display:'flex', flexDirection:'column', gap:8}}>
          <span className="wf-h-label">Merge / Split</span>
          <div style={{display:'flex', gap:6, flexWrap:'wrap'}}>
            <span className="wf-btn sm">⟵ Merge prev</span>
            <span className="wf-btn sm">Merge next ⟶</span>
            <span className="wf-btn sm">Split horiz</span>
            <span className="wf-btn sm">Split vert</span>
            <span className="wf-btn sm danger">Delete word</span>
          </div>
        </div>
        <div style={{width:1, background:W.rule}}></div>
        <div style={{flex:1, display:'flex', flexDirection:'column', gap:8}}>
          <span className="wf-h-label">Bounding Box</span>
          <div style={{display:'flex', gap:6, flexWrap:'wrap'}}>
            <span className="wf-btn sm">Refine</span>
            <span className="wf-btn sm">Expand + Refine</span>
            <span className="wf-btn sm">Rebox (close &amp; draw)</span>
          </div>
          <div style={{display:'flex', gap:6, flexWrap:'wrap'}}>
            <span className="wf-btn sm">Crop ▲</span>
            <span className="wf-btn sm">Crop ▼</span>
            <span className="wf-btn sm">Crop ◀</span>
            <span className="wf-btn sm">Crop ▶</span>
            <span className="wf-btn sm danger">Erase pixels</span>
          </div>
        </div>
      </div>

      {/* Fine-tune nudge */}
      <div style={{padding:'14px 24px', display:'flex', gap:20, alignItems:'center', background:W.paperAlt}}>
        <span className="wf-h-label">Nudge</span>
        <div style={{display:'flex', gap:4, alignItems:'center'}}>
          <span style={{fontSize:11, color:W.ink2}}>step</span>
          {['1px','5px','10px'].map(s => (
            <span key={s} className="wf-btn sm" style={{
              background: s==='5px'?W.ink:W.panel, color: s==='5px'?'#fff':W.ink, borderColor: s==='5px'?W.ink:W.ink3,
            }}>{s}</span>
          ))}
        </div>
        <div style={{display:'flex', gap:14, alignItems:'center'}}>
          {[['L','x'],['R','x'],['T','y'],['B','y']].map(([side]) => (
            <div key={side} style={{display:'flex', alignItems:'center', gap:3}}>
              <span style={{fontSize:11, fontWeight:600, marginRight:3}}>{side}</span>
              <span className="wf-btn sm" style={{width:24, padding:0}}>−</span>
              <span className="wf-btn sm" style={{width:24, padding:0}}>+</span>
            </div>
          ))}
        </div>
        <span style={{fontSize:11, color:W.ink3, marginLeft:10}}>Pending L:0 R:0 T:0 B:0 px</span>
        <div style={{flex:1}}></div>
        <span className="wf-btn sm ghost">Reset</span>
        <span className="wf-btn sm">Apply</span>
        <span className="wf-btn sm primary">Apply + Refine</span>
      </div>
    </div>
  );
}

// V2 — SIDE-BY-SIDE COMPARISON (image-first, edit-light)
// Big word zoom on left; on right a vertical stack of: GT input,
// style chips, merge/split, bbox actions. Less context but more focus.
function WordDialogV2() {
  return (
    <div className="wf">
      <div style={{
        display:'flex', alignItems:'center', padding:'14px 20px',
        borderBottom:`1px solid ${W.rule}`, background:W.panel,
      }}>
        <span style={{fontSize:15, fontWeight:700}}>Word editor</span>
        <span style={{fontSize:12, color:W.ink3, marginLeft:8}}>L4 · W2 of 5</span>
        <StatusPip kind="fuzzy" label="83%"/>
        <div style={{flex:1}}></div>
        <span style={{fontSize:10, color:W.ink3, marginRight:8}}><span className="wf-key">⌘</span><span className="wf-key">⏎</span> save&amp;next</span>
        <span className="wf-btn primary sm">Save &amp; Next ⏎</span>
        <span className="wf-btn sm" style={{marginLeft:6}}>Close</span>
      </div>
      <div style={{display:'flex', flex:1, minHeight:0}}>
        {/* image */}
        <div style={{flex:'1 1 55%', padding: 20, borderRight: `1px solid ${W.rule}`,
          display:'flex', flexDirection:'column', gap:10, background: W.paperAlt,
        }}>
          <div style={{
            flex:1, background:'#fff', border:`1px solid ${W.rule}`, borderRadius:6,
            display:'flex', alignItems:'center', justifyContent:'center',
            fontFamily:'serif', fontSize: 90,
            position:'relative',
          }}>
            WILSON,
            {/* bbox overlay */}
            <div style={{
              position:'absolute', top:'25%', left:'12%', right:'12%', bottom:'25%',
              border:`1.5px solid ${W.wordColor}`, background: W.wordColor + '15',
              borderRadius: 2,
            }}></div>
          </div>
          {/* zoom + nudge */}
          <div style={{display:'flex', gap:8, alignItems:'center'}}>
            <span className="wf-h-label">Zoom</span>
            {['1×','2×','5×','10×','Fit'].map(z => (
              <span key={z} className="wf-btn sm" style={{
                background: z==='2×'?W.ink:W.panel, color: z==='2×'?'#fff':W.ink, borderColor: z==='2×'?W.ink:W.ink3,
              }}>{z}</span>
            ))}
            <div style={{flex:1}}></div>
            <span className="wf-h-label">Nudge</span>
            {['1px','5px','10px'].map(s => (
              <span key={s} className="wf-btn sm">{s}</span>
            ))}
          </div>
          <div style={{display:'flex', gap:8, alignItems:'center'}}>
            <span className="wf-h-label" style={{minWidth:36}}>Box</span>
            {[['L','◀'],['R','▶'],['T','▲'],['B','▼']].map(([n,a]) => (
              <div key={n} style={{display:'flex', gap:2, alignItems:'center'}}>
                <span style={{fontSize:11, fontWeight:600}}>{n}</span>
                <span className="wf-btn sm" style={{width:22, padding:0}}>−</span>
                <span className="wf-btn sm" style={{width:22, padding:0}}>+</span>
              </div>
            ))}
            <div style={{flex:1}}></div>
            <span className="wf-btn sm">Refine</span>
            <span className="wf-btn sm">Exp + Refine</span>
            <span className="wf-btn sm">Rebox…</span>
          </div>
        </div>
        {/* edit column */}
        <div style={{flex:'1 1 45%', display:'flex', flexDirection:'column', padding:20, gap:14, minWidth:0}}>
          <div>
            <span className="wf-h-label">OCR text</span>
            <div className="wf-mono" style={{padding:'10px 12px', background:W.panelSunk, borderRadius:4, fontSize:16, marginTop:4}}>WILSON,</div>
          </div>
          <div>
            <span className="wf-h-label">Ground truth</span>
            <input className="wf-input lg" defaultValue="WILSON," style={{width:'100%', marginTop:4, fontSize:16, height:38}}/>
            <div style={{display:'flex', gap:6, marginTop:6}}>
              <span className="wf-btn sm">← copy OCR</span>
            </div>
          </div>
          <div>
            <span className="wf-h-label">Style</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-chip">All Caps (whole)<span className="x">×</span></span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ italic</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ sm-caps</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ bold</span>
            </div>
          </div>
          <div>
            <span className="wf-h-label">Component</span>
            <div style={{display:'flex', gap:5, flexWrap:'wrap', marginTop:6}}>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ drop cap</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ footnote</span>
              <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ catchword</span>
            </div>
          </div>
          <div>
            <span className="wf-h-label">Merge / split</span>
            <div style={{display:'flex', gap:5, marginTop:6, flexWrap:'wrap'}}>
              <span className="wf-btn sm">⟵ Merge prev</span>
              <span className="wf-btn sm">Merge next ⟶</span>
              <span className="wf-btn sm">Split ⟹</span>
              <span className="wf-btn sm">Split ⇊</span>
            </div>
          </div>
          <div style={{marginTop:'auto', display:'flex', gap:6}}>
            <span className="wf-btn primary lg" style={{flex:1}}>✓ Save</span>
            <span className="wf-btn lg ghost">Discard</span>
            <span className="wf-btn lg danger">🗑</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// V3 — INLINE DRAWER (skinny, slides in from canvas right)
// Fits the V5 worklist flow — a vertical right-side dialog that doesn't
// occlude the page scan. Keyboard-first.
function WordDialogV3() {
  return (
    <div className="wf" style={{padding:0}}>
      <div style={{
        padding:'12px 16px', borderBottom:`1px solid ${W.rule}`, background:W.panel,
        display:'flex', alignItems:'center', gap:10,
      }}>
        <span style={{fontSize:14, fontWeight:700}}>L4 · W2</span>
        <StatusPip kind="fuzzy" label="83%"/>
        <div style={{flex:1}}></div>
        <span style={{fontSize:10, color:W.ink3}}><span className="wf-key">esc</span></span>
      </div>
      <div style={{padding:16, display:'flex', flexDirection:'column', gap:14, height:'calc(100% - 50px)'}}>
        {/* word zoom strip */}
        <div style={{
          background:'#fff', border:`1px solid ${W.rule}`, borderRadius:6,
          padding:'22px 16px',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontFamily:'serif', fontSize: 56,
        }}>WILSON,</div>

        <div>
          <span className="wf-h-label">OCR</span>
          <div className="wf-mono" style={{padding:'6px 10px', background:W.panelSunk, borderRadius:4, fontSize:13, marginTop:4}}>WILSON,</div>
        </div>
        <div>
          <span className="wf-h-label">GT</span>
          <input className="wf-input lg" defaultValue="WILSON," style={{width:'100%', marginTop:4}}/>
          <div style={{display:'flex', gap:4, marginTop:6}}>
            <span className="wf-btn sm" style={{flex:1}}>← copy OCR</span>
          </div>
        </div>
        <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
          <span className="wf-chip">All Caps<span className="x">×</span></span>
          <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ style</span>
          <span className="wf-chip" style={{borderStyle:'dashed', color:W.ink3}}>+ component</span>
        </div>

        <details open style={{border:`1px solid ${W.rule}`, borderRadius:4, padding:8}}>
          <summary style={{fontSize:11, fontWeight:600, color:W.ink2, cursor:'default'}}>Bounding box</summary>
          <div style={{display:'flex', gap:4, flexWrap:'wrap', marginTop:8}}>
            <span className="wf-btn sm">Refine</span>
            <span className="wf-btn sm">Exp+Refine</span>
            <span className="wf-btn sm">Rebox</span>
          </div>
          <div style={{display:'flex', gap:6, marginTop:8, alignItems:'center'}}>
            <span style={{fontSize:10, color:W.ink3}}>step</span>
            {['1','5','10'].map(s => (
              <span key={s} className="wf-btn sm" style={{
                width:22, padding:0,
                background: s==='5'?W.ink:W.panel, color: s==='5'?'#fff':W.ink, borderColor: s==='5'?W.ink:W.ink3,
              }}>{s}</span>
            ))}
            <span style={{fontSize:10, color:W.ink3, marginLeft:6}}>px</span>
            <div style={{flex:1}}></div>
            <span style={{fontSize:10, color:W.ink3}}>arrows ←↑↓→</span>
          </div>
        </details>

        <details style={{border:`1px solid ${W.rule}`, borderRadius:4, padding:8}}>
          <summary style={{fontSize:11, fontWeight:600, color:W.ink2}}>Merge / split / delete</summary>
        </details>

        <div style={{marginTop:'auto', display:'flex', flexDirection:'column', gap:6}}>
          <span className="wf-btn primary lg">✓ Save &amp; Next <span className="wf-key" style={{height:16, fontSize:9, background:'#0003', color:'#fff', borderColor:'transparent', marginLeft:4}}>⏎</span></span>
          <div style={{display:'flex', gap:6}}>
            <span className="wf-btn sm ghost" style={{flex:1}}>Skip <span className="wf-key">␣</span></span>
            <span className="wf-btn sm" style={{flex:1}}>Open full dialog</span>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { WordDialogV1, WordDialogV2, WordDialogV3 });
